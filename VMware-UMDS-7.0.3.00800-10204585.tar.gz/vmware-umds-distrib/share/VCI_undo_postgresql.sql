/* *************************************************************************
 * Copyright 2016-2021 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/*==============================================================
 VCI_undo_postgresql.sql
 DBMS name:      postgres 9.2
==============================================================*/

/* Drop tables */

drop table VCI_UPDATE_CONFLICT_INFO;

drop table VCI_UPDATE_BASELINES_EXPANDED cascade;

drop table VCI_HOST_UPGRADE_BASELINES cascade;

drop table VCI_HOST_UPGRADES cascade;

drop table VCI_HOST_UPGRADE_PACKAGES cascade;

drop table VCI_VMTOOLS_SCANRESULTS cascade;

drop table VCI_VMHW_SCANRESULTS cascade;

drop table VCI_VMHW_COMPATIBILITY cascade;

drop table VCI_VMHW_VERSIONS cascade;

drop table VCI_VERSION cascade;

drop table VCI_UPDATES cascade;

drop table VCI_PLATFORMS cascade;

drop table VCI_UPDATE_PLATFORMS cascade;

drop table VCI_METADATA_FILES cascade;

drop table VCI_PLATFORM_METADATA cascade;

drop table VCI_UPDATE_PACKAGES cascade;

drop table VCI_PACKAGES cascade;

drop table VCI_BASELINES cascade;

drop table VCI_BASELINE_GROUPS cascade;

drop table VCI_BASELINE_GROUP_BASELINES cascade;

drop table VCI_UPDATE_BASELINES cascade;

drop table VCI_TARGET_BASELINES cascade;

drop table VCI_TARGET_BASELINE_GROUPS cascade;

drop table VCI_AGING_SNAPSHOTS cascade;

drop table VCI_SCANHISTORY cascade;

drop table VCI_SCANRESULTS cascade;

drop table VCI_SCANRESULTS_TARGETS cascade;

drop table VCI_SCANRESULTS_BASELINES cascade;

drop table VCI_SCANHISTORY_TARGETS cascade;

drop table VCI_REMEDIATION_HISTORY cascade;

drop table VCI_TEXTFILES cascade;

drop table VCI_BUNDLE_KEYS cascade;

drop table VCI_CONTENT_KEYS cascade;

drop table VCI_PACKAGE_LOCALES cascade;

drop table VCI_LOCALES cascade;

drop table VCI_RUNNING_VC_TASKS cascade;

drop table VCI_RESTORING_TEMPLATES cascade;

drop table VCI_PARAMETERS cascade;

drop table VCI_TARGET_ENTITIES cascade;

drop table VCI_OPERATION_HISTORY cascade;

drop table VCI_OPERATION_HISTORY_SUBTASKS cascade;

drop table VCI_SCANRESULTS_CONFRESUPD cascade;

drop table VCI_TASK_STATS cascade;

drop table VCI_VC_CLEANUP_ACTION cascade;

drop table VCI_UPGRADE_OFFLINE_IDS cascade;

drop table VCI_NOTIFICATIONS cascade;

drop table VCI_RECALL_PACKAGES cascade;

drop table VCI_RECALL_UPDATES cascade;

drop table VCI_RECALL_RESOLUTIONS cascade;

drop table VCI_COMPONENT_SPEC cascade;

drop table VCI_REMEDIATEPRECHECK_RESULTS cascade;

drop table PM_OFFLINE_DEPOTS cascade;

drop table if exists PM_OFFLINE_TO_MICRO_DEPOT cascade;

drop table if exists PM_ONLINE_AND_UMDS_DEPOTS cascade;

drop table if exists PM_ONLINE_AND_UMDS_TO_MICRO_DEPOT cascade;

drop table PM_TASKS cascade;

drop table PM_DEPOT_COMPONENTS cascade;

drop table PM_DEPOT_BASE_IMAGES cascade;

drop table PM_DEPOT_ADDONS cascade;

drop table PM_DEPOT_BASE_IMAGES_COMPONENTS cascade;

drop table PM_DEPOT_ADDONS_COMPONENTS cascade;

drop table PM_SOFTWARE_COMPLIANCES cascade;

drop table PM_RECOMMENDATION_SPEC cascade;

drop table PM_RECOMMENDATION_INFO cascade;

drop table PM_TASK_NOTIFICATIONS cascade;

drop table PM_HCL_COMPLIANCES cascade;

drop table if exists PM_COORDINATOR_POLICY_INTERNAL cascade;

drop table if exists PM_DEPOT_MANIFESTS cascade;

drop table if exists PM_DEPOT_MANIFESTS_COMPONENTS cascade;

drop table if exists PM_DEPOT_MANIFESTS_REMOVED_COMPONENTS cascade;

drop table if exists PM_STORAGE_DEVICE_VCG_OVERRIDES cascade;

drop table if exists PM_HW_SUPPORT_PACKAGES cascade;

drop table if exists PM_STORAGE_DEVICE_COMPLIANCE_OVERRIDES cascade;

drop table if exists PM_HCM_HOST_ASSOC_INFO cascade;

drop table if exists PM_HCM_CLUSTER_ASSOC_INFO cascade;

drop table if exists PM_HCM_EXTENSION_SERVER_INFO cascade;

drop table if exists PM_HCM_PLUGIN_INFO cascade;

drop table if exists PM_HCM_AUTH_INFO cascade;

drop table if exists PM_SERVER_COMPLIANCE_ATTRIBUTES cascade;

drop table if exists PM_SERVER_COMPLIANCE_OVERRIDES cascade;

drop table if exists PM_PCI_DEVICE_COMPLIANCE_OVERRIDES cascade;

drop table if exists PM_PCI_DEVICE_VCG_PRODUCT_ID_OVERRIDES cascade;

drop table if exists PM_HCL_VALIDATION_RESULTS cascade;

drop trigger if exists component_existence
on PM_DEPOT_ADDONS_REMOVED_COMPONENTS;

drop function if exists check_component_existence
();

drop table PM_DEPOT_ADDONS_REMOVED_COMPONENTS cascade;

/* Drop enums  */
drop type if exists component_type cascade;

drop type if exists component_category_type cascade;

drop type if exists component_urgency_type cascade;

drop type if exists base_category_type cascade;

drop type if exists addon_category_type cascade;

drop type if exists manifest_category_type cascade;

drop type if exists online_umds_url_type cascade;

drop type if exists plugin_type cascade;


/* Drop sequences */
drop sequence VCI_UPDATES_SEQ;

drop sequence VCI_PLATFORMS_SEQ;

drop sequence VCI_PACKAGES_SEQ;

drop sequence VCI_BASELINES_SEQ;

drop sequence VCI_BASELINE_GROUPS_SEQ;

drop sequence VCI_SCANHISTORY_SEQ;

drop sequence VCI_REMEDIATION_HISTORY_SEQ;

drop sequence VCI_LANGUAGES_SEQ;

drop sequence VCI_METADATA_FILES_SEQ;

drop sequence VCI_OPERATION_HISTORY_SEQ;

drop sequence VCI_TASK_STATISTICS_SEQID;

drop sequence VCI_HOST_UPGRADES_SEQ;

drop sequence VCI_HOST_UPGRADE_PACKAGES_SEQ;

drop sequence VCI_VC_ACTION_SEQID;

drop sequence VCI_NOTIFICATIONS_SEQ;

drop sequence PM_HCM_NONCE_ID_SEQ;

drop sequence if exists PM_HCL_RESULT_ID_SEQ;

/* --------------------------- VALM schema ------------------------- */

drop table VCI_VA_APPLIANCES cascade;
drop table VCI_VA_PRODUCTS cascade;
drop table VCI_VA_UPGRADES cascade;
drop table VCI_VA_UPGRADE_BASELINES cascade;
drop table VCI_VA_CHANGELOG cascade;
drop table VCI_EULA cascade;
drop table VCI_VA_FILES cascade;
drop table VCI_VA_UPGRADE_CHANGELOG cascade;
drop table VCI_UPDATE_EULAS cascade;
drop table VCI_VA_UPGRADE_FILES cascade;
drop table VCI_PACKAGE_FILES cascade;

drop sequence VCI_VA_PRODUCTS_SEQ;
drop sequence VCI_VA_CHANGELOG_SEQ;
drop sequence VCI_EULA_SEQ;
drop sequence VCI_VA_FILES_SEQ;
drop sequence VCI_PACKAGE_FILES_SEQ;


/*
 * Delete the database stored procedures for VMware Update Manager version 4
 */

DROP FUNCTION IF EXISTS vci_populateBaselineUpdates(
    baselineId integer,
    baselineVersion integer
);

DROP FUNCTION IF EXISTS vci_compBaselineComplianceLeaf (
    targetType integer,
    targetComponent integer,
    targetCategory integer,
    targetUid varchar
);

DROP FUNCTION IF EXISTS vci_MultiBLComplianceLeafList
();

DROP FUNCTION IF EXISTS vci_expand_patches
();
DROP FUNCTION IF EXISTS vci_CheckBaselineConflict (
    targetUid varchar,
    baselineCategory integer,
    baselineId integer,
    baselineVersion integer,
    updateId integer,
    targetStatus integer
);

DROP FUNCTION IF EXISTS vci_queryEntityBLStatus (
   needLastScanTime integer,
   scanType integer,
   targetComponent integer
);

/*
 * Delete PM_LAST_APPLIED_COMMIT table and the related stored procedures,
 * triggers and enums.
 */

DROP TRIGGER IF EXISTS update_last_update_time
ON PM_LAST_APPLIED_COMMIT;

DROP FUNCTION IF EXISTS last_update_time
();

DROP TABLE IF EXISTS PM_LAST_APPLIED_COMMIT;

DROP TYPE IF EXISTS commit_types;


/**
 * Drop config related tables/procedures/sequences
 */

DROP AGGREGATE IF EXISTS config_to_json_agg(text[], config_op_type, jsonb);
DROP AGGREGATE IF EXISTS jsonb_set_agg (text [], jsonb);

DROP TRIGGER IF EXISTS update_draft_state_on_ins on PM_CLUSTER_DRAFT_TREES;
DROP TRIGGER IF EXISTS update_draft_state_on_del on PM_CLUSTER_DRAFT_TREES;

DROP FUNCTION IF EXISTS find_configs_for_host;
DROP FUNCTION IF EXISTS drop_host_from_config;
DROP FUNCTION IF EXISTS export_config;
DROP FUNCTION IF EXISTS export_draft_config;
DROP PROCEDURE IF EXISTS merge_config;
DROP PROCEDURE IF EXISTS import_config;
DROP PROCEDURE IF EXISTS drop_draft;
DROP PROCEDURE IF EXISTS clear_config_draft;
DROP PROCEDURE IF EXISTS delete_config_draft_path;
DROP PROCEDURE IF EXISTS drop_cluster_config;
DROP FUNCTION IF EXISTS commit_draft;
DROP FUNCTION IF EXISTS create_initial_draft;
DROP FUNCTION IF EXISTS create_draft;
DROP FUNCTION IF EXISTS get_host_doc;
DROP FUNCTION IF EXISTS diff_config_tree_element;
DROP FUNCTION IF EXISTS create_config_tree_element;
DROP FUNCTION IF EXISTS create_config_blob;
DROP FUNCTION IF EXISTS config_to_json;
DROP FUNCTION IF EXISTS jsonb_walk;
DROP FUNCTION IF EXISTS config_walk;
DROP FUNCTION IF EXISTS jsonb_set_recursive;
DROP FUNCTION IF EXISTS config_draft_tree_modified;
DROP PROCEDURE IF EXISTS insert_config_schema;
DROP FUNCTION IF EXISTS generate_host_specific_schema;
DROP FUNCTION IF EXISTS generate_config_schema_doc;

DROP TABLE IF EXISTS PM_CLUSTER_DRAFT_CONFLICTS;
DROP TABLE IF EXISTS PM_CLUSTER_DRAFT_TREES;
DROP TABLE IF EXISTS PM_CLUSTER_DRAFTS;
DROP TABLE IF EXISTS PM_CLUSTER_CONFIGS;
DROP TABLE IF EXISTS PM_CONFIG_COMMITS;
DROP TABLE IF EXISTS PM_CONFIG_TREES;
DROP TABLE IF EXISTS PM_CONFIG_TREE_ELEMENTS;
DROP TABLE IF EXISTS PM_CONFIG_BLOBS;
DROP TABLE IF EXISTS PM_CONFIG_SCHEMAS;

DROP TYPE IF EXISTS config_tree_diff;
DROP TYPE IF EXISTS config_op_type;
DROP TYPE IF EXISTS config_diff_type;
DROP TYPE IF EXISTS config_draft_state;
DROP TYPE IF EXISTS jsonb_walk_result;

DROP SEQUENCE IF EXISTS PM_CONFIG_COMMIT_SEQ;
DROP SEQUENCE IF EXISTS PM_CONFIG_DRAFT_SEQ;
