/* *************************************************************************
 * Copyright 2017 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Postgres upgrade script from base schema: data */
UPDATE vci_version
set db_schema_version_id=120
where db_schema_version_id=110
;

/* Mark 5.x host patches as deleted */
UPDATE vci_updates
set deleted = 1,
hidden = 1
where meta_uid like 'ESXi5%' or meta_uid like 'esxi5%' or meta_uid like 'VEM5%'
;

/* Mark all the baselines associated with host/VA upgrades as deleted */
/*
category 0 ==> Patch,
category 1 ==> Upgrade,
category 2 ==> Configuration,
category 3 ==> Extension
BaselineType Definitions can be found:
https://opengrok.eng.vmware.com/source/xref/vum-dev.perforce.1666/vum-dev/vim/vmodl/integrity/BaselineAttribute.java#36

type 0 ==>  VM
type 1 ==> HOST
type 2 ==> VA
TargetType definition can be found:
https://opengrok.eng.vmware.com/source/xref/vum-dev.perforce.1666/vum-dev/vim/vmodl/integrity/SoftwareUpdate.java#129
*/
UPDATE vci_baselines
set deleted = 1
where (type = 1 or type = 2) and category = 1
;

/* Mark all the baseline groups associated with VA upgrades as deleted */
UPDATE vci_baseline_groups
set deleted = 1
where type = 2
;

/* Mark old host/VA upgrade releases as deleted */
UPDATE vci_updates
set deleted = 1
where (type = 1 or type = 2) and category = 1
;

/* Delete all the data from host upgrade table */
DELETE from vci_host_upgrades
;
