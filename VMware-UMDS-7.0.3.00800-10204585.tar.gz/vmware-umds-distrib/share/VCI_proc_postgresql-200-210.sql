/* *************************************************************************
 * Copyright 2020 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/
/*
 * vciInstallUtils expects the file in the following format
 * @proc1.sql
 * /
 * @proc2.sql
 * /
 * ...
 * Please make sure to maintain the file format
 */
