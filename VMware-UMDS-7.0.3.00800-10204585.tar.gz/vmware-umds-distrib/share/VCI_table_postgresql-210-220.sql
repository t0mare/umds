/* *************************************************************************
 * Copyright 2020 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/*=======================================================================
 Table: PM_HW_SUPPORT_PACKAGES
 MANAGER_NAME           : Identifier of the Hardware Support Manager
 NAME                   : Name of the Hardware Support Package
 VERSION                : Version of the HSP
 BASE_IMAGE_VERSION     : Base Image Version supported by this HSP
 DESCRIPTION            : Description of the HSP
 MANIFEST_NAME          : Manifest Name, if any
 MANIFEST_VERISON       : Manifest Version, manifest name present --> manifest version present
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_HW_SUPPORT_PACKAGES (
   MANAGER_NAME         varchar(255)            NOT NULL,
   NAME                 varchar(255)            NOT NULL,
   VERSION              varchar(255)            NOT NULL,
   BASE_IMAGE_VERSION   varchar(255)            NOT NULL,
   DESCRIPTION          text                    DEFAULT '',
   MANIFEST_NAME        varchar(255),
   MANIFEST_VERSION     varchar(255),
   PRIMARY KEY (MANAGER_NAME, NAME, VERSION, BASE_IMAGE_VERSION)
);


/* Enum to describe the types of commits. */
CREATE TYPE commit_types AS ENUM( 'image',
                                  'configuration' );


/**
 * Add a column called COMMIT_TYPE and set the type to 'image' by default.
 * Since prior to this upgrade, the only user of this table was the image
 * coordinator.
 */
ALTER TABLE IF EXISTS PM_LAST_APPLIED_COMMIT
ADD COLUMN IF NOT EXISTS COMMIT_TYPE commit_types DEFAULT 'image' NOT NULL;


/* Drop the primary key on the table so that we can add a new one */
ALTER TABLE IF EXISTS PM_LAST_APPLIED_COMMIT
DROP CONSTRAINT IF EXISTS PK_PM_LAST_APPLIED_VERSION_PK;


/* Add a new primary key consisting of both the entity_id and the commit_type */
ALTER TABLE IF EXISTS PM_LAST_APPLIED_COMMIT
ADD CONSTRAINT PK_PM_LAST_APPLIED_VERSION_PK
PRIMARY KEY (ENTITY_ID, COMMIT_TYPE);


/* Add column ENABLE_HCL_VALIDATION */
ALTER TABLE PM_COORDINATOR_POLICY_OVERRIDES ADD COLUMN IF NOT EXISTS
   ENFORCE_HCL_VALIDATION bool;
