/* *************************************************************************
 * Copyright 2020-2021 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/


/*=======================================================================
 Table: PM_COORDINATOR_POLICY_INTERNAL

 ENTITY_ID            : The ID of the managed object entity for which the
                       policies are being applied.
 DROP_NFC_CONNECTION  : Keep or drop nfc connection
========================================================================*/
CREATE TABLE IF NOT EXISTS PM_COORDINATOR_POLICY_INTERNAL (
   ENTITY_ID               varchar(255)      NOT NULL,
   DROP_NFC_CONNECTION     bool              NOT NULL DEFAULT FALSE,
   PRIMARY KEY (ENTITY_ID)
);

/*==============================================================
Table: PM_ONLINE_AND_UMDS_DEPOTS

 This table is designed to expand and replace integrity.SoftwareUpdateURL
 data record stored in VUM vci_textfiles table.

 DEPOT_ID    : Identifier of online/UMDS depots (SHA-1 hash of URL)
 DESCRIPTION : Description of depots
 URL         : URL of online/UMDS depots (MUST be unique)
 URL_TYPE    : Type of URL
               Note: SoftwareUpdateURL can store multiple urlTypes, but we
                     accept only one URL_TYPE for each online/UMDS depot.
               ESX4xHostPatches: Production depots from VMware and partners
                                 (always builtin)
               ThirdPartyHostPatches: User created depots (non-builtin)
                                      or builtin depots from partners or
                                      third-party (obsolete, don't recommend
                                      to use any more)
               IntranetPatchSource: UMDS depot
               Unknown: Error case (keep here to be compatible with
                        SoftwareUpdateURL.URLType definition)
 BUILTIN     : Flag indicating if depots are created by vLCM
               0: not builtin; 1: builtin
 ENABLED     : Flag indicating if depots are enabled or disabled
               0: disabled; 1: enabled
 CREATE_TIME : When online/UMDS depots were created
 OWNER       : User who created depots
 OWNERDATA   : Private data saved by the owner. It is opaque to vLCM.
=================================================================*/

CREATE TYPE online_umds_url_type AS ENUM ('ESX4xHostPatches',
                                          'ThirdPartyHostPatches',
                                          'IntranetPatchSource',
                                          'Unknown');

CREATE TABLE IF NOT EXISTS PM_ONLINE_AND_UMDS_DEPOTS (
   DEPOT_ID                varchar(40)             PRIMARY KEY NOT NULL,
   DESCRIPTION             text                    NOT NULL DEFAULT '',
   URL                     text                    UNIQUE NOT NULL,
   URL_TYPE                online_umds_url_type    NOT NULL DEFAULT 'Unknown',
   BUILTIN                 integer                 NOT NULL DEFAULT 0,
   ENABLED                 integer                 NOT NULL DEFAULT 0,
   CREATE_TIME             timestamp               DEFAULT (now() at time zone 'utc'),
   OWNER                   varchar(255)            NOT NULL DEFAULT '',
   OWNERDATA               text                    NOT NULL DEFAULT ''
);

/**
 * Add the "owner" and "ownerdata" fields to pm_offline_depots table.
 */
ALTER TABLE IF EXISTS pm_offline_depots ADD COLUMN owner varchar(255) NOT NULL DEFAULT '';
ALTER TABLE IF EXISTS pm_offline_depots ADD COLUMN ownerdata text NOT NULL DEFAULT '';

/**
 * 1. Delete dangling records before updating foreign key constraint;
 *
 * 2. Add "ON DELETE CASCADE" to all the VUM tables which have a foreign key
 *    constraint depending on the "id" or "meta_uid" field of vci_updates table,
 *    so that we won't have to manually clean up these tables when deleting
 *    a update (bulletin).
 */
DELETE FROM vci_update_platforms WHERE update_id NOT IN (SELECT id FROM vci_updates);

ALTER TABLE IF EXISTS vci_update_platforms
DROP CONSTRAINT IF EXISTS fk_vci_updplt_ref_upd;

ALTER TABLE IF EXISTS vci_update_platforms ADD CONSTRAINT fk_vci_updplt_ref_upd
FOREIGN KEY (update_id) REFERENCES vci_updates(id) ON DELETE CASCADE;


DELETE FROM vci_scanresults_targets WHERE update_id NOT IN (SELECT id FROM vci_updates);

ALTER TABLE IF EXISTS vci_scanresults_targets
DROP CONSTRAINT IF EXISTS fk_vci_sresvms_ref_sig;

ALTER TABLE IF EXISTS vci_scanresults_targets ADD CONSTRAINT fk_vci_sresvms_ref_sig
FOREIGN KEY (update_id) REFERENCES vci_updates(id) ON DELETE CASCADE;


DELETE FROM vci_scanhistory_targets WHERE update_id NOT IN (SELECT id FROM vci_updates);

ALTER TABLE IF EXISTS vci_scanhistory_targets
DROP CONSTRAINT IF EXISTS fk_vci_shistvvms_ref_sig;

ALTER TABLE IF EXISTS vci_scanhistory_targets ADD CONSTRAINT fk_vci_shistvvms_ref_sig
FOREIGN KEY (update_id) REFERENCES vci_updates(id) ON DELETE CASCADE;


DELETE FROM vci_content_keys WHERE meta_uid NOT IN (SELECT meta_uid FROM vci_updates);

ALTER TABLE IF EXISTS vci_content_keys
DROP CONSTRAINT IF EXISTS fk_vci_contentkeys_ref_upd;

ALTER TABLE IF EXISTS vci_content_keys ADD CONSTRAINT fk_vci_contentkeys_ref_upd
FOREIGN KEY (meta_uid) REFERENCES vci_updates(meta_uid) ON DELETE CASCADE;


DELETE FROM vci_update_eulas WHERE update_id NOT IN (SELECT id FROM vci_updates);

ALTER TABLE IF EXISTS vci_update_eulas
DROP CONSTRAINT IF EXISTS fk_vci_upd_eula_ref_upd;

ALTER TABLE IF EXISTS vci_update_eulas ADD CONSTRAINT fk_vci_upd_eula_ref_upd
FOREIGN KEY (update_id) REFERENCES vci_updates(id) ON DELETE CASCADE;


DELETE FROM vci_scanresults_confresupd WHERE conflicting_update_metauid NOT IN (SELECT meta_uid FROM vci_updates);

ALTER TABLE IF EXISTS vci_scanresults_confresupd
DROP CONSTRAINT IF EXISTS fk_vci_cfresupd_ref_sig;

ALTER TABLE IF EXISTS vci_scanresults_confresupd ADD CONSTRAINT fk_vci_cfresupd_ref_sig
FOREIGN KEY (conflicting_update_metauid) REFERENCES vci_updates(meta_uid) ON DELETE CASCADE;


DELETE FROM vci_update_packages WHERE update_id NOT IN (SELECT id FROM vci_updates);

ALTER TABLE IF EXISTS vci_update_packages
DROP CONSTRAINT IF EXISTS fk_vci_updpkg_ref_upd;

ALTER TABLE IF EXISTS vci_update_packages ADD CONSTRAINT fk_vci_updpkg_ref_upd
FOREIGN KEY (update_id) REFERENCES vci_updates(id) ON DELETE CASCADE;

/*=======================================================================
Table: PM_STORAGE_DEVICE_VCG_OVERRIDES
 ENTITY_ID             : Identifier of cluster for which override is to be performed
 MODEL                  : Storage device Model
 VENDOR                 : Storage device vendor
 CAPACITY               : Capacity of Disk
 PART_NUMBER            : Hardware part number of the storage device
 FIRMWARE_VERSION       : Firmware version of the storage device that the override is applied to
 VCG_ID                 : VCG ID representing the above Info, selected by user
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_STORAGE_DEVICE_VCG_OVERRIDES (
ENTITY_ID         varchar(255)            NOT NULL,
MODEL             varchar(255)            NOT NULL,
VENDOR            varchar(255)            NOT NULL,
CAPACITY          bigint                  NOT NULL,
PART_NUMBER       varchar(255)            DEFAULT 'UNKNOWN' NOT NULL,
FIRMWARE_VERSION  varchar(255)            DEFAULT 'UNKNOWN' NOT NULL,
PRODUCT_VCG_ID    varchar(255)            NOT NULL,
PRIMARY KEY(ENTITY_ID, MODEL, VENDOR, CAPACITY, PART_NUMBER, FIRMWARE_VERSION)
);

/*=======================================================================
Table: PM_STORAGE_DEVICE_COMPLIANCE_OVERRIDES
 ENTITY_ID              : Identifier of cluster for which override is to be performed
 MODEL                  : Storage device Model
 VENDOR                 : Storage device vendor
 CAPACITY               : Capacity of Disk
 PART_NUMBER            : Hardware part number of the storage device
 FIRMWARE_VERSION       : Firmware version of the storage device that the override is applied to
 RELEASE                : vSphere release that an override must be applied to.
 COMPLIANCE_OVERRIDE     : Compliance status override for the storage device.
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_STORAGE_DEVICE_COMPLIANCE_OVERRIDES (
ENTITY_ID           varchar(255)            NOT NULL,
MODEL               varchar(255)            NOT NULL,
VENDOR              varchar(255)            NOT NULL,
CAPACITY            bigint                  NOT NULL,
PART_NUMBER         varchar(255)            DEFAULT 'UNKNOWN' NOT NULL,
FIRMWARE_VERSION    varchar(255)            DEFAULT 'UNKNOWN' NOT NULL,
RELEASE             varchar(255)            DEFAULT 'UNKNOWN' NOT NULL,
COMPLIANCE_OVERRIDE int                     NOT NULL,
PRIMARY KEY(ENTITY_ID, MODEL, VENDOR, CAPACITY, PART_NUMBER, FIRMWARE_VERSION,  RELEASE)
);
