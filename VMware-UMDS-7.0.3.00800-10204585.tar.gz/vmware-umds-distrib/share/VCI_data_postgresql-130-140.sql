/* *************************************************************************
 * Copyright 2018 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Postgres upgrade script from base schema: data */
UPDATE vci_version
set db_schema_version_id=140
where db_schema_version_id=130
;

/* Mark 6.0.0 host patches as deleted */
UPDATE vci_updates
set deleted = 1,
hidden = 1
where meta_uid like 'ESXi600%' or meta_uid like 'esxi600%'
;

/* Mark all the baselines associated with host upgrades as deleted */
/*
category 0 ==> Patch,
category 1 ==> Upgrade,
category 2 ==> Configuration,
category 3 ==> Extension
BaselineType Definitions can be found:
https://opengrok.eng.vmware.com/source/xref/vum-dev.perforce.1666/vum-dev/vim/vmodl/integrity/BaselineAttribute.java#36

type 0 ==>  VM
type 1 ==> HOST
type 2 ==> VA
TargetType definition can be found:
https://opengrok.eng.vmware.com/source/xref/vum-dev.perforce.1666/vum-dev/vim/vmodl/integrity/SoftwareUpdate.java#129
*/
UPDATE vci_baselines
set deleted = 1
where type = 1 and category = 1
;

/* Mark old host upgrade releases as deleted */
UPDATE vci_updates
set deleted = 1
where type = 1 and category = 1
;

/* Delete all the data from host upgrade table */
DELETE from vci_host_upgrades
;
