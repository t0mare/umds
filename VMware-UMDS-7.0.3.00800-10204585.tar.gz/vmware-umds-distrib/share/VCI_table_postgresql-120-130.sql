/* *************************************************************************
 * Copyright 2018 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Postgres upgrade script from base schema: tables */
/*==============================================================
 Table: VCI_BASELINE_GROUPS
    LASTUPDATED: Changing the type of the field to store timestamp.
==============================================================*/
DROP VIEW IF EXISTS VUMV_BASELINE_GROUPS;

ALTER TABLE VCI_BASELINE_GROUPS ALTER COLUMN
    LASTUPDATED TYPE timestamp;

CREATE OR REPLACE VIEW VUMV_BASELINE_GROUPS AS
SELECT BASELINE_GROUP_ID,
       VERSION,
       NAME,
       TYPE,
       DESCRIPTION,
       DELETED,
       LASTUPDATED
FROM VCI_BASELINE_GROUPS;
