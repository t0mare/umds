/* *************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Change column name from component_type to type */
ALTER TABLE PM_DEPOT_COMPONENTS RENAME COMPONENT_TYPE TO TYPE;

/* Add column message to give commit message */
ALTER TABLE PM_SOFTWARE_DESIRED_STATES ADD COLUMN IF NOT EXISTS MESSAGE TEXT;

/* Change data type for notifications to jsonb */
ALTER TABLE PM_TASKS ALTER COLUMN NOTIFICATIONS TYPE jsonb USING NOTIFICATIONS::jsonb;

/* Change default value for notifications */
ALTER TABLE PM_TASKS ALTER COLUMN NOTIFICATIONS SET DEFAULT '[]';

/* Drop default value for START_TIME */
ALTER TABLE PM_TASKS ALTER COLUMN START_TIME DROP DEFAULT;

/* Drop default value for LAST_UPDATED */
ALTER TABLE PM_TASKS ALTER COLUMN LAST_UPDATED DROP DEFAULT;

/**
 * Drop component existence check so that an addon can have removed components
 * that don't exist in PM_DEPOT_COMPONENTS table.
 */
DROP TRIGGER IF EXISTS component_existence ON PM_DEPOT_ADDONS_REMOVED_COMPONENTS CASCADE;
