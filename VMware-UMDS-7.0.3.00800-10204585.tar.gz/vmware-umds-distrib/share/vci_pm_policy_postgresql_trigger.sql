/* *************************************************************************
 * Copyright 2019-2020 VMware, Inc.   All rights reserved. -- VMware Confidential
 * ************************************************************************ */

/*
 * vci_pm_policy_trigger.sql
 *
 * A trigger to scrub out all the empty rows.
 */

CREATE OR REPLACE FUNCTION scrub_empty_policy_rows() returns TRIGGER as $$
BEGIN
    DELETE FROM PM_COORDINATOR_POLICY_OVERRIDES
    WHERE PM_COORDINATOR_POLICY_OVERRIDES IS NULL;
    RETURN NEW;
END
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS scrub_empty_policy_overrides
    ON PM_COORDINATOR_POLICY_OVERRIDES;

CREATE TRIGGER scrub_empty_policy_overrides
AFTER UPDATE ON PM_COORDINATOR_POLICY_OVERRIDES
EXECUTE PROCEDURE scrub_empty_policy_rows();
