/* *************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

CREATE SEQUENCE IF NOT EXISTS PM_SOFTWARE_DRAFTS_SEQ INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS PM_SOFTWARE_DESIRED_STATES_SEQ INCREMENT BY 1;

/*==============================================================================
ENUMERATIONS
==============================================================================*/
CREATE TYPE component_type AS ENUM ('SOLUTION',
                                    'DRIVER',
                                    'OTHER');

CREATE TYPE component_category_type AS ENUM ('SECURITY',
                                   'ENHANCEMENT',
                                   'BUGFIX',
                                   'RECALL',
                                   'RECALL_FIX',
                                   'INFO',
                                   'MISC',
                                   'GENERAL');

CREATE TYPE component_urgency_type AS ENUM ('CRITICAL',
                                  'IMPORTANT',
                                  'MODERATE',
                                  'LOW',
                                  'GENERAL');

CREATE TYPE base_category_type AS ENUM ('SECURITY',
                                        'ENHANCEMENT',
                                        'BUGFIX');

CREATE TYPE addon_category_type AS ENUM ('SECURITY',
                                        'ENHANCEMENT',
                                        'BUGFIX');
/*=======================================================================
 Table: PM_SOFTWARE_DESIRED_STATES
 DESIRED_STATE_ID       : The ID of the desired state doc
 SPEC                   : Desired state spec
 ENTITY_ID              : The ID of the managed object entity for which the
                          applied version is being tracked.
 AUTHOR                 : User who created the desired state.
 CREATE_TIME            : When the Desired state was created.
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_SOFTWARE_DESIRED_STATES  (
   DESIRED_STATE_ID         INTEGER                   NOT NULL,
   SPEC                     json                      NOT NULL,
   ENTITY_ID                varchar(255)              NOT NULL,
   AUTHOR                   varchar(255)              NOT NULL,
   CREATE_TIME              timestamp                 DEFAULT (now() at time zone 'utc'),
   CONSTRAINT PK_PM_DESIRED_STATE_ID PRIMARY KEY (DESIRED_STATE_ID),
   CONSTRAINT UK_PM_DESIRED_STATE_ENTITY_DESIRED_ID UNIQUE (ENTITY_ID, AUTHOR, CREATE_TIME)
);

/*=======================================================================
 Table: PM_SOFTWARE_DRAFTS
 DRAFT_ID               : The ID of the Draft for unique identification.
 ENTITY_ID              : The ID of the managed object entity for which the
                          applied version is being tracked.
 BASE_DESIRED_STATE     : Version of the desired state doc used to create
                          this draft
 AUTHOR                 : User who created the draft
 CREATE_TIME            : When the draft was created.
 SPEC                   : Draft spec
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_SOFTWARE_DRAFTS  (
   DRAFT_ID                 INTEGER                   NOT NULL,
   ENTITY_ID                varchar(255)              NOT NULL,
   BASE_DESIRED_STATE       int                               ,
   AUTHOR                   varchar(255)              NOT NULL,
   CREATE_TIME              timestamp                 DEFAULT (now() at time zone 'utc'),
   SPEC                     json                      NOT NULL,
   CONSTRAINT PK_PM_DRAFTS_SPEC_ID PRIMARY KEY (DRAFT_ID),
   CONSTRAINT UK_PM_DRAFT_ENTITY_AUTHOR UNIQUE (ENTITY_ID, AUTHOR)
);
/*=======================================================================
 Table: PM_DEPOT_COMPONENTS
 NAME                   : Name of the component
 VERSION                : Version of the component
 DISPLAY_NAME           : Human readable  name of the component
 DISPLAY_VERSION        : Human readable version of the component
 VENDOR                 : Vendor of the component
 COMPONENT_TYPE         : Type of the component
 SUMMARY                : Summary of the component
 DESCRIPTION            : Description of the component
 CATEGORY               : Category of the component
 URGENCY                : Urgency of the component
 CONTACT                : Contact email for the component
 RELEASE_DATE           : Release date of the component
 KB                     : Link to kb article related to the component
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_DEPOT_COMPONENTS (
   NAME                 varchar(255)            NOT NULL,
   VERSION              varchar(255)            NOT NULL,
   DISPLAY_NAME         varchar(255)            NOT NULL,
   DISPLAY_VERSION      varchar(255)            NOT NULL,
   VENDOR               varchar(255)            NOT NULL,
   COMPONENT_TYPE       component_type          NOT NULL,
   SUMMARY              varchar(255)            DEFAULT '',
   DESCRIPTION          text                    DEFAULT '',
   CATEGORY             component_category_type NOT NULL,
   URGENCY              component_urgency_type  NOT NULL,
   CONTACT              varchar(255)            DEFAULT '',
   RELEASE_DATE         timestamp               NOT NULL,
   KB                   varchar(255)            DEFAULT '',
   PRIMARY KEY (NAME, VERSION)
);

/*=======================================================================
 Table: PM_DEPOT_BASE_IMAGES
 VERSION                : Version of the base image
 DISPLAY_NAME           : Human readable name of the base image
 DISPLAY_VERSION        : Human readable version of the base image
 SUMMARY                : Summary of the base image
 DESCRIPTION            : Description of the base image
 CATEGORY               : Category of the base image
 RELEASE_DATE           : Release date of the base image
 KB                     : Link to kb article related to the base image
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_DEPOT_BASE_IMAGES (
   VERSION              varchar(255)            NOT NULL,
   DISPLAY_NAME         varchar(255)            NOT NULL,
   DISPLAY_VERSION      varchar(255)            NOT NULL,
   SUMMARY              varchar(255)            DEFAULT '',
   DESCRIPTION          text                    DEFAULT '',
   CATEGORY             base_category_type      NOT NULL,
   RELEASE_DATE         timestamp               NOT NULL,
   KB                   varchar(255)            DEFAULT '',
   PRIMARY KEY (VERSION)
);

/*=======================================================================
 Table: PM_DEPOT_BASE_IMAGES_COMPONENTS

 Junction table mapping PM_DEPOT_BASE_IMAGES and PM_DEPOT_COMPONENTS tables together.
 Used to identify the set of components the given image consists of.

 BASE_IMAGE_VERSION     : Foreign key to PM_DEPOT_BASE_IMAGES table
 COMPONENT_NAME         : Foreign key to PM_DEPOT_COMPONENTS table
 COMPONENT_VERSION      : Foreign key to PM_DEPOT_COMPONENTS table
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_DEPOT_BASE_IMAGES_COMPONENTS (
   BASE_IMAGE_VERSION   varchar(255)            NOT NULL,
   COMPONENT_NAME       varchar(255)            NOT NULL,
   COMPONENT_VERSION    varchar(255)            NOT NULL,
   PRIMARY KEY (BASE_IMAGE_VERSION, COMPONENT_NAME, COMPONENT_VERSION),
   FOREIGN KEY (BASE_IMAGE_VERSION)
      REFERENCES PM_DEPOT_BASE_IMAGES(VERSION) ON DELETE CASCADE,
   FOREIGN KEY (COMPONENT_NAME, COMPONENT_VERSION)
      REFERENCES PM_DEPOT_COMPONENTS (NAME, VERSION) ON DELETE RESTRICT
);

/*=======================================================================
 Table: PM_DEPOT_ADDONS
 NAME                   : Name of the OEM add-on
 VERSION                : Version of the OEM add-on
 DISPLAY_NAME           : Human readable name of the OEM add-on
 DISPLAY_VERSION        : Human readable version of the OEM add-on
 VENDOR                 : Vendor of the OEM add-on
 SUMMARY                : Summary of the OEM add-on
 DESCRIPTION            : Description of the OEM add-on
 CATEGORY               : Category of the OEM add-on
 RELEASE_DATE           : Release date of the OEM add-on
 KB                     : Link to kb article related to the OEM add-on
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_DEPOT_ADDONS (
   NAME                 varchar(255)            NOT NULL,
   VERSION              varchar(255)            NOT NULL,
   DISPLAY_NAME         varchar(255)            NOT NULL,
   DISPLAY_VERSION      varchar(255)            NOT NULL,
   VENDOR               varchar(255)            NOT NULL,
   SUMMARY              varchar(255)            DEFAULT '',
   DESCRIPTION          text                    DEFAULT '',
   CATEGORY             addon_category_type     NOT NULL,
   RELEASE_DATE         timestamp               NOT NULL,
   KB                   varchar(255)            DEFAULT '',
   PRIMARY KEY (NAME, VERSION)
);


/*=======================================================================
 Table: PM_DEPOT_ADDONS_COMPONENTS

 Junction table mapping PM_DEPOT_ADDONS and PM_DEPOT_COMPONENTS tables together.
 Used to identify the set of components that are being added by the given addon.

 ADDON_NAME             : Foreign key to PM_DEPOT_ADDONS table
 ADDON_VERSION          : Foreign key to PM_DEPOT_ADDONS table
 COMPONENT_NAME         : Foreign key to PM_DEPOT_COMPONENTS table
 COMPONENT_VERSION      : Foreign key to PM_DEPOT_COMPONENTS table
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_DEPOT_ADDONS_COMPONENTS (
   ADDON_NAME           varchar(255)            NOT NULL,
   ADDON_VERSION        varchar(255)            NOT NULL,
   COMPONENT_NAME       varchar(255)            NOT NULL,
   COMPONENT_VERSION    varchar(255)            NOT NULL,
   PRIMARY KEY (ADDON_NAME, ADDON_VERSION, COMPONENT_NAME, COMPONENT_VERSION),
   FOREIGN KEY (ADDON_NAME, ADDON_VERSION)
      REFERENCES PM_DEPOT_ADDONS (NAME, VERSION) ON DELETE CASCADE,
   FOREIGN KEY (COMPONENT_NAME, COMPONENT_VERSION)
      REFERENCES PM_DEPOT_COMPONENTS (NAME, VERSION) ON DELETE RESTRICT
);

/*=======================================================================
 Table: PM_DEPOT_ADDONS_REMOVED_COMPONENTS

 Junction table mapping PM_DEPOT_ADDONS and PM_DEPOT_COMPONENTS tables together.
 Used to identify the set of components that are being removed by the given addon.

 ADDON_NAME             : Foreign key to PM_DEPOT_ADDONS table
 ADDON_VERSION          : Foreign key to PM_DEPOT_ADDONS table
 COMPONENT_NAME         : Foreign key to PM_DEPOT_COMPONENTS table
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_DEPOT_ADDONS_REMOVED_COMPONENTS (
   ADDON_NAME           varchar(255)            NOT NULL,
   ADDON_VERSION        varchar(255)            NOT NULL,
   COMPONENT_NAME       varchar(255)            NOT NULL,
   PRIMARY KEY (ADDON_NAME, ADDON_VERSION, COMPONENT_NAME),
   FOREIGN KEY (ADDON_NAME, ADDON_VERSION)
      REFERENCES PM_DEPOT_ADDONS (NAME, VERSION) ON DELETE CASCADE
);

/*=======================================================================
 Table: PM_SOFTWARE_COMPLIANCES
 ENTITY_ID              : The ID of the managed object entity for which the
                          scan results is being tracked.
 SCAN_RESULT            : Scan results are stored in json
 AUTHOR                 : User who triggered scan
 DESIRED_STATE_ID       : ID of the desired state against which scan was calculated
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_SOFTWARE_COMPLIANCES  (
   ENTITY_ID                varchar(255)              NOT NULL,
   SCAN_RESULT              json                      NOT NULL,
   HW_SCAN_RESULT           json,
   HW_REMEDIATION_IMPACT    json,
   AUTHOR                   varchar(255)              NOT NULL,
   DESIRED_STATE_ID         INTEGER                   NOT NULL,
   PRIMARY KEY (ENTITY_ID),
   FOREIGN KEY (DESIRED_STATE_ID)
         REFERENCES PM_SOFTWARE_DESIRED_STATES (DESIRED_STATE_ID)
 );
