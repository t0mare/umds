/* *************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

 /*=======================================================================
 Table: PM_DEPOT_OVERRIDES
 CLUSTER_ID             : ID of the cluster
 DEPOT_OVERRIDE         : Location of Depot for the cluster
=======================================================================*/

CREATE TABLE IF NOT EXISTS PM_DEPOT_OVERRIDES (
   CLUSTER_ID           varchar(255)            NOT NULL,
   DEPOT_OVERRIDE       text                    NOT NULL,
   PRIMARY KEY (CLUSTER_ID, DEPOT_OVERRIDE)
);

/*=======================================================================
 Table: PM_RECOMMENDATION_INFO

 Table to keep all related information about recommendations of desired
 image specs

 CLUSTER_ID             : ID of the cluster
 COMMIT_ID              : Identifier of a desired image spec
 AUTHOR                 : User who checked the recommendations
 EXPLANATION_DETAILS    : Explanation of reasons such as why recoomenda-
                          tions could not be generated
 CHECK_TIME             : Time when recommendation was checked
 LAST_UPDATED_TIME      : Time when last time the row was updated
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_RECOMMENDATION_INFO (
   CLUSTER_ID           varchar(255)            NOT NULL,
   COMMIT_ID            varchar(255)            NOT NULL,
   AUTHOR               varchar(255),
   EXPLANATION_DETAILS  json,
   CHECK_TIME           timestamp               NOT NULL,
   LAST_UPDATE_TIME     timestamp               NOT NULL,
   PRIMARY KEY (CLUSTER_ID)
);

/*=======================================================================
 Table: PM_RECOMMENDATION_SPEC

 Table to keep the content of the recommendations based on desired image
 specs

 CLUSTER_ID             : ID of the cluster
 COMMIT_ID              : Identifier of a desired image spec
 SERIES_ID              : Id of the series in which the recommendation is
 CONTENT                : Software spec content of the recommended release
========================================================================*/
CREATE TABLE IF NOT EXISTS PM_RECOMMENDATION_SPEC (
   CLUSTER_ID           varchar(255)            NOT NULL,
   COMMIT_ID            varchar(255)            NOT NULL,
   KEY_NAME             varchar(255)            NOT NULL,
   CONTENT              json,
   PRIMARY KEY (CLUSTER_ID, KEY_NAME),
   FOREIGN KEY (CLUSTER_ID)
      REFERENCES PM_RECOMMENDATION_INFO (CLUSTER_ID)
         ON DELETE CASCADE
);
