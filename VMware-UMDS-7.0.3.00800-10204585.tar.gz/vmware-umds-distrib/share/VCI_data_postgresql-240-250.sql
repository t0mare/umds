/* *************************************************************************
 * Copyright 2020 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Postgres upgrade script from base schema: data */
UPDATE vci_version
set db_schema_version_id=250
where db_schema_version_id=240
