/* *************************************************************************
 * Copyright 2021 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

CREATE SEQUENCE IF NOT EXISTS PM_HCL_RESULT_ID_SEQ INCREMENT BY 1;

/*=======================================================================
Table: PM_HCL_VALIDATION_RESULTS
 ID                       : Unique identifier for this entry (auto-generated)
 ENTITY_ID                : Identifier of cluster/host where override is valid
 SPEC_ID                  : Commit ID of spec used in compliance validation
 COMPLIANCE_STATUS        : Compliance status (COMPATIBLE/INCOMPATIBLE/UNKNOWN)
 COMPLIANCE_STATUS_DETAIL : Detailed status( CERTIFIED/USER_OVERRIDE etc.)
 HARDWARE_CATEGORY        : Hardware type (SERVER/PCI_DEVICE/STORAGE_DEVICE)
 DEVICE_CLASS             : STORAGE_CONTROLLER/STORAGE_DEVICE/NIC/GPU/OTHER
 COMPLIANCE_RESULT        : Serialized compliance validation result (JSON)
                            for server, PCI device, or storage device,
                            depending on the value in the HARDWARE_CATEGORY
                            field.
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_HCL_VALIDATION_RESULTS (
ID                         int                 NOT NULL,
ENTITY_ID                  varchar(255)        NOT NULL,
SPEC_ID                    int                 NOT NULL,
COMPLIANCE_STATUS          smallint            NOT NULL,
COMPLIANCE_STATUS_DETAIL   smallint            NOT NULL,
HARDWARE_CATEGORY          smallint            NOT NULL,
DEVICE_CLASS               smallint            DEFAULT -1 NOT NULL,
COMPLIANCE_RESULT          text                NOT NULL,
PRIMARY KEY(ID)
);

/**
 * Add REBOOT_WARNING_DELAY and EMM_WARNING_DELAY columns to PM_COORDINATOR_POLICY_INTERNAL table.
 */
ALTER TABLE IF EXISTS PM_COORDINATOR_POLICY_INTERNAL ADD COLUMN REBOOT_WARNING_DELAY bigint NOT NULL DEFAULT 0,
                                                     ADD COLUMN EMM_WARNING_DELAY bigint NOT NULL DEFAULT 0;
