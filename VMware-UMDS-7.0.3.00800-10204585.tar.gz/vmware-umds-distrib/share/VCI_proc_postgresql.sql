/* *************************************************************************
 * Copyright 2016 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/*
 * vci_populateBaselineUpdates
 *
 * Given a baseline ID, calculate all the updates contained in the baseline,
 * including those from the dynamic sql and populate VCI_UPDATE_BASELINES_EXPANDED.
 * Careful!! - this procedure will truncate the existing contents of this table.
 *
 * param baselineId [in] - the baseline ID for which to calculate the contained updates
 * param baselineVersion [in] - the baseline version for which to expand the updates
 *
 * Returns the set of rows (baseline id, baseline version, update id, exclusion flag)
 * All included updates have exclusion flag = 0
 * TODO return excluded updates with exclusion flag = 1
 */

DROP FUNCTION IF EXISTS vci_populateBaselineUpdates(integer);
DROP FUNCTION IF EXISTS vci_populateBaselineUpdates(integer, integer);
CREATE FUNCTION vci_populateBaselineUpdates
(
        baselineId IN integer,
        baselineVersion IN integer
)
RETURNS void AS $$
DECLARE
        excludeSql varchar;
        dynSql varchar;
        subQuery varchar;
        querySql varchar;
        errmsg varchar;
        baselineStr varchar;
BEGIN

        baselineStr := format('%s (version %s)', baselineId, baselineVersion);

        /* expect atmost one row with dynsql for a given baseline */
        BEGIN
                SELECT dynamic_sql INTO dynSql
                FROM
                        VCI_UPDATE_BASELINES
                WHERE baseline_id = baselineId AND baseline_version = baselineVersion AND
                        search_spec IS NOT NULL;
        EXCEPTION
                WHEN NO_DATA_FOUND THEN
                        dynSql := NULL;
                /* WHEN VALUE_ERROR THEN
                        errmsg := 'Dynamic sql for baseline ' || baselineStr
                                || ' is too long to fit into pl/sql variable';
                        RAISE_APPLICATION_ERROR(-20000, errmsg, TRUE); */
                WHEN TOO_MANY_ROWS THEN
                        errmsg := 'Multiple rows returned while fetching dynamic sql for baseline ' ||
                                baselineStr || '; Expected: 1';
                        RAISE EXCEPTION USING MESSAGE=errmsg;
        END;


        excludeSql := format('(SELECT update_id FROM VCI_UPDATE_BASELINES ' ||
                             'WHERE baseline_id = %s AND baseline_version = %s ' ||
                             'AND exclude = 1)', baselineId, baselineVersion);

        /* get all the included updates after filtering out any overlapping excluded updates ... */
        querySql := format('SELECT baseline_id, baseline_version, update_id, exclude ' ||
                           'FROM VCI_UPDATE_BASELINES ' ||
                           'WHERE baseline_id = %s AND baseline_version = %s ' ||
                           'AND exclude = 0 AND update_id NOT IN %s',
                           baselineId, baselineVersion, excludeSql);

        IF dynSql IS NOT NULL THEN
        /*
         * ... union with the updates defined by the dynamic sql after filtering out any
         * overlapping excluded updates ...
         */
                subQuery := format('SELECT baseline_id, baseline_version, id, 0 ' ||
                        'FROM VCI_UPDATES, VCI_UPDATE_BASELINES ' ||
                        'WHERE baseline_id = %s AND baseline_version = %s ' ||
                        'AND id IN (%s) AND id NOT IN %s ' ||
                        'AND hidden != 1', baselineId, baselineVersion, dynSql, excludeSql);
                querySql := querySql || ' UNION ' || subQuery;
        END IF;

        DELETE FROM VCI_UPDATE_BASELINES_EXPANDED
        WHERE baseline_id = baselineId;

        BEGIN
                EXECUTE 'INSERT INTO VCI_UPDATE_BASELINES_EXPANDED ' || querySql;
        EXCEPTION
                WHEN OTHERS THEN
                        errMsg := 'Error while executing dynamic sql for expanding updates for baseline ' ||
                                baselineStr || '; Malformed dynamic sql ?';
                        RAISE EXCEPTION USING MESSAGE=errMsg;
        END;
END;
$$ LANGUAGE plpgsql;


/*
 * vci_compBaselineComplianceLeaf
 *
 * Compute the compliance status for all baselines with respect to the given
 * target leaf entity in the inventory and insert results into VCI_SCANRESULTS_BASELINES
 *
 * param targetType [in] - the baseline target type - VM (=0), HOST (=1), VA (=2)
 * param targetComponent [in] - the target component for the baseline - see
 *                              SoftwareUpdateInfo::TargetComponent.
 * param targetCategory [in] - the target category for the baseline - see
 *                             BaselineAttribute::BaselineType (Patch, Upgrade, etc.)
 * param targetUid [in] - the moid of the leaf entity whose compliance is calculated
 */

DROP FUNCTION IF EXISTS vci_compBaselineComplianceLeaf(integer, integer, integer, varchar);
CREATE FUNCTION vci_compBaselineComplianceLeaf
(
   targetType IN integer,
   targetComponent IN integer,
   targetCategory IN integer,
   targetUid IN varchar
)
RETURNS void AS $$
DECLARE
   /*
    * Update status. See BaselineManager::UpdateStatus
    */
   _Missing CONSTANT integer := 0;
   _Installed CONSTANT integer := 1;
   _NotApplicable CONSTANT integer := 2;
   _Unknown CONSTANT integer := 3;
   _Staged CONSTANT integer := 4;
   _Conflict CONSTANT integer := 5;
   _ObsoletedByHost CONSTANT integer := 6;
   _MissingPackage CONSTANT integer := 7;
   _NotInstallable CONSTANT integer := 8;
   _NewModule CONSTANT integer := 9;
   _UnsupportedUpgrade CONSTANT integer := 10;
   _IncompatibleHardware CONSTANT integer := 11;
   _ConflictingNewModule CONSTANT integer := 12;
   _InstalledRecalled CONSTANT integer := 13;
   _NotApplicableRecalled CONSTANT integer := 14;
   _PrerequisiteRecalled CONSTANT integer := 15;
   _MissingRecalled CONSTANT integer := 16;
   _NewModuleRecalled CONSTANT integer := 17;
   _PrerequisiteRecalledInstalled CONSTANT integer := 18;
   _IncompatibleSoftwareConfig CONSTANT integer := 19;

   /*
    * Baseline status. See BaselineComplianceStatus::Status
    */
   Compliant CONSTANT integer:= 0;
   NotCompliant CONSTANT integer := 1;
   UnknownComp CONSTANT integer := 2;
   Incompatible CONSTANT integer := 3;

   HOST CONSTANT integer := 1;
   HOSTGENERAL CONSTANT integer := 0;

   /* See BaselineAttribute::BaselineType */
   PATCHBL CONSTANT integer := 0;
   EXTNBL CONSTANT integer := 3;

   compUpdate CURSOR FOR
      SELECT m.compliance AS comp, m.installed AS inst, m.missing AS miss,
             m.unknown AS unk, m.notapplicable AS notapp,
             m.staged AS staged,
             m.conflict AS conflict,
             m.obsoletedbyhost AS obsoletedbyhost,
             m.misspackage AS misspackage,
             m.notinstallable AS notinstallable,
             m.newmodule AS newmodule,
             m.unsupportedupgrade AS unsupportedupgrade,
             m.incompatiblehardware AS incompatiblehardware,
             m.conflictingnewmodule AS conflictingnewmodule,
             m.installedrecalled AS installedrecalled,
             m.notapplicablerecalled AS notapplicablerecalled,
             m.prerequisiterecalled AS prerequisiterecalled,
             m.missingrecalled AS missingrecalled,
             m.newmodulerecalled AS newmodulerecalled,
             m.prerequisiterecalledinstalled AS prerequisiterecalledinstalled,
             m.incompatiblesoftwareconfig AS incompatiblesoftwareconfig,
             1 AS valid
      FROM
         VCI_SCANRESULTS_BASELINES s, VCI_MASTER_COMPLIANCE_TEMP m
      WHERE
         s.target_uid = m.target_uid AND s.baseline_id = m.baseline_id AND
         s.baseline_version = m.baseline_version
      FOR UPDATE OF
        s;

BEGIN

   /*
    * Clear out all the temp tables here so that multiple invocations don't trip us up
    * Direct DDLs are not allowed in pl/sql, so have to exec it
    */
   DROP TABLE IF EXISTS VCI_UPDATE_STATUS_TEMP;
   DROP TABLE IF EXISTS VCI_MASTER_COMPLIANCE_TEMP;

   /*
    * Get the update counts for different update statuses for all baselines from
    * SCANRESULTS_TARGETS.
    * The left outer join gives the count of zero for those baselines which don't have
    * updates of a particular status.
    *
    * Treat Staged updates as Missing for the purposes of compliance computation.
    * The unknown and not applicable updates found here are in addition to what was found
    * by other means previously
    */
   CREATE TEMPORARY TABLE VCI_UPDATE_STATUS_TEMP (baseline_id, baseline_version, target_status, updCount) AS
   SELECT id, version, status, coalesce(updCount, 0)
   FROM
      (SELECT id, version FROM VCI_BASELINES WHERE type = targetType AND
       target_component = targetComponent AND category = targetCategory AND deleted = 0) AS leftie
      CROSS JOIN
         (SELECT _Missing AS STATUS
          UNION SELECT _Installed AS STATUS
          UNION SELECT _NotApplicable AS STATUS
          UNION SELECT _Unknown AS STATUS
          UNION SELECT _Staged AS STATUS
          UNION SELECT _Conflict AS STATUS
          UNION SELECT _ObsoletedByHost AS STATUS
          UNION SELECT _MissingPackage AS STATUS
          UNION SELECT _NotInstallable AS STATUS
          UNION SELECT _NewModule AS STATUS
          UNION SELECT _UnsupportedUpgrade AS STATUS
          UNION SELECT _IncompatibleHardware AS STATUS
          UNION SELECT _ConflictingNewModule AS STATUS
          UNION SELECT _InstalledRecalled AS STATUS
          UNION SELECT _NotApplicableRecalled AS STATUS
          UNION SELECT _PrerequisiteRecalled AS STATUS
          UNION SELECT _MissingRecalled AS STATUS
          UNION SELECT _NewModuleRecalled AS STATUS
          UNION SELECT _PrerequisiteRecalledInstalled AS STATUS
          UNION SELECT _IncompatibleSoftwareConfig AS STATUS
         ) AS middie
      LEFT OUTER JOIN (
         SELECT baseline_id, baseline_version, tgt_status, COUNT(*) AS updCount
         FROM
            (SELECT be.baseline_id, be.baseline_version,
                CASE
                   /* conflicting new module is normalized to new module for Patch baseline */
                   WHEN (targetCategory = PATCHBL AND srt.target_status = _ConflictingNewModule)
                        THEN _NewModule
                   /* staged new module is Staged for extension baseline */
                   WHEN (targetCategory = EXTNBL AND srt.target_status = _NewModule AND
                         srt.additional_details IS NOT NULL AND
                         position('StagedNewModule' IN srt.additional_details) > 0)
                         THEN _Staged
                   /*
                    * If there is a depot conflict, check if the conflict is within the baseline
                    * and get the appropriate status
                    */
                   WHEN (targetType = HOST AND targetComponent = HOSTGENERAL AND
                         (targetCategory = PATCHBL OR targetCategory = EXTNBL) AND
                         (srt.target_status = _ConflictingNewModule OR srt.target_status = _Conflict))
                         THEN vci_CheckBaselineConflict(targetUid,
                                                        targetCategory,
                                                        be.baseline_id,
                                                        be.baseline_version,
                                                        srt.update_id,
                                                        srt.target_status)
                   ELSE srt.target_status
                END AS tgt_status
             FROM VCI_UPDATE_BASELINES_EXPANDED be INNER JOIN VCI_SCANRESULTS_TARGETS srt
             ON srt.target_uid = targetUid AND be.update_id = srt.update_id
            ) AS rightie
         GROUP BY
            baseline_id, baseline_version, tgt_status
      ) AS outie ON (id = baseline_id AND version = baseline_version
         AND status = tgt_status)
   ;

   /*
    * Not applicable updates are those that were downloaded before the start of
    * last scan on this target and don't figure in the scan results
    *
    * vci_GetNAUnkUpdates gives all the unknown and not applicable updates for the target.
    * Join the result with SCANRESULTS and get only those updates that were downloaded before
    * the start of scan.
    */

   EXECUTE format($exec$
   CREATE OR REPLACE TEMPORARY VIEW VCI_GETNAUNKUPDATESVIEW AS
   SELECT
      be.baseline_id, be.baseline_version, be.update_id, u.category,
      u.component, u.downloadtime
   FROM
   VCI_UPDATE_BASELINES_EXPANDED be INNER JOIN VCI_UPDATES u
      ON (be.update_id = u.id)
      LEFT OUTER JOIN VCI_SCANRESULTS_TARGETS srt
      ON (srt.update_id = u.id AND srt.target_uid = %L)
   WHERE srt.update_id IS NULL $exec$, targetUid);

   /*
    * Left outer join gives the count of zero for those baselines which don't have
    * not applicable updates
    * NOTE: These are in addition to what was determined from scan results, so just
    * add to the existing count for not applicable
    */
   UPDATE VCI_UPDATE_STATUS_TEMP vus
   SET updCount =
   (SELECT updCount + coalesce(updCountVar, 0)
    FROM
      (SELECT id, version FROM VCI_BASELINES WHERE type = targetType AND
         target_component = targetComponent AND category = targetCategory AND deleted = 0) AS leftie
       LEFT OUTER JOIN (
         SELECT mn.baseline_id AS bid,
            mn.baseline_version AS bver, count(*) AS updCountVar
         FROM
            VCI_SCANRESULTS scanResult INNER JOIN VCI_GETNAUNKUPDATESVIEW mn
            ON (scanResult.target_uid = targetUid AND
                scanResult.starttime >= mn.downloadtime AND
                scanResult.scan_type = mn.category AND
                scanResult.target_component = mn.component)
         GROUP BY
            mn.baseline_id, mn.baseline_version
       ) AS rightie ON (id = bid AND version = bver)
    WHERE vus.baseline_id = id AND vus.baseline_version = version
   )
   WHERE vus.target_status = _NotApplicable
   ;

   /*
    * Unknown updates are those that were downloaded after the start of
    * last scan on this target or all the updates in the attached baseline if there
    * was no scan done on this target.
    *
    * vci_GetNAUnkUpdates gives all the unknown and not applicable updates for the target.
    * Join the result with SCANRESULTS and get only those updates that were downloaded after
    * the start of scan or the updates for which there is no scan result.
    * Left outer join gives the count of zero for those baselines which don't have
    * unknown updates
    * NOTE: These are in addition to what was determined from scan results, so just
    * add to the existing count of Unknown
    */
   UPDATE VCI_UPDATE_STATUS_TEMP vus
   SET updCount =
   (SELECT updCount + coalesce(updCountVar, 0)
    FROM
      (SELECT id, version FROM VCI_BASELINES WHERE type = targetType AND
         target_component = targetComponent AND category = targetCategory AND deleted = 0) AS leftie
       LEFT OUTER JOIN (
         SELECT mn.baseline_id AS bid,
            mn.baseline_version AS bver, count(*) AS updCountVar
         FROM
            VCI_SCANRESULTS scanResult
            RIGHT OUTER JOIN VCI_GETNAUNKUPDATESVIEW mn
               ON (scanResult.target_uid = targetUid
                  AND scanResult.scan_type = mn.category AND
                  scanResult.target_component = mn.component)
         WHERE
            scanResult.starttime < mn.downloadtime OR scanResult.target_uid IS NULL
         GROUP BY
            scanResult.target_uid, mn.baseline_id, mn.baseline_version
      ) AS rightie ON (id = bid AND version = bver)
    WHERE vus.baseline_id = id AND vus.baseline_version = version
   )
   WHERE vus.target_status = _Unknown
   ;

   /*
    * Coalesce all the individual update status table variables into the master table
    * that counts the number of updates of each type and also keeps baseline compliance
    * Precedence is NotCompliant > Incompatible > Unknown > Compliant
    *
    * Missing, Staged, InstalledRecalled, PrerequisiteRecalledInstalled => NotCompliant
    * Conflict, MissingPackage, NewModule, UnsupportedUpgrade,
    *    IncompatibleHardware, IncompatibleSoftwareConfig  => Incompatible
    * Unknown => Unknown
    * Installed, ObsoletedByHost, NotApplicable, NotApplicableRecalled,
    * PrerequisiteRecalled, MissingRecalled, NewModuleRecalled=> Compliant
    *
    * NewModule compliance is sensitive to baseline type
    */
   CREATE TEMPORARY TABLE VCI_MASTER_COMPLIANCE_TEMP
   (target_uid, baseline_id, baseline_version, compliance,
    installed, missing, unknown, notapplicable, staged, conflict,
    obsoletedbyhost, misspackage, notinstallable, newmodule,
    unsupportedupgrade, incompatiblehardware, conflictingnewmodule,
    installedrecalled, notapplicablerecalled, prerequisiterecalled,
    missingrecalled, newmodulerecalled, prerequisiterecalledinstalled,
    incompatiblesoftwareconfig
    )
   AS SELECT targetUid, na.baseline_id, na.baseline_version,
      CASE
         WHEN miss.updCount > 0 THEN NotCompliant
         WHEN staged.updCount > 0 THEN NotCompliant
         WHEN installedrecalled.updCount > 0 THEN NotCompliant
         WHEN prerequisiterecalledinstalled.updCount > 0 THEN NotCompliant
         WHEN prerequisiterecalled.updCount > 0 THEN Incompatible
         WHEN (targetCategory = EXTNBL AND newmodule.updCount > 0) THEN NotCompliant
         WHEN misspkg.updCount > 0 THEN Incompatible
         WHEN conflict.updCount > 0 THEN Incompatible
         WHEN unsupportedupgrade.updCount > 0 THEN Incompatible
         WHEN incompatiblehardware.updCount > 0 THEN Incompatible
         WHEN notinstallable.updCount > 0 THEN Incompatible
         WHEN conflictingnewmodule.updCount > 0 THEN Incompatible
         WHEN incompatiblesoftwareconfig.updCount > 0 THEN Incompatible
         WHEN unk.updCount > 0 THEN UnknownComp
         ELSE Compliant
      END,
      inst.updCount, miss.updCount, unk.updCount, na.updCount,
      staged.updCount, conflict.updCount, obsolete.updCount, misspkg.updCount,
      notinstallable.updCount, newmodule.updCount,
      unsupportedupgrade.updCount, incompatiblehardware.updCount,
      conflictingnewmodule.updCount,
      installedrecalled.updCount, notapplicablerecalled.updCount,
      prerequisiterecalled.updCount, missingrecalled.updCount,
      newmodulerecalled.updCount, prerequisiterecalledinstalled.updCount,
      incompatiblesoftwareconfig.updCount
   FROM
      VCI_UPDATE_STATUS_TEMP na
      INNER JOIN VCI_UPDATE_STATUS_TEMP unk ON (na.baseline_id = unk.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP inst ON (unk.baseline_id = inst.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP miss ON (inst.baseline_id = miss.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP staged ON (miss.baseline_id = staged.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP conflict ON (staged.baseline_id = conflict.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP obsolete ON (conflict.baseline_id = obsolete.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP misspkg ON (obsolete.baseline_id = misspkg.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP notinstallable ON (misspkg.baseline_id = notinstallable.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP newmodule ON (notinstallable.baseline_id = newmodule.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP unsupportedupgrade ON (newmodule.baseline_id = unsupportedupgrade.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP incompatiblehardware ON (unsupportedupgrade.baseline_id = incompatiblehardware.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP conflictingnewmodule ON
            (incompatiblehardware.baseline_id = conflictingnewmodule.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP installedrecalled ON (conflictingnewmodule.baseline_id = installedrecalled.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP notapplicablerecalled ON (installedrecalled.baseline_id = notapplicablerecalled.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP prerequisiterecalled ON (notapplicablerecalled.baseline_id = prerequisiterecalled.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP missingrecalled ON (prerequisiterecalled.baseline_id = missingrecalled.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP newmodulerecalled ON (missingrecalled.baseline_id = newmodulerecalled.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP prerequisiterecalledinstalled ON (newmodulerecalled.baseline_id = prerequisiterecalledinstalled.baseline_id)
      INNER JOIN VCI_UPDATE_STATUS_TEMP incompatiblesoftwareconfig ON (prerequisiterecalledinstalled.baseline_id = incompatiblesoftwareconfig.baseline_id)
   WHERE
      na.target_status = _NotApplicable AND unk.target_status = _Unknown AND
      inst.target_status = _Installed AND miss.target_status = _Missing AND
      staged.target_status = _Staged AND conflict.target_status = _Conflict AND
      obsolete.target_status = _ObsoletedByHost AND
      misspkg.target_status = _MissingPackage AND
      notinstallable.target_status = _NotInstallable AND
      newmodule.target_status = _NewModule AND
      unsupportedupgrade.target_status = _UnsupportedUpgrade AND
      incompatiblehardware.target_status = _IncompatibleHardware AND
      conflictingnewmodule.target_status = _ConflictingNewModule AND
      installedrecalled.target_status = _InstalledRecalled AND
      notapplicablerecalled.target_status = _NotApplicableRecalled AND
      prerequisiterecalled.target_status = _PrerequisiteRecalled AND
      missingrecalled.target_status = _MissingRecalled AND
      newmodulerecalled.target_status = _NewModuleRecalled AND
      prerequisiterecalledInstalled.target_status = _PrerequisiteRecalledInstalled AND
      incompatiblesoftwareconfig.target_status = _IncompatibleSoftwareConfig
   ;
   CREATE UNIQUE INDEX ON VCI_MASTER_COMPLIANCE_TEMP ( target_uid, baseline_id, baseline_version );

   /*
    * Insert compliance of new target-baseline combo into VCI_SCANRESULTS_BASELINES
    */
   INSERT INTO VCI_SCANRESULTS_BASELINES
      (baseline_id, baseline_version, target_uid, target_status,
      compliant_upd, noncompliant_upd, unknown_upd, not_applicable_upd,
      staged_upd, conflict_upd, obsoletedbyhost_upd, misspackage_upd, notinstallable_upd,
      newmodule_upd, unsupportedupgrade_upd, incompatiblehardware_upd,
      conflictingnewmodule_upd, installedrecalled_upd, notapplicablerecalled_upd,
      prerequisiterecalled_upd, missingrecalled_upd,
      newmodulerecalled_upd, prereqrecalledinstalled_upd,
      incompatiblesoftwareconfig_upd, isvalid
      )

   SELECT m.baseline_id, m.baseline_version, m.target_uid, m.compliance,
          m.installed, m.missing, m.unknown, m.notapplicable, m.staged,
          m.conflict, m.obsoletedbyhost, m.misspackage, m.notinstallable,
          m.newmodule, m.unsupportedupgrade, m.incompatiblehardware,
          m.conflictingnewmodule, m.installedrecalled,
          m.notapplicablerecalled, m.prerequisiterecalled, m.missingrecalled,
          m.newmodulerecalled, m.prerequisiterecalledinstalled,
          m.incompatiblesoftwareconfig, 1
   FROM
      VCI_MASTER_COMPLIANCE_TEMP m LEFT OUTER JOIN VCI_SCANRESULTS_BASELINES s
      ON m.target_uid = s.target_uid AND m.baseline_id = s.baseline_id
         AND m.baseline_version = s.baseline_version
   WHERE
      s.target_uid IS NULL AND s.baseline_id IS NULL AND s.baseline_version IS NULL
   ;

   /*
    * Update the compliance of existing target-baseline combo in VCI_SCANRESULTS_BASELINES
    */
   FOR row1 IN compUpdate LOOP
      UPDATE VCI_SCANRESULTS_BASELINES
      SET target_status = row1.comp, compliant_upd = row1.inst,
          noncompliant_upd = row1.miss,
          unknown_upd = row1.unk, not_applicable_upd = row1.notapp,
          staged_upd = row1.staged,
          conflict_upd = row1.conflict,
          obsoletedbyhost_upd = row1.obsoletedbyhost,
          misspackage_upd = row1.misspackage,
          notinstallable_upd = row1.notinstallable,
          newmodule_upd = row1.newmodule,
          unsupportedupgrade_upd = row1.unsupportedupgrade,
          incompatiblehardware_upd = row1.incompatiblehardware,
          conflictingnewmodule_upd = row1.conflictingnewmodule,
          installedrecalled_upd = row1.installedrecalled,
          notapplicablerecalled_upd = row1.notapplicablerecalled,
          prerequisiterecalled_upd = row1.prerequisiterecalled,
          missingrecalled_upd = row1.missingrecalled,
          newmodulerecalled_upd = row1.newmodulerecalled,
          prereqrecalledinstalled_upd = row1.prerequisiterecalledinstalled,
          incompatiblesoftwareconfig_upd = row1.incompatiblesoftwareconfig,
          isvalid = row1.valid
      WHERE CURRENT OF compUpdate;
   END LOOP;

   DROP TABLE VCI_UPDATE_STATUS_TEMP, VCI_MASTER_COMPLIANCE_TEMP;
   DROP VIEW VCI_GETNAUNKUPDATESVIEW;
END;
$$ LANGUAGE plpgsql;


/*
 * vci_compMultiBaselineComplianceLeafList
 *
 * Compute the compliance status for a set of baselines with respect to the given
 * target leaf entities in the inventory and insert results into
 * #vci_storedproc_inoutlist_temp
 *
 * The input parameters and output results are all in #vci_storedproc_inoutlist_temp
 *
 * Inputs are rows of (id, target_uid) in #vci_storedproc_inoutlist_temp for all
 * the baseline ids and target uids.
 *
 * The output results are written back to the same table,
 * with a row for each target uid , its compliance status and aggregate update counts
 * for all the baselines.
 *
 */

DROP FUNCTION IF EXISTS vci_MultiBLComplianceLeafList();
CREATE FUNCTION vci_MultiBLComplianceLeafList()
RETURNS void AS $$
DECLARE

   /*
    * Initialize update and compliance status constants.
    * See BaselineManager::UpdateStatus and BaselineComplianceStatus::Status
    */
   _MISSING CONSTANT integer := 0;
   _INSTALLED CONSTANT integer := 1;
   _NOTAPPLICABLE_UPDATE CONSTANT integer := 2;
   _UNKNOWN_UPDATE CONSTANT integer := 3;
   _STAGED CONSTANT integer := 4;
   _CONFLICT CONSTANT integer := 5;
   _OBSOLETEDBYHOST CONSTANT integer := 6;
   _MISSINGPACKAGE CONSTANT integer := 7;
   _NOTINSTALLABLE CONSTANT integer := 8;
   _NEWMODULE CONSTANT integer := 9;
   _UNSUPPORTEDUPGRADE CONSTANT integer := 10;
   _INCOMPATIBLEHW CONSTANT integer := 11;
   _CONFLICTINGNEWMODULE CONSTANT integer := 12;
   _INSTALLEDRECALLED CONSTANT integer := 13;
   _NOTAPPLICABLERECALLED CONSTANT integer := 14;
   _PREREQUISITERECALLED CONSTANT integer := 15;
   _MISSINGRECALLED CONSTANT integer := 16;
   _NEWMODULERECALLED CONSTANT integer := 17;
   _PREREQUISITERECALLEDINSTALLED CONSTANT integer := 18;
   _INCOMPATIBLESWCFG CONSTANT integer := 19;

   COMPLIANT CONSTANT integer:= 0;
   NOTCOMPLIANT CONSTANT integer := 1;
   UNKNOWN_COMPLIANCE_STATUS CONSTANT integer := 2;
   INCOMPATIBLE CONSTANT integer := 3;

   /* See BaselineAttribute::BaselineType */
   PATCHBL CONSTANT integer := 0;
   EXTNBL CONSTANT integer := 3;

   targetuid         vci_scanresults.target_uid%type;
   missCnt           integer := 0;
   installedCnt      integer := 0;
   stagedCnt         integer := 0;
   unknownCnt        integer := 0;
   notApplicableCnt  integer := 0;
   conflictCnt       integer := 0;
   obsoletedCnt      integer := 0;
   missingPkgCnt     integer := 0;
   notInstallableCnt integer := 0;
   newModuleCnt      integer := 0;
   unsupportedCnt    integer := 0;
   incompatibleCnt   integer := 0;
   conflictingnmCnt  integer := 0;
   installedrecalledCnt  integer := 0;
   notapplicablerecalledCnt  integer := 0;
   prerequisiterecalledCnt  integer := 0;
   missingrecalledCnt  integer := 0;
   newmodulerecalledCnt  integer := 0;
   prereqrecalledinstalledCnt  integer := 0;
   incompatibleSwCfgCnt integer := 0;

   totalUpdateCnt   integer := 0;

   baselineCategory integer := 0;

   /*
    * Get NotApplicable Counts for Entities if they have some
    * 1. find all update id which does not have anything in vci_scanresults_targets
    * 2. out of which, only these last scan time >= update downloadtime are
    *    not applicable.
    *
    */
   notApplicableCntCursor CURSOR FOR
      SELECT tmp.target_uid,
             coalesce(count(DISTINCT bu.update_id), 0) notApplicableCnt
      FROM VCI_SCANRESULTS scanResult, VCI_STOREDPROC_INOUTLIST_TEMP tmp,
           VCI_BASELINES_UPDATES_TEMP bu
      WHERE
           NOT EXISTS (
               SELECT 1
               FROM VCI_SCANRESULTS_TARGETS srt
               WHERE
                  srt.update_id = bu.update_id
                  AND srt.target_uid = tmp.target_uid
           )
           AND scanResult.target_uid = tmp.target_uid
           AND scanResult.target_component = bu.update_component
           AND scanResult.scan_type = bu.update_category
           AND scanResult.starttime >= bu.update_downloadtime
      GROUP BY tmp.target_uid;


    /*
     * query to figure out all other counts
     * Missing and Conflict updates will become New Module for a patch baseline
     *  if the update nature is not null and equals HOSTEXTENSION
     */
    allCntCursor CURSOR FOR
         SELECT
         res.target_uid,
         coalesce(sum(CASE
            WHEN (res.target_status = _MISSING) THEN 1
            ELSE 0
            END), 0) missCnt ,
         coalesce(sum(CASE
            WHEN (res.target_status = _INSTALLED) THEN 1
            ELSE 0
            END), 0) installedCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _STAGED OR
                  /* NewModule + staged = Staged for Extension baseline */
                  (baselineCategory = EXTNBL AND res.target_status = _NEWMODULE AND
                   res.additional_details LIKE '%StagedNewModule%'))
                   THEN 1
            ELSE 0
            END), 0) stagedCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _UNKNOWN_UPDATE) THEN 1
            ELSE 0
            END), 0) unknownCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _NOTAPPLICABLE_UPDATE) THEN 1
            ELSE 0
            END), 0) notApplicableCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _CONFLICT) THEN 1
            ELSE 0
            END), 0) conflictCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _OBSOLETEDBYHOST) THEN 1
            ELSE 0
            END), 0) obsoletedCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _MISSINGPACKAGE) THEN 1
            ELSE 0
            END), 0) missingPkgCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _NOTINSTALLABLE) THEN 1
            ELSE 0
            END), 0) notInstallableCnt,
         coalesce(sum(CASE
            /* (NewModule and PatchBL) OR (NewModule and ExtnBL and !StagedNewModule) */
            WHEN ((baselineCategory = PATCHBL AND res.target_status = _NEWMODULE) OR
                  (baselineCategory = EXTNBL AND res.target_status = _NEWMODULE AND
                  /* If a column like additional_details is null,
                   * operator NOT LIKE (with any string) will always return false,
                   * add 'IS NULL' check to handle the NULL value in additional_details column.
                   */
                   (res.additional_details IS NULL OR
                   res.additional_details NOT LIKE '%StagedNewModule%')) OR
                  /* conflicting new module is normalized to new module for Patch BL */
                  (baselineCategory = PATCHBL AND res.target_status = _CONFLICTINGNEWMODULE))
                  THEN 1
            ELSE 0
            END), 0) newModuleCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _UNSUPPORTEDUPGRADE) THEN 1
            ELSE 0
            END), 0) unsupportedCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _INCOMPATIBLEHW) THEN 1
            ELSE 0
            END), 0) incompatibleCnt,
         coalesce(sum(CASE
            /* for patch BL, conflictingnewmodule is already accounted in newmodule */
            WHEN (baselineCategory = EXTNBL AND res.target_status = _CONFLICTINGNEWMODULE)
            THEN 1
            ELSE 0
            END), 0) conflictingnmCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _INSTALLEDRECALLED) THEN 1
            ELSE 0
            END), 0) installedrecalledCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _NOTAPPLICABLERECALLED) THEN 1
            ELSE 0
            END), 0) notapplicablerecalledCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _PREREQUISITERECALLED) THEN 1
            ELSE 0
            END), 0) prerequisiterecalledCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _MISSINGRECALLED) THEN 1
            ELSE 0
            END), 0) missingrecalledCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _NEWMODULERECALLED) THEN 1
            ELSE 0
            END), 0) newmodulerecalledCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _PREREQUISITERECALLEDINSTALLED) THEN 1
            ELSE 0
            END), 0) prereqrecalledinstalledCnt,
         coalesce(sum(CASE
            WHEN (res.target_status = _INCOMPATIBLESWCFG) THEN 1
            ELSE 0
            END), 0) incompatibleSwCfgCnt
        FROM
        (
            /*
             * First select the distinct updates and then apply the baseline conflict check,
             * otherwise the counts will be messed up.
             * The baseline conflict check is only for conflict updates in a patch baseline
             * and conflict/conflictingnewmodule update in an extension baseline.
             */
            SELECT target_uid, update_id,
               CASE
                  WHEN ((baselineCategory = PATCHBL AND target_status = _CONFLICT) OR
                        (baselineCategory = EXTNBL AND
                        (target_status = _CONFLICT OR target_status = _CONFLICTINGNEWMODULE)))
                   THEN vci_CheckBaselineConflict(target_uid,
                                                  baselineCategory,
                                                  -1,
                                                  -1,
                                                  update_id,
                                                  target_status)
               ELSE
                   target_status
               END AS target_status,
               additional_details
            FROM
            (
                /* The list of target_uids from tmp table will be unique by now */
                SELECT tmp.target_uid, bu.update_id, srt.target_status,
                   srt.additional_details
                FROM
                   VCI_BASELINES_UPDATES_TEMP bu, VCI_STOREDPROC_INOUTLIST_TEMP tmp,
                   vci_scanresults_targets srt
                WHERE
                   bu.update_id = srt.update_id AND srt.target_uid = tmp.target_uid
            ) AS heck
        ) res
    GROUP BY res.target_uid;

BEGIN

   /*
    * All baselines passed in are of same category, so get the category of first
    * baseline. We will need it for patch baseline and new module handling.
    */
   SELECT b.category INTO baselineCategory
   FROM VCI_BASELINES b, VCI_STOREDPROC_INOUTLIST_TEMP tmp
   WHERE b.id = tmp.id limit 1;

   /*
    * obtain a list of unique updates involved in the baselines
    * in case of multipe vms, vci_storedproc_inoutlist_temp should have
    * multiple target_uid with the same baselines, so we do select
    * distinct.
    */
   DROP TABLE IF EXISTS VCI_BASELINES_UPDATES_TEMP;
   CREATE TEMPORARY TABLE VCI_BASELINES_UPDATES_TEMP
   (update_id, update_component, update_category, update_downloadtime) AS
      SELECT DISTINCT up.id, up.component, up.category, up.downloadtime
      FROM vci_updates up,
           vci_update_baselines_expanded be
      WHERE be.update_id = up.id AND be.baseline_id IN
            (SELECT DISTINCT(tmp.id) FROM VCI_STOREDPROC_INOUTLIST_TEMP tmp);

   GET DIAGNOSTICS totalUpdateCnt = ROW_COUNT;


   /*
    * remove all duplicate target_uids from temp table, now that we got all
    * baseline information.
    */
   DELETE FROM VCI_STOREDPROC_INOUTLIST_TEMP
   WHERE EXISTS (
      SELECT 1 FROM VCI_STOREDPROC_INOUTLIST_TEMP tmp
      WHERE tmp.target_uid = VCI_STOREDPROC_INOUTLIST_TEMP.target_uid
      AND tmp.id > VCI_STOREDPROC_INOUTLIST_TEMP.id
   );

   /*
    * initialize target uid, status and all counts to 0.
    */
   UPDATE VCI_STOREDPROC_INOUTLIST_TEMP SET
   id = NULL, target_status = NULL,
   missing = 0, staged = 0, installed = 0, unknown = 0, notapplicable = 0,
   conflict = 0, obsoletedbyhost = 0, missingpackage = 0, notinstallable = 0,
   newmodule = 0, unsupportedupgrade = 0, incompatiblehw = 0, conflictingnm = 0,
   installedrecalled = 0, notapplicablerecalled = 0, prerequisiterecalled = 0,
   missingrecalled = 0, newmodulerecalled = 0, prerequisiterecalledinstalled = 0,
   incompatibleswcfg = 0;


   OPEN notApplicableCntCursor;
   LOOP
      FETCH notApplicableCntCursor INTO targetuid, notApplicableCnt;
      EXIT WHEN NOT FOUND;
      UPDATE VCI_STOREDPROC_INOUTLIST_TEMP
      SET notapplicable = notapplicable + notApplicableCnt
      WHERE target_uid = targetuid;
   END LOOP;
   CLOSE notApplicableCntCursor;
   notApplicableCnt := 0;

   OPEN allCntCursor;
   LOOP
      FETCH allCntCursor
      INTO  targetuid, missCnt, installedCnt, stagedCnt, unknownCnt,
            notApplicableCnt, conflictCnt, obsoletedCnt, missingPkgCnt,
            notInstallableCnt, newModuleCnt, unsupportedCnt, incompatibleCnt,
            conflictingnmCnt, installedrecalledCnt, notapplicablerecalledCnt,
            prerequisiterecalledCnt, missingrecalledCnt, newmodulerecalledCnt,
            prereqrecalledinstalledCnt, incompatibleSwCfgCnt;
      EXIT WHEN NOT FOUND;
      UPDATE VCI_STOREDPROC_INOUTLIST_TEMP SET
            missing = missing + missCnt,
            staged = staged + stagedCnt,
            installed = installed + installedCnt,
            unknown = unknown + unknownCnt,
            notapplicable = notapplicable + notApplicableCnt,
            conflict = conflict + conflictCnt,
            obsoletedbyhost = obsoletedbyhost + obsoletedCnt,
            missingpackage = missingpackage + missingPkgCnt,
            notinstallable = notinstallable + notInstallableCnt,
            newmodule = newmodule + newModuleCnt,
            unsupportedupgrade = unsupportedupgrade + unsupportedCnt,
            incompatiblehw = incompatiblehw + incompatibleCnt,
            conflictingnm = conflictingnm + conflictingnmCnt,
            installedrecalled = installedrecalled + installedrecalledCnt,
            notapplicablerecalled = notapplicablerecalled + notapplicablerecalledCnt,
            prerequisiterecalled = prerequisiterecalled + prerequisiterecalledCnt,
            missingrecalled = missingrecalled + missingrecalledCnt,
            newmodulerecalled = newmodulerecalled + newmodulerecalledCnt,
            prerequisiterecalledinstalled = prerequisiterecalledinstalled + prereqrecalledinstalledCnt,
            incompatibleswcfg = incompatibleswcfg + incompatibleswcfgCnt
       WHERE
            target_uid = targetuid;
   END LOOP;
   CLOSE allCntCursor;

   /*
    * calculate unknown count
    */
   UPDATE VCI_STOREDPROC_INOUTLIST_TEMP
   SET unknown = unknown +
         (totalUpdateCnt -
         (missing + staged +
          installed + unknown + notapplicable +
          conflict + obsoletedbyhost + missingpackage +
          notinstallable + newmodule + unsupportedupgrade +
          incompatiblehw + conflictingnm + installedrecalled +
          notapplicablerecalled + prerequisiterecalled +
          missingrecalled + newmodulerecalled + prerequisiterecalledinstalled +
          incompatibleswcfg))
   WHERE
         (missing + staged +
          installed + unknown + notapplicable +
          conflict + obsoletedbyhost + missingpackage +
          notinstallable + newmodule + unsupportedupgrade +
          incompatiblehw + conflictingnm + installedrecalled +
          notapplicablerecalled + prerequisiterecalled +
          missingrecalled + newmodulerecalled + prerequisiterecalledinstalled +
          incompatibleswcfg)
         < totalUpdateCnt;



   /*
    * calculate compliance status
    */
   UPDATE VCI_STOREDPROC_INOUTLIST_TEMP
   SET target_status = (
             CASE
               WHEN (missing + staged + installedrecalled
                     + prerequisiterecalledinstalled > 0) THEN NOTCOMPLIANT
               WHEN (baselineCategory = EXTNBL AND newmodule > 0) THEN NOTCOMPLIANT
               WHEN (conflict + missingpackage +
                     notinstallable + unsupportedupgrade + incompatiblehw
                     + conflictingnm + prerequisiterecalled
                     + incompatibleswcfg) > 0 THEN INCOMPATIBLE
               WHEN unknown > 0 THEN UNKNOWN_COMPLIANCE_STATUS
               ELSE COMPLIANT
             END );

   DROP TABLE VCI_BASELINES_UPDATES_TEMP;
END;
$$ LANGUAGE plpgsql;

/*
 * vci_CheckBaselineConflict
 *
 * This function takes a baseline id, update id and the current status of the update
 * and checks whether the update's depot conflict is actually an in-baseline conflict.
 * It first checks whether the update id has host conflicts. If so, the current status
 * is returned.
 * If the update only has a depot conflict, it checks whether any of the conflicting
 * updates are present in the baseline id. If so, it will return the current status,
 * else it returns the update as either Missing or New Module
 */

DROP FUNCTION IF EXISTS vci_CheckBaselineConflict(varchar, integer, integer, integer, integer, integer);
CREATE FUNCTION vci_CheckBaselineConflict
(
   targetUid varchar,
   baselineCategory integer,
   baselineId integer,
   baselineVersion integer,
   updateId integer,
   targetStatus integer
)
RETURNS integer AS $$
DECLARE
   MISSING CONSTANT integer := 0;
   CONFLICT CONSTANT integer := 5;
   NEWMODULE CONSTANT integer := 9;
   CONFLICTINGNEWMODULE CONSTANT integer := 12;
   HOST_CONFLICT CONSTANT integer := 1;
   DEPOT_CONFLICT CONSTANT integer := 2;
   HOST_CONFLICT_INDIRECT CONSTANT integer := 3;
   DEPOT_CONFLICT_INDIRECT CONSTANT integer := 4;
   EXTN_BL CONSTANT integer := 3;
   conflictCount integer;
   returnStatus integer;
BEGIN
   returnStatus := targetStatus;

   /*
    * If there are no host conflicts for the update, check for depot conflicts within the given baseline.
    */
   SELECT COUNT(1) INTO conflictCount
   FROM VCI_UPDATE_CONFLICT_INFO uc
   WHERE input_id = updateId AND target_uid = targetUid AND
      (conflict_type = HOST_CONFLICT OR conflict_type = HOST_CONFLICT_INDIRECT);

   IF conflictCount = 0
   THEN
      /*
       * If depot conflicting updates are not in the updates for given baseline,
       * then there is no conflict. It's either Missing or NewModule status
       */

      /*
       * multi baseline case. The updates in vci_baselines_updates_temp are the
       * total set of updates to check */
      IF baselineId = -1
      THEN
        SELECT COUNT(1) INTO conflictCount
        FROM
           VCI_UPDATE_CONFLICT_INFO uci INNER JOIN VCI_BASELINES_UPDATES_TEMP bu
           ON uci.target_uid = targetUid AND uci.input_id = updateId
              AND uci.conflicts_with_id = bu.update_id
              AND (uci.conflict_type = DEPOT_CONFLICT OR uci.conflict_type = DEPOT_CONFLICT_INDIRECT)
           INNER JOIN VCI_SCANRESULTS_TARGETS srt
           ON srt.target_uid = targetUid AND srt.update_id = uci.conflicts_with_id
              AND ((srt.target_status <> CONFLICTINGNEWMODULE AND srt.target_status <> NEWMODULE)
                   OR baselineCategory = EXTN_BL);
      ELSE
         /*
          * Invoked for a single baseline
          */
         SELECT COUNT(1) INTO conflictCount
         FROM
             VCI_UPDATE_CONFLICT_INFO uci INNER JOIN VCI_UPDATE_BASELINES_EXPANDED ube
                  ON ube.baseline_id = baselineId AND ube.baseline_version = baselineVersion
               AND uci.target_uid = targetUid AND uci.conflicts_with_id = ube.update_id
               AND uci.input_id = updateId
               AND (uci.conflict_type = DEPOT_CONFLICT OR uci.conflict_type = DEPOT_CONFLICT_INDIRECT)
             INNER JOIN VCI_SCANRESULTS_TARGETS srt
             ON srt.target_uid = targetUid AND srt.update_id = uci.conflicts_with_id
                AND ((srt.target_status <> CONFLICTINGNEWMODULE AND srt.target_status <> NEWMODULE)
                     OR baselineCategory = EXTN_BL);
      END IF;

      IF conflictCount = 0
      THEN
         IF targetStatus = CONFLICT THEN
            returnStatus := MISSING;
         ELSE
            returnStatus := NEWMODULE;
         END IF;
      END IF;
   END IF;

   /* Retain the original @targetStatus for all other cases since we cannot resolve conflicts */
   RETURN returnStatus;
END;
$$ LANGUAGE plpgsql;


/*
 * vci_getEntityBaselineComplianceStatus
 *
 *
 * The input parameters are in
 * vci_storedproc_inlist_temp(
 *                             target_uid varchar(256),
 *                             baseline_id int)
 * The output parameters are in
 * vci_storedproc_outlist_temp(
 *                              target_uid varchar(256),
 *                              last_scan datetime,
 *                              baseline_id int,
 *                              baseline_status int)
 *
 *
 * Inputs are rows of baseline_id for all the baselines and target_uid
 * for all the target uids.
 *
 *
 * The output results are written back to the same table,
 * with a row for each target uid , its compliance status and aggregate update counts
 * for all the baselines.
 *
 * @param needLastScanTime [in] - indicate whether last scan time should also returned.
 * 1 means last scan time is needed and 0 otherwise.
 * @param scanType [in] - the scan type.
 * @param targetComponent [in] - the target component of the scan
 */

DROP FUNCTION IF EXISTS vci_queryEntityBLStatus(integer, integer, integer);
CREATE FUNCTION vci_queryEntityBLStatus
(
   needLastScanTime IN integer,
   scanType IN integer,
   targetComponent IN integer
)
RETURNS void AS $$
BEGIN

   DROP TABLE IF EXISTS VCI_BASELINES_TEMP;

   CREATE TEMPORARY TABLE VCI_BASELINES_TEMP AS
   SELECT baseline_id FROM VCI_STOREDPROC_INLIST_TEMP;

   IF (needLastScanTime = 0) THEN
         INSERT INTO VCI_STOREDPROC_OUTLIST_TEMP(target_uid, baseline_id, baseline_status)
         SELECT scan_bl.target_uid, scan_bl.baseline_id, scan_bl.target_status
         FROM
         VCI_SCANRESULTS_BASELINES scan_bl
         INNER JOIN VCI_STOREDPROC_INLIST_TEMP tmpin
         ON (scan_bl.target_uid = tmpin.target_uid)
         INNER JOIN VCI_BASELINES_TEMP bltmp
         ON (scan_bl.baseline_id = bltmp.baseline_id)
         INNER JOIN VCI_BASELINES bl
         ON (scan_bl.baseline_id = bl.id AND scan_bl.baseline_version = bl.version)
         WHERE scan_bl.isvalid = 1 AND bl.deleted = 0;
   ELSE
         INSERT INTO VCI_STOREDPROC_OUTLIST_TEMP(target_uid, baseline_id, baseline_status, last_scan)
         SELECT scan_bl.target_uid, scan_bl.baseline_id, scan_bl.target_status,
         (CASE WHEN (scan_res.scan_type = scanType AND scan_res.target_component = targetComponent)
                  THEN scan_res.starttime
               WHEN (scan_res.scan_type = scanType AND targetComponent = -1)
                  THEN scan_res.starttime
               ELSE NULL
          END)
         FROM
         VCI_SCANRESULTS_BASELINES scan_bl
         INNER JOIN VCI_STOREDPROC_INLIST_TEMP tmpin
         ON (scan_bl.target_uid = tmpin.target_uid)
         INNER JOIN VCI_BASELINES_TEMP bltmp
         ON (scan_bl.baseline_id = bltmp.baseline_id)
         INNER JOIN VCI_BASELINES bl
         ON (scan_bl.baseline_id = bl.id
             AND scan_bl.baseline_version = bl.version
             AND scan_bl.isvalid = 1
             AND bl.deleted = 0)
         LEFT OUTER JOIN vci_scanresults scan_res
         ON (scan_bl.target_uid = scan_res.target_uid);

   END IF;
   DROP TABLE VCI_BASELINES_TEMP;
END;
$$ LANGUAGE plpgsql;
