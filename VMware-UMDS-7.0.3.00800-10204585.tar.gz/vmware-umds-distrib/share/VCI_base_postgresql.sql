/* *************************************************************************
 * Copyright 2016 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/*==============================================================
 VCI_postgresql.sql
 DBMS name:      PostgreSQL 9.2
==============================================================*/

/* This base version is the same schema as VUM 6.0.0 80-90 */

/* Sequences */

CREATE SEQUENCE VCI_UPDATES_SEQ;

CREATE SEQUENCE VCI_PLATFORMS_SEQ;

CREATE SEQUENCE VCI_PACKAGES_SEQ;

CREATE SEQUENCE VCI_BASELINES_SEQ;

CREATE SEQUENCE VCI_SCANHISTORY_SEQ;

CREATE SEQUENCE VCI_REMEDIATION_HISTORY_SEQ;

CREATE SEQUENCE VCI_LANGUAGES_SEQ;

CREATE SEQUENCE VCI_BASELINE_GROUPS_SEQ;

CREATE SEQUENCE VCI_METADATA_FILES_SEQ;

CREATE SEQUENCE VCI_OPERATION_HISTORY_SEQ;

CREATE SEQUENCE VCI_TASK_STATISTICS_SEQID;

CREATE SEQUENCE VCI_HOST_UPGRADES_SEQ;

CREATE SEQUENCE VCI_VC_ACTION_SEQID;

CREATE SEQUENCE VCI_EULA_SEQ;

CREATE SEQUENCE VCI_VA_FILES_SEQ;

CREATE SEQUENCE VCI_VA_CHANGELOG_SEQ;

CREATE SEQUENCE VCI_VA_PRODUCTS_SEQ;

CREATE SEQUENCE VCI_PACKAGE_FILES_SEQ;

CREATE SEQUENCE VCI_NOTIFICATIONS_SEQ;

CREATE SEQUENCE VCI_HOST_UPGRADE_PACKAGES_SEQ;


/*==============================================================
 Table: VCI_VERSION
 VERSION_ID: VMware Update Manager version
 VERSION_STRING: VMware Update Manager Version string
 DB_SCHEMA_VERSION_ID: VMware Update Manager database schema version
=============================================================nex=*/
CREATE TABLE VCI_VERSION  (
   VERSION_ID              integer                        ,
   VERSION_STRING          varchar(255)                   NOT NULL,
   DB_SCHEMA_VERSION_ID    integer                        NOT NULL,
   CONSTRAINT PK_VCI_VERSION PRIMARY KEY (VERSION_ID, DB_SCHEMA_VERSION_ID)
);

/*==============================================================
 Table: VCI_UPDATES

   ID                     Unique Id; generated sequence number
   TYPE                   VM (=0), HOST (=1), or VA (=2)
   TITLE                  A short description for the UI
   META_UID               A unique ID
   GENERIC                A bitfield with misc flags about the update,
			                  such as whether it is a service pack
   CATEGORY               The category of the update (e.g. an upgrade product)
   COMPONENT              SoftwareUpdateInfo::TargetComponent: HOST_GENERAL,
                           HOST_THIRDPARTY, VM_GENERAL, VM_TOOLS,
                           VM_HARDWAREVERSION, VA_GENERAL
   SERVICE_PACK           1 if the update is a service pack, 0 if not, null
			                  for host updates
   SECURITY_FIX           1 if the update is a security fix; 0 if not
   IMPACT                 Security Impact
   HYPERLINK              Link to a webpage describing the update
   PATCHCONTURL           URL to get patch binary, if it's a host update
   SIGNATUREURL           URL to get patch signature, it it's a host update
   LOCALE
   DESCRIPTION            Long description
   VENDOR
   RELEASEDATE            Date when vendor released this update
   DOWNLOADTIME           When this update's metadata was downloaded
   PATH                   Currently un-used; to be removed
   VENDOR_UID             A Unique ID from the vendor
   BUGTRAQ_UID            A Bugtraq ID, if any
   CVE_UID                A CVE id, if any
   DELETED                If 1, this row is deleted
   BUNDLE_TYPE            Patch, rollup or maintainanceUpdate
   INSTALLATION_IMPACTS   Reboot;maintainanceMode,
   COMPONENT_NAME         Firware/viclient/tools,
   RELEASE_BUILD          Build number,
   CODE_VERSION           Internal version to be handled by different code.
   RELEASE                Release string
   PRODUCT_VERSION        Product version string
   METADATAFILEID         Mapping to vci_metadata_files id
   HIDDEN                 Hidden from getallupdates call. 1 if it's offline
                           upgrade, 0 if not, default 0
   RECALLED               1 if the bulletin is recalled (e.g. bulletin is
                           validated, or one of the vibs is recalled,
                           0 otherwise (default).
   HOSTUPDATE_CATEGORY    The new category type defined for host updates

==============================================================*/
CREATE TABLE VCI_UPDATES  (
   ID                   integer                          NOT NULL,
   TYPE                 integer                          NOT NULL,
   TITLE                varchar(255),
   META_UID             varchar(255),
   GENERIC              integer,
   SERVICE_PACK         integer,
   SECURITY_FIX         integer                          NOT NULL,
   IMPACT               integer                          NOT NULL,
   HYPERLINK            varchar(255),
   PATCHCONTURL         varchar(255),
   SIGNATUREURL         varchar(255),
   LOCALE               varchar(255),
   DESCRIPTION          text,
   VENDOR               varchar(128),
   RELEASEDATE          DATE,
   DOWNLOADTIME         timestamp                        NOT NULL,
   PATH                 varchar(255),
   VENDOR_UID           varchar(255),
   BUGTRAQ_UID          varchar(255),
   CVE_UID              varchar(255),
   DELETED              integer                          NOT NULL,
   RUN                  varchar(128),
   EXEC_PLATFORM        varchar(32),
   BUNDLE_TYPE          varchar(32),
   INSTALLATION_IMPACTS varchar(256),
   COMPONENT_NAME       varchar(64),
   RELEASE_BUILD        bigint                   NOT NULL DEFAULT 0,
   CATEGORY             integer                           NOT NULL,
   COMPONENT            integer                           NOT NULL,
   CODE_VERSION         varchar(32),
   PRODUCT_VERSION      varchar(32),
   RELEASE              varchar(32),
   METADATAFILEID       integer,
   HIDDEN               integer                 NOT NULL DEFAULT 0,
   RECALLED             integer                 NOT NULL DEFAULT 0,
   HOSTUPDATE_CATEGORY  integer                 NOT NULL DEFAULT 0,
   CONSTRAINT PK_VCI_UPDATES PRIMARY KEY (ID),
   CONSTRAINT UK_VCI_UPDATES UNIQUE (META_UID)
);

CREATE INDEX VCI_IDX_UPD_DEL ON VCI_UPDATES(DELETED);

/*==============================================================
   Table: VCI_METADATA_FILES

   ID                 Unique id as primary key
   FILE_NAME          The file name for the metadata
   DOWNLOAD_URL       the url to download the metadta from.
   RELATIVE_PATH      the local path relative to patch depot root.
   CODE_VERSION       identify the code using the data
   RELEASE_TIMESTAMP  the release timestamp
   SCHEMA_VERSION     the schema version of the metadata file
   IMPORT_TYPE        0:online patch, 1: offline patch, 2: offline upgrade
==============================================================*/
CREATE TABLE VCI_METADATA_FILES  (
   ID                   integer                     NOT NULL,
   FILE_NAME            varchar(128)                NOT NULL,
   DOWNLOAD_URL         varchar(255)                NOT NULL,
   RELATIVE_PATH        varchar(255)                NOT NULL,
   CODE_VERSION         varchar(32),
   RELEASE_TIMESTAMP    varchar(255)                NOT NULL,
   SCHEMA_VERSION       varchar(32)                 NOT NULL,
   IMPORT_TYPE          integer           NOT NULL DEFAULT 0,
   CONSTRAINT PK_VCI_METADATA_FILES PRIMARY KEY (ID)
);

/*==============================================================
 Table: VCI_PLATFORMS

 NAME             Name of platform, used for display in UI
 FAMILY           Enum, current valid values:
                  WINDOWS = 1, LINUX = 2, ESX = 3, EMBEDDED ESX = 4
 VERSION          Platform version provided by vendor e.g. 1.0.1 etc
 LOCALE           Platform language supported, e.g. "en-us"
 METADATA_URL     URL for metadata location (currently used only for EESX)
 METADATA_SIG_URL URL for metadata signature (currently used only for EESX)
 CREATION_TIME    The time stamp when the row is created

==============================================================*/
CREATE TABLE VCI_PLATFORMS  (
   ID                   integer                          NOT NULL,
   NAME                 varchar(255)                     NOT NULL,
   FAMILY               integer                          NOT NULL,
   VERSION              varchar(255),
   LOCALE               varchar(20),
   METADATA_URL         varchar(255),
   METADATA_SIG_URL     varchar(255),
   CREATION_TIME        timestamp                        NOT NULL,
   CONSTRAINT PK_VCI_PLATFORMS PRIMARY KEY (ID),
   CONSTRAINT UK_VCI_PLATFORMS UNIQUE (NAME, FAMILY, VERSION, LOCALE)
);

/*==============================================================
   Table: VCI_PLATFORM_METADATA

   Link platform and metadata files
   PLATFORM_ID      foreign key to platform table
   METADATA_ID      foreign key to metadata file table
==============================================================*/
CREATE TABLE VCI_PLATFORM_METADATA  (
   PLATFORM_ID            integer                          NOT NULL,
   METADATA_ID            integer                          NOT NULL,
   CONSTRAINT PK_VCI_PLATFORM_METADATA PRIMARY KEY (PLATFORM_ID, METADATA_ID),
   CONSTRAINT FK_VCI_PLT_MTAS_REF_PLT FOREIGN KEY (PLATFORM_ID)
      REFERENCES VCI_PLATFORMS (ID),
   CONSTRAINT FK_VCI_PLT_MTAS_REF_MTA FOREIGN KEY (METADATA_ID)
      REFERENCES VCI_METADATA_FILES (ID)
);

/*==============================================================
 Table: VCI_PACKAGES

    SOFTWARE_TAGS: Software Tags
==============================================================*/
CREATE TABLE VCI_PACKAGES  (
   ID                   integer                          NOT NULL,
   NAME                 varchar(255),
   DESCRIPTION          text,
   PATH                 varchar(255),
   DOWNLOADTIME         timestamp                        NOT NULL,
   DOWNLOADURL          varchar(255),
   USECNT               integer,
   LASTUSE              integer,
   PKG_SIZE             integer,
   IS_SUPPORTED         integer,
   BUNDLE_ID            varchar(128),
   VERSION              varchar(255),
   LOCALE               varchar(64),
   BUILD_DATE           date,
   PAYLOAD_TYPE         varchar(64),
   RELEASE_BUILD        integer,
   INSTALLATION_IMPACTS varchar(128),
   COMPONENT_NAME       varchar(64),
   VIB_TYPE             varchar(64),
   UNPACKED_SIZE        integer,
   SIGNATURE_TYPE       varchar(32),
   SIGNATURE            varchar(128),
   CODE_VERSION         varchar(32),
   SOFTWARE_TAGS        varchar(2000),
   CONSTRAINT PK_VCI_PKGS PRIMARY KEY (ID)
);

/*==============================================================
 Table: VCI_UPDATE_PLATFORMS
==============================================================*/
CREATE TABLE VCI_UPDATE_PLATFORMS  (
   UPDATE_ID            integer                          NOT NULL,
   PLATFORM_ID          integer                          NOT NULL,
   CONSTRAINT PK_VCI_UPDPLT PRIMARY KEY (UPDATE_ID, PLATFORM_ID),
   CONSTRAINT FK_VCI_UPDPLT_REF_UPD FOREIGN KEY (UPDATE_ID)
      REFERENCES VCI_UPDATES (ID),
   CONSTRAINT FK_VCI_UPDPLT_REF_PLTS FOREIGN KEY (PLATFORM_ID)
      REFERENCES VCI_PLATFORMS (ID)
);

/*==============================================================
 Table: VCI_UPDATE_PACKAGES
==============================================================*/
CREATE TABLE VCI_UPDATE_PACKAGES (
   UPDATE_ID            integer                          NOT NULL,
   PACKAGE_ID           integer                          NOT NULL,
   CONSTRAINT PK_VCI_UPDPKG PRIMARY KEY (UPDATE_ID, PACKAGE_ID),
   CONSTRAINT FK_VCI_UPDPKG_REF_UPD FOREIGN KEY (UPDATE_ID)
      REFERENCES VCI_UPDATES (ID),
   CONSTRAINT FK_VCI_UPDPKG_REF_PKGS FOREIGN KEY (PACKAGE_ID)
      REFERENCES VCI_PACKAGES (ID) ON DELETE CASCADE
);

/*====================================================================
  Table: VCI_HOST_UPGRADES

  ID                      unique ID
  PRODUCT                 "esx" or "embeddedEsx"
  VERSION                 "x.y.z"
  BUILD_NUMBER
  DISPLAY_NAME            Name that can be displayed to the user
  LOCALE                  Locale of the package; only INTL exists as of now
  PERMANENT_STORAGE       Minimum COS VMDK size, used for choosing a datastore
  TRANSIENT_STORAGE       Size required by the temp dir; used for choosing a
                              directory to extract the cosless upgrader
  FILE_NAME               Relative path to the upgrade package.  Path is
                              relative to patchstore
  PRECHECK_PATH           Path to the precheck script from the package
  RELEASE_ID              Foreign key to the VCI_UPDATES table
  INTERFACE_VERSION 	     Host upgrade interface version
  PACKAGE_TYPE            0:upgrade, 1:patch
  SCAN_VERSION            Minimum scan version needed for upgrade
  UPDATE_LEVEL            Update level of the release
  PROFILENAME             Name of image composer profile which generated this image
  DIGEST                  Checksum for all packages included in the image
  VENDOR                  Vendor name
  ACCPT_LEVEL             Acceptance level of the upgrade. Valid range: [0-3]
  REL_DATE                Release date
=====================================================================*/
CREATE TABLE VCI_HOST_UPGRADES (
   ID			            integer                          NOT NULL,
   PRODUCT              varchar(255)                     NOT NULL,
   VERSION              varchar(255)                     NOT NULL,
   BUILD_NUMBER         integer                          NOT NULL,
   DISPLAY_NAME         varchar(255)                     NOT NULL,
   LOCALE               varchar(255)                     NOT NULL,
   PERMANENT_STORAGE    integer,
   TRANSIENT_STORAGE    integer,
   FILE_NAME            varchar(255)                     NOT NULL,
   PRECHECK_PATH        varchar(255),
   RELEASE_ID           integer                          NOT NULL,
   INTERFACE_VERSION    integer                          NOT NULL,
   PACKAGE_TYPE         integer                NOT NULL DEFAULT 0,
   SCAN_VERSION         varchar(255)           NOT NULL DEFAULT 0,
   UPDATE_LEVEL	      integer                         DEFAULT 0,
   PROFILE_NAME	      varchar(255),
   DIGEST		         varchar(255),
   VENDOR		         varchar(255),
   ACCPT_LEVEL	         integer,
   REL_DATE		         date,
   CONSTRAINT PK_VCI_HOST_UPGRADES PRIMARY KEY (ID),
   CONSTRAINT FK_VCI_HOST_UPGRADES FOREIGN KEY (RELEASE_ID)
      REFERENCES VCI_UPDATES(ID) ON DELETE CASCADE
);

/*==============================================================
 Table: VCI_HOST_UPGRADE_PACKAGES
   ID                    DB id of software package (primary key)
   UPGRADE_ID            Foreign key, associates software package with
                          host upgrade bundle
   PKGNAME               Name of the software package
   ACCPT_LEVEL           Acceptance level of the package. Valid range: [0-3]
   VENDOR                Name of the vendor
   VERSION               Package version
   PKG_SIZE              Size, in MB
   REL_DATE              Release date of the package
===============================================================*/

CREATE TABLE VCI_HOST_UPGRADE_PACKAGES (
       ID                        integer            NOT NULL,
       UPGRADE_ID                integer            NOT NULL,
       PKG_NAME                  varchar(255),
       ACCPT_LEVEL               integer,
       VENDOR                    varchar(255),
       VERSION                   varchar(255),
       PKG_SIZE                  integer,
       REL_DATE                  date,
       CONSTRAINT PK_VCI_HU_PKGS PRIMARY KEY (ID),
       CONSTRAINT FK_VCI_HU_PKGS FOREIGN KEY (UPGRADE_ID)
              REFERENCES VCI_HOST_UPGRADES (ID) ON DELETE CASCADE
);

/*==============================================================
 Table: VCI_BASELINES

 This table stores the basic baseline information.

 ID                     Unique Id; generated sequence number
 VERSION                Version of the baseline info
 NAME                   Name of the baseline
 TYPE                   target type: VM, HOST, VA
 UPDATETYPE             Content type: dynamic, static, both
 BUILTIN                Whether or not the baseline is a builtin baseline
 DESCRIPTION            Description of the baseline
 DELETED                Whether or not the baseline is deleted
 LASTUPDATED            Last update time
 TARGET_COMPONENT       Target component: hardware version, tools, or general
 CATEGORY               Baseline category: patch, upgrade, configuration,
                           extension
 EXTRA_ATTRIBUTES       The string representation of extra attributes. Multiple
                           values separated by comma.
 INFO_BLOB              Seralized data object for baselineInfo
 OWNER                  The owner for the baseline Group
 OWNERDATA              Private data saved by owner of the baseline group.

 ==============================================================*/
CREATE TABLE VCI_BASELINES  (
   ID                   integer                           NOT NULL,
   VERSION              integer                           NOT NULL,
   NAME                 varchar(255),
   TYPE                 integer                           NOT NULL,
   UPDATETYPE           integer                           NOT NULL,
   DESCRIPTION          text,
   DELETED              integer                           NOT NULL,
   LASTUPDATED          timestamp                         NOT NULL,
   BUILTIN              integer,
   TARGET_COMPONENT     integer                           NOT NULL,
   CATEGORY             integer                 NOT NULL DEFAULT 0,
   EXTRA_ATTRIBUTES     varchar(255),
   INFO_BLOB            text,
   OWNER                varchar(128),
   OWNERDATA            varchar(256),
   CONSTRAINT PK_VCI_BASELINES PRIMARY KEY (ID)
);

CREATE INDEX VCI_IDX_BL_TYPE ON VCI_BASELINES(TYPE);
CREATE INDEX VCI_IDX_BL_TCOMP ON VCI_BASELINES(TARGET_COMPONENT);
CREATE INDEX VCI_IDX_BL_CAT ON VCI_BASELINES(CATEGORY);
CREATE INDEX VCI_IDX_BL_NAME ON VCI_BASELINES(NAME);
CREATE INDEX VCI_IDX_BL_DEL ON VCI_BASELINES(DELETED);

/*==============================================================
 Table: VCI_BASELINE_GROUPS

 This table stores the information about baseline groups.

 BASELINE_GROUP_ID    The unique Id of baseline group; generated sequence number
 NAME                 The name of the baseline group
 DESCRIPTION          The description of the baseline group
 DELETED              Whether or not the baseline group is deleted
 LASTUPDATED          Last update time
 OWNER                Name of the baseline creator
 OWNERDATA            Private data saved by the baseline owner

 ==============================================================*/
CREATE TABLE VCI_BASELINE_GROUPS  (
   BASELINE_GROUP_ID    integer                          NOT NULL,
   VERSION              integer                          NOT NULL,
   NAME                 varchar(255)                     NOT NULL,
   TYPE                 integer                          NOT NULL,
   DESCRIPTION          text,
   DELETED              integer                          NOT NULL,
   LASTUPDATED          date                             NOT NULL,
   OWNER                varchar(128),
   OWNERDATA            varchar(256),
   CONSTRAINT PK_VCI_BASELINE_GROUPS PRIMARY KEY (BASELINE_GROUP_ID)
);

/*==============================================================
 Table: VCI_BASELINE_GROUP_BASELINES

 This table stores the list of baselines within each baseline group.

 BASELINE_GROUP_ID       The unique Id baseline group; generated sequence number
 BASELINE_GROUP_VERSION  The version of the baseline group
 BASELINE_ID             The id of the baseline within the baseline group

 ==============================================================*/
CREATE TABLE VCI_BASELINE_GROUP_BASELINES  (
   BASELINE_GROUP_ID       integer                         NOT NULL,
   BASELINE_GROUP_VERSION  integer                         NOT NULL,
   BASELINE_ID             integer                         NOT NULL,
   constraint PK_VCI_BLGP_BL unique (BASELINE_GROUP_ID,
                                     BASELINE_GROUP_VERSION,
                                     BASELINE_ID),
   CONSTRAINT FK_VCI_BLGP_BL_REF_BL FOREIGN KEY (BASELINE_ID)
      REFERENCES VCI_BASELINES (ID) ON DELETE CASCADE,
   CONSTRAINT FK_VCI_BLGP_BL_REF_BLGP FOREIGN KEY (BASELINE_GROUP_ID)
      REFERENCES VCI_BASELINE_GROUPS (BASELINE_GROUP_ID) ON DELETE CASCADE
);

/*==============================================================
 Table: VCI_HOST_UPGRADE_BASELINES
 ==============================================================*/
CREATE TABLE VCI_HOST_UPGRADE_BASELINES  (
   BASELINE_ID          integer                          NOT NULL,
   BASELINE_VERSION     integer                          NOT NULL,
   RELEASE_ID           integer                          NOT NULL,
   constraint PK_VCI_UPG_BLS unique (BASELINE_ID, BASELINE_VERSION),
   CONSTRAINT FK_VCI_UPG_BL_REF_BL FOREIGN KEY (BASELINE_ID)
      REFERENCES VCI_BASELINES (ID) ON DELETE CASCADE,
   CONSTRAINT FK_VCI_UPG_BL_REF_HU FOREIGN KEY (RELEASE_ID)
      REFERENCES VCI_UPDATES (ID) ON DELETE CASCADE
);

/*==============================================================
 Table: VCI_UPDATE_BASELINES
 ==============================================================*/
CREATE TABLE VCI_UPDATE_BASELINES  (
   BASELINE_ID          integer                           NOT NULL,
   BASELINE_VERSION     integer                           NOT NULL,
   UPDATE_ID            integer,
   EXCLUDE              integer,
   DYNAMIC_SQL          text,
   SEARCH_SPEC          text,
   CONSTRAINT PK_VCI_UPD_BLS UNIQUE (BASELINE_ID, BASELINE_VERSION, UPDATE_ID, EXCLUDE),
   CONSTRAINT FK_VCI_UPD_BL_REF_BL FOREIGN KEY (BASELINE_ID)
      REFERENCES VCI_BASELINES (ID) ON DELETE CASCADE,
   CONSTRAINT FK_VCI_UPD_BL_REF_UPD FOREIGN KEY (UPDATE_ID)
      REFERENCES VCI_UPDATES (ID) ON DELETE CASCADE
);

/*==============================================================
 Table: VCI_UPDATE_BASELINES_EXPANDED

 Stores the expanded list of updates corresponding to a
 a baseline. This includes the result of any dynamic sql
 expansion.
 BASELINE_ID            Unique Id; generated sequence number
 BASELINE_VERSION       Version of the baseline info
 UPDATE_ID              The update id
 EXCLUDE                Whether the update is included or excluded
==============================================================*/
CREATE TABLE VCI_UPDATE_BASELINES_EXPANDED (
   BASELINE_ID          integer                         NOT NULL,
   BASELINE_VERSION     integer                         NOT NULL,
   UPDATE_ID            integer                         NOT NULL,
   EXCLUDE              integer,
   CONSTRAINT PK_UBEXT unique (BASELINE_ID, BASELINE_VERSION, UPDATE_ID, EXCLUDE),
   CONSTRAINT FK_IDEXT foreign key(BASELINE_ID) REFERENCES VCI_BASELINES(ID)
              ON DELETE CASCADE,
   CONSTRAINT FK_UPDEXT foreign key(UPDATE_ID) REFERENCES VCI_UPDATES(ID)
              ON DELETE CASCADE
);

CREATE INDEX VCI_IDX_UBX_BID ON VCI_UPDATE_BASELINES_EXPANDED(BASELINE_ID);
CREATE INDEX VCI_IDX_UBX_UID ON VCI_UPDATE_BASELINES_EXPANDED(UPDATE_ID);

/*==============================================================
 Table: VCI_NOTIFICATIONS (Updates of release type "notification")

   ID                     Unique Id; generated sequence number
   META_UID               A unique ID, the notification bulletin name
   VENDOR_UID             A unique ID for the vendor
   VENDOR                 Vendor ID, e.g. VMware
   SUMMARY                Short description, a.k.a TITLE in VCI_UPDATES
   SEVERITY               Severity level, a.k.a IMPACT in VCI_UPDATES
   CATEGORY               Notification category
   DESCRIPTION            Long description
   CONTENTBODY            Content body, notification text
   HYPERLINK              Link of the KB article
   CONTACT                Email contact, Address, Phone, etc.
   RELEASEDATE            Date when vendor released this notification
   DOWNLOADTIME           When this notification was downloaded
   DELETED                If 1, this row is deleted
==============================================================*/
CREATE TABLE VCI_NOTIFICATIONS  (
   ID                   integer                          NOT NULL,
   META_UID             varchar(255)                     NOT NULL,
   VENDORPRODUCT        varchar(255),
   VENDOR               varchar(128),
   SUMMARY              varchar(255),
   SEVERITY             integer                          NOT NULL,
   CATEGORY             integer                          NOT NULL,
   DESCRIPTION          text,
   CONTENTBODY          text,
   HYPERLINK            varchar(255),
   CONTACT              varchar(255),
   RELEASEDATE          timestamp,
   DOWNLOADTIME         timestamp                        NOT NULL,
   DELETED              integer                          NOT NULL,
   CONSTRAINT PK_VCI_NOTIFICATIONS PRIMARY KEY (ID),
   CONSTRAINT UK_VCI_NOTIFICATIONS UNIQUE (META_UID)
);

/*==============================================================
 Table: VCI_RECALL_PACKAGES

   NOTIFICATION_ID        ID from VCI_NOTIFICATIONS table
   UPDATE_ID              ID from VCI_UPDATES table that the package belongs to
   PACKAGE_BUNDLE_ID      Name of vib package which is recalled in the
                           notification, package may or may not exist in VUM
                           depot. It is supposed to be the BUNDLE_ID in
                           VCI_PACKAGES table.
==============================================================*/
CREATE TABLE VCI_RECALL_PACKAGES  (
   NOTIFICATION_ID      integer                          NOT NULL,
   PACKAGE_BUNDLE_ID    varchar(128)                     NOT NULL,
   CONSTRAINT PK_VCIREC_PACKAGES PRIMARY KEY (NOTIFICATION_ID,
                                              PACKAGE_BUNDLE_ID),
   CONSTRAINT FK_VCIREC_PACKAGES_NTF FOREIGN KEY (NOTIFICATION_ID)
      REFERENCES VCI_NOTIFICATIONS (ID)
);

/*==============================================================
 Table: VCI_RECALL_UPDATES

   NOTIFICATION_ID        ID from VCI_NOTIFICATIONS table
   UPDATE_ID              ID from VCI_UPDATES table that matches the
                           update_meta_uid
   UPDATE_META_UID        Name of the update which is recalled in the
                           notification, update may or may not exist in VUM
                           depot. It is supposed to be the META_UID in
                           VCI_UPDATES table.
==============================================================*/
CREATE TABLE VCI_RECALL_UPDATES  (
   NOTIFICATION_ID      integer                          NOT NULL,
   UPDATE_META_UID      varchar(255)                     NOT NULL,
   CONSTRAINT PK_RECALL_UPDATES PRIMARY KEY (NOTIFICATION_ID, UPDATE_META_UID),
   CONSTRAINT FK_VCI_RECUPD_REF_NTFS FOREIGN KEY (NOTIFICATION_ID)
      REFERENCES VCI_NOTIFICATIONS (ID)
);

/*==============================================================
 Table: VCI_RECALL_RESOLUTIONS

   NOTIFICATION_ID            ID from VCI_NOTIFICATIONS table
   FIXED_NTFS_META_UID        META_UID from VCI_NOTIFICATIONS, it is the recall.
   FIX_META_ID                META_UID from VCI_UPDATES, the new patch, the fix.
   RECALLED_META_ID           META_UID from VCI_UPDATES, the old patch, the
                                 recalled.
==============================================================*/
CREATE TABLE VCI_RECALL_RESOLUTIONS  (
   NOTIFICATION_ID                   integer             NOT NULL,
   RECALLED_NTFS_META_UID            varchar(255)        NOT NULL,
   FIX_META_ID                       varchar(255)        NOT NULL,
   RECALLED_META_ID                  varchar(255)        NOT NULL,
   CONSTRAINT PK_VCI_RECALL_RESOLUTIONS PRIMARY KEY (NOTIFICATION_ID,
                                                     RECALLED_NTFS_META_UID,
                                                     FIX_META_ID,
                                                     RECALLED_META_ID)
);

/*==============================================================
 Table: VCI_TARGET_BASELINES
==============================================================*/
CREATE TABLE VCI_TARGET_BASELINES  (
   BASELINE_ID          integer                           NOT NULL,
   TARGET_UID           varchar(255),
   VC_CONTEXT           varchar(128)          NOT NULL DEFAULT '.',
   CONSTRAINT PK_VCI_TGT_BLS PRIMARY KEY (BASELINE_ID, TARGET_UID, VC_CONTEXT),
   CONSTRAINT FK_VCI_TGT_BL_REF_BL FOREIGN KEY (BASELINE_ID)
      REFERENCES VCI_BASELINES (ID) ON DELETE CASCADE
);

/*==============================================================
 Table: VCI_TARGET_BASELINE_GROUPS

 This table stores the association of the baseline groups with target.

 BASELINE_GROUP_ID   : the unique ID of baseline groups
 TARGET_UID          : the UID of the targets
 VC_CONTEXT          : the context of the VC

==============================================================*/
CREATE TABLE VCI_TARGET_BASELINE_GROUPS  (
   BASELINE_GROUP_ID    integer                           NOT NULL,
   TARGET_UID           varchar(255)                      NOT NULL,
   VC_CONTEXT           varchar(128)          NOT NULL DEFAULT '.',
   CONSTRAINT PK_VCI_TGT_BLGPS PRIMARY KEY (BASELINE_GROUP_ID,
                                 TARGET_UID, VC_CONTEXT),
   CONSTRAINT FK_VCI_TGT_BLGP_REF_BLGP FOREIGN KEY (BASELINE_GROUP_ID)
      REFERENCES VCI_BASELINE_GROUPS (BASELINE_GROUP_ID) ON DELETE CASCADE
);

/*==============================================================
 Table: VCI_AGING_SNAPSHOTS
 Stores per target details of snapshots that alpine took as part of
 remediation and needs to clean up after certain time
 =============================================================== */
CREATE TABLE VCI_AGING_SNAPSHOTS  (
   TARGET_UID           varchar(255),
   SNAPSHOT_UUID        varchar(255),
   DELETION_TIME        timestamp                        NOT NULL,
   VC_CONTEXT           varchar(128)          NOT NULL DEFAULT '.',
   CONSTRAINT PK_VCI_AGING_SNAPSHOTS PRIMARY KEY (TARGET_UID, VC_CONTEXT,
                                       SNAPSHOT_UUID)

);

/*==============================================================
 HISTORY TABLES
==============================================================*/

/*==============================================================
 Table: VCI_SCANHISTORY

 This table stores a history of all scans performed on any targets in the
 Inventry. Stale data in this table may be periodically cleaned if use
 subscribes to Alpine database aging policy.

 ID                     Unique Id; generated sequence number
 TARGET_UID             uid of the target being scanned
 VC_CONTEXT             the context of the VC

 NOTE: We repeat the target_uid here even though VCI_SCANHISTORY_TARGETS table
 has a target_uid, because the VCI_SCANHISTORY_TARGETS only contains data for
 missing and installed updates. If a scan is performed on a target, and all
 updates were found to be not applicable, then VCI_SCANHISTORY_TARGETS table
 will have no entries for that scan. Hence we need the target_uid here, to be
 able to determine whether or not a scan was ever performed on that target.

 STARTTIME              scan start time
 ENDTIME                scan end time
 SCAN_STATUS            scan status: 0 FAILURE, 1 SUCCESS, 2 CANCELLED
 REASON                 reason if any in case of failure
 SCAN_TYPE              see baseline type: Patch, Upgrade
 TARGET_COMPONENT       see TargetComponent:
                           HOST_GENERAL,
                           HOST_THIRDPARTY,
                           VM_GENERAL,
                           VM_TOOLS,
                           VM_HARDWAREVERSION,
                           VA_GENERAL

==============================================================*/
CREATE TABLE VCI_SCANHISTORY  (
   ID                  integer                           NOT NULL,
   TARGET_UID          varchar(255),
   VC_CONTEXT          varchar(128)          NOT NULL DEFAULT '.',
   STARTTIME           timestamp                         NOT NULL,
   ENDTIME             timestamp,
   SCAN_STATUS         integer                           NOT NULL,
   REASON              varchar(255),
   SCAN_TYPE           integer                           NOT NULL,
   TARGET_COMPONENT    integer                           NOT NULL,
   CONSTRAINT PK_VCI_SCANHISTORY PRIMARY KEY (ID)
);

/*==============================================================
Table: VCI_SCANRESULTS

 This table servers as a cache of most recent scans performed all targets in the
 Inventory.

 ID                     Unique Id; generated sequence number
 TARGET_UID             uid of the target being scanned
 VC_CONTEXT             the context of the VC

 NOTE: We repeat the target_uid here even though VCI_SCANRESULTS_TARGETS table
 has a target_uid, because the VCI_SCANRESULTS_TARGETS only contains data for
 missing and installed updates. If a scan is performed on a target, and all
 updates were found to be not applicable, then VCI_SCANRESULTS_TARGETS table
 will have no entries for that scan. Hence we need the target_uid here, to be
 able to determine whether or not a scan was ever performed on that target.

 STARTTIME              scan start time
 ENDTIME                scan end time
 SCAN_STATUS            scan status: 0 SUCCESS 1 FAILURE 2 INPROGRESS
 SCAN_TYPE              see baseline type: Patch, Upgrade, Configuration,
                           Extension
 TARGET_COMPONENT       see TargetComponent:
                           HOST_GENERAL,
                           HOST_THIRDPARTY,
                           VM_GENERAL,
                           VM_TOOLS,
                           VM_HARDWAREVERSION,
                           VA_GENERAL
==============================================================*/
CREATE TABLE VCI_SCANRESULTS  (
   ID                  integer                           NOT NULL,
   TARGET_UID          varchar(255),
   VC_CONTEXT          varchar(128)          NOT NULL DEFAULT '.',
   STARTTIME           timestamp                         NOT NULL,
   ENDTIME             timestamp,
   SCAN_STATUS         integer                           NOT NULL,
   SCAN_TYPE           integer                           NOT NULL,
   TARGET_COMPONENT    integer                           NOT NULL,
   CONSTRAINT PK_VCI_SCANRESULTS PRIMARY KEY (ID)
);

CREATE INDEX VCI_IDX_SR_TIME ON VCI_SCANRESULTS(STARTTIME);
CREATE INDEX VCI_IDX_SR_TCOMP ON VCI_SCANRESULTS(TARGET_COMPONENT);
CREATE INDEX VCI_IDX_SR_TYPE ON VCI_SCANRESULTS(SCAN_TYPE);
CREATE INDEX VCI_IDX_SR_TGTUID ON VCI_SCANRESULTS(TARGET_UID);

/*==============================================================
 Table: VCI_SCANRESULTS_TARGETS
==============================================================*/
CREATE TABLE VCI_SCANRESULTS_TARGETS  (
   SCANH_ID            integer                           NOT NULL,
   UPDATE_ID           integer                           NOT NULL,
   TARGET_UID          varchar(255),
   VC_CONTEXT          varchar(128)          NOT NULL DEFAULT '.',
   TARGET_STATUS       integer                           NOT NULL,
   OEM_PATCH_INFO      text,
   ADDITIONAL_DETAILS  text,
   CONSTRAINT PK_VCI_SRESVMS PRIMARY KEY (SCANH_ID, UPDATE_ID, TARGET_UID,
                                 VC_CONTEXT),
   CONSTRAINT FK_VCI_SRESVMS_REF_SH FOREIGN KEY (SCANH_ID)
      REFERENCES VCI_SCANRESULTS(ID),
   CONSTRAINT FK_VCI_SRESVMS_REF_SIG FOREIGN KEY (UPDATE_ID)
      REFERENCES VCI_UPDATES (ID)
);

CREATE INDEX VCI_IDX_SRT_STATUS ON VCI_SCANRESULTS_TARGETS(TARGET_STATUS);
CREATE INDEX VCI_IDX_SRT_TGTUID ON VCI_SCANRESULTS_TARGETS(TARGET_UID);

/* The following indexes have adverse effect on performance */

/* CREATE INDEX VCI_IDX_SRT_UID ON VCI_SCANRESULTS_TARGETS(UPDATE_ID); */

/*==============================================================
 Table: VCI_SCANRESULTS_BASELINES

 BASELINE_ID                     Unique Id of baseline
 BASELINE_VERSION                Version of baseline we computed compliance
                                    against
 TARGET_UID                      UID of target entity scanned
 VC_CONTEXT                      the context of the VC
 TARGET_STATUS                   Status of the target wrt this baseline,
                                 COMPLIANT = 0, NOT COMPLIANT = 1, UNKNOWN = 2
INCOMPATIBLESOFTWARECONFIG_UPD   Update count for host which are not compliant
                                 because of software or config problems
==============================================================*/
CREATE TABLE VCI_SCANRESULTS_BASELINES  (
   BASELINE_ID                integer                    NOT NULL,
   BASELINE_VERSION           integer                    NOT NULL,
   TARGET_UID                 varchar(255),
   TARGET_STATUS              integer                    NOT NULL,
   COMPLIANT_UPD              integer,
   NONCOMPLIANT_UPD           integer,
   UNKNOWN_UPD                integer,
   NOT_APPLICABLE_UPD         integer,
   ISVALID                    integer,
   VC_CONTEXT                 varchar(128)   NOT NULL DEFAULT '.',
   STAGED_UPD                 integer,
   CONFLICT_UPD               integer,
   OBSOLETEDBYHOST_UPD        integer,
   MISSPACKAGE_UPD            integer,
   NOTINSTALLABLE_UPD         integer,
   NEWMODULE_UPD              integer,
   UNSUPPORTEDUPGRADE_UPD     integer,
   INCOMPATIBLEHARDWARE_UPD   integer,
   CONFLICTINGNEWMODULE_UPD   integer,
   INSTALLEDRECALLED_UPD      integer                    DEFAULT 0,
   NOTAPPLICABLERECALLED_UPD  integer                    DEFAULT 0,
   PREREQUISITERECALLED_UPD   integer                    DEFAULT 0,
   MISSINGRECALLED_UPD        integer                    DEFAULT 0,
   NEWMODULERECALLED_UPD      integer                    DEFAULT 0,
   PREREQRECALLEDINSTALLED_UPD  integer                  DEFAULT 0,
   INCOMPATIBLESOFTWARECONFIG_UPD  integer               DEFAULT 0,
   CONSTRAINT PK_VCI_SRESBLS PRIMARY KEY (BASELINE_ID,
                              BASELINE_VERSION,
                              TARGET_UID,
                              VC_CONTEXT),
   CONSTRAINT FK_VCI_SRESBLS_REF_BL FOREIGN KEY (BASELINE_ID)
      REFERENCES VCI_BASELINES (ID) ON DELETE CASCADE
);

/*==============================================================
 Table: VCI_SCANHISTORY_TARGETS
==============================================================*/
CREATE TABLE VCI_SCANHISTORY_TARGETS  (
   SCANH_ID            integer                           NOT NULL,
   UPDATE_ID           integer                           NOT NULL,
   TARGET_UID          varchar(255)                      NOT NULL,
   VC_CONTEXT          varchar(128)          NOT NULL DEFAULT '.',
   TARGET_STATUS       integer                           NOT NULL,
   FAILUREREASON       varchar(255),
   ADDITIONAL_DETAILS  text,
   CONSTRAINT PK_VCI_SHISTVMS PRIMARY KEY (SCANH_ID,
                              UPDATE_ID,
                              TARGET_UID,
                              VC_CONTEXT),
   CONSTRAINT FK_VCI_SHISTVMS_REF_SH FOREIGN KEY (SCANH_ID)
      REFERENCES VCI_SCANHISTORY (ID) ON DELETE CASCADE,
   CONSTRAINT FK_VCI_SHISTVMS_REF_SIG FOREIGN KEY (UPDATE_ID)
      REFERENCES VCI_UPDATES (ID)
);

/*==============================================================
 Table: VCI_REMEDIATION_HISTORY

 Stores results of a remediation operation at per target level
   (VM/HOST/CONTAINER)

 ID                     Unique remediation ID created using a sequence
 TARGET_UID             UUID of the target being remediated (obtained from VC)
 STARTTIME              Remediation start time
 ENDTIME                Remediation end time
 ISSNAPSHOTTAKEN        Whether snapshot was taken prior to remediation
 REMEDIATION_STATUS     Status of remediation operation: 0 SUCCESS 1 FAILURE
                        2 CANCELLED
==============================================================*/
CREATE TABLE VCI_REMEDIATION_HISTORY  (
   ID                  integer                           NOT NULL,
   TARGET_UID          varchar(255),
   VC_CONTEXT          varchar(128)          NOT NULL DEFAULT '.',
   STARTTIME           timestamp                         NOT NULL,
   ENDTIME             timestamp,
   ISSNAPSHOTTAKEN     integer                               NULL,
   REMEDIATION_STATUS  integer                           NOT NULL,
   ACTION_TYPE         integer,
   VCTASK_QUEUE_TIME   integer                 NOT NULL DEFAULT 0,
   CONSTRAINT PK_VCI_REMEDIATION_HISTORY PRIMARY KEY (ID)
);

/*==============================================================
 Table: VCI_TEXTFILES

   KEYSTR         ESX platform is '1', Windows platform is '2', Linux is '3'
==============================================================*/
CREATE TABLE VCI_TEXTFILES (
   KEYSTR               varchar(255),
   TEXTFILE             text,
   FILETYPE             integer             NOT NULL,
   CREATIONTIME         timestamp           NOT NULL,
   UPDATETIME           timestamp           NOT NULL,
   CONSTRAINT UK_VCI_TEXTFILES UNIQUE (KEYSTR, FILETYPE)
);

/*==============================================================
 Table: VCI_BUNDLE_KEYS

 KEY_ID            A unique id of a key
 SOURCE            "METADATA" or "USER"
 PLATFORM_ID       Specifies which platform this key is used
                   for
===============================================================*/
CREATE TABLE VCI_BUNDLE_KEYS  (
   KEY_ID            varchar(128),
   SOURCE            varchar(32),
   PLATFORM_ID       integer                    NOT NULL,
   CONSTRAINT PK_VCI_BUNDLE_KEYS PRIMARY KEY (KEY_ID),
   CONSTRAINT FK_VCI_BUNDLEKEYS_REF_PLT FOREIGN KEY (PLATFORM_ID)
	  REFERENCES VCI_PLATFORMS(ID)
);

/*===============================================================
Table: VCI_COMPONENT_SPEC

   NAME : Component name
   VERSION  : component version
===============================================================*/

CREATE TABLE VCI_COMPONENT_SPEC (
   NAME              varchar(128)                  NOT NULL,
   VERSION           varchar(128)                  NOT NULL,
   SPEC              text,
   CONSTRAINT PK_COMPONENT_SPEC PRIMARY KEY (NAME, VERSION)
);

/*===============================================================
 Table: VCI_CONTENT_KEYS

 KEY_ID           Key Id (from the metadata)
 SEQ_NUM          Sequence number of the key, from the metadata
 ACTION           Set of actions: some subset of {revocation,
                  expiration, addition}
 META_UID         Meta UID of the update
 RESIGN           If true, old packages must be resigned with
                  this key
 VALID            True if the key is valid
===============================================================*/
CREATE TABLE VCI_CONTENT_KEYS (
   KEY_ID           varchar(128),
   SEQ_NUM          bigint                       NOT NULL,
   ACTION           varchar(128),
   META_UID         varchar(255),
   RESIGN           integer                      NOT NULL,
   VALID            integer,
   CONSTRAINT PK_VCI_CONTENT_KEYS PRIMARY KEY (KEY_ID, META_UID),
   CONSTRAINT FK_VCI_CONTENTKEYS_REF_UPD FOREIGN KEY (META_UID)
	  REFERENCES VCI_UPDATES(META_UID)
);

/*==============================================================
 Table: VCI_LOCALE
==============================================================*/
CREATE TABLE VCI_LOCALES (
   LANG_ID          integer                      NOT NULL,
   ISO_LANG         varchar(255),
   OEM_LANG_INFO    varchar(255),
   CONSTRAINT PK_VCI_LCL PRIMARY KEY (LANG_ID)
);

/*==============================================================
 Table: VCI_PACKAGE_LOCALES
==============================================================*/
CREATE TABLE VCI_PACKAGE_LOCALES (
   PACKAGE_ID           integer                  NOT NULL,
   LANG_ID              integer                  NOT NULL,
   DOWNLOADURL          varchar(255),
   DOWNLOADTIME         timestamp,
   CONSTRAINT PK_VCI_PKGLCL PRIMARY KEY (PACKAGE_ID, LANG_ID),
   CONSTRAINT FK_VCI_PKGLCL_REF_PKGS FOREIGN KEY (PACKAGE_ID)
      REFERENCES VCI_PACKAGES (ID),
   CONSTRAINT FK_VCI_PKGLCL_REF_LCLS FOREIGN KEY (LANG_ID)
      REFERENCES VCI_LOCALES (LANG_ID)
);

/*==============================================================
 Table: VCI_RUNNING_VC_TASKS
 Stores running VC tasks for Alpine and needs to clean up
 when Alpine crashes and restarts.

 TASK_ID                  The MoId of the VC task for Alpine.
 TASK_QUEUE_TIME          The creation UTC time for the VC task
                           in microseconds.
 TASK_STATE_ON_RESET      Reset the task to be success or failure
                           Vim::TaskInfo::State has (0,1,2,3) as valid values;
                           See Vim::TaskInfo::State
==============================================================*/
CREATE TABLE VCI_RUNNING_VC_TASKS (
   TASK_ID              varchar(255),
   TASK_QUEUE_TIME      bigint                        NOT NULL,
   TASK_STATE_ON_RESET  integer             NOT NULL DEFAULT 3,
   VCTASK_QUEUE_TIME    bigint                        NOT NULL,
CONSTRAINT PK_VCI_RUNNING_VC_TASKS PRIMARY KEY (TASK_ID)
);

/*==============================================================
 Table: VCI_RESTORING_TEMPLATES
 Stores virtual machine targets of which the template flag
 needs to be restored.

 TARGET_UID                The MoId of the virtual machine.
 VC_CONTEXT                The context of the VC
 CREATION_TIME             The UTC time when the template flag is removed.
==============================================================*/
CREATE TABLE VCI_RESTORING_TEMPLATES (
   TARGET_UID           varchar(255),
   CREATION_TIME        bigint                     NOT NULL,
   VC_CONTEXT           varchar(128)     NOT NULL DEFAULT '.',
   CONSTRAINT PK_VCI_RESTORING_TEMPLATES PRIMARY KEY (TARGET_UID,
                                          VC_CONTEXT)
);

/*==============================================================
 Table: VCI_TARGET_ENTITIES
 Stores VC managed entities related to VUM

 TARGET_UID                The MoId of the managed entity.
 VC_CONTEXT                The context of the VC
 VMODL_TYPE                The VMODL type of the managed entity.
==============================================================*/
CREATE TABLE VCI_TARGET_ENTITIES  (
   TARGET_UID           varchar(255)                NOT NULL,
   VC_CONTEXT           varchar(128)    NOT NULL DEFAULT '.',
   VMODL_TYPE           varchar(255)                NOT NULL,
   CONSTRAINT PK_VCI_TGT_ENTS PRIMARY KEY (TARGET_UID, VC_CONTEXT)
);

/*==============================================================
Table: VCI_PACKAGE_FILES
==============================================================*/
CREATE TABLE VCI_PACKAGE_FILES (
       ID                  integer              NOT NULL,
       PACKAGE_ID          integer              NOT NULL,
       RELATIVE_PATH       varchar(255),
       DOWNLOAD_URL        varchar(255),
       VENDOR_CODE         varchar(64),
       CONSTRAINT PK_VCI_PACKAGE_FILES PRIMARY KEY (ID),
       CONSTRAINT FK_VCI_PACKAGE_FILES FOREIGN KEY (PACKAGE_ID)
          REFERENCES VCI_PACKAGES(ID)
);

/*==============================================================
 Table: VCI_PARAMETERS
 Stores VCI option parameters

 NAME                   The name of the parameter
 VALUE                  The value of the parameter
==============================================================*/
CREATE TABLE VCI_PARAMETERS (
   NAME                 varchar(255)                NOT NULL,
   VALUE                varchar(2000),
   CONSTRAINT PK_VCI_PARAMETERS PRIMARY KEY (NAME)
);

/* --------------------- VALM SCHEMA ----------------------------- */

/*==============================================================
 Table: VCI_VA_PRODUCTS

   ID                     Unique Id; generated sequence number
   VENDORNAME             Vendor name
   VENDORUUID             UUID of Vendor
   PRODUCTNAME            Product name (minus the release, e.g. "Database")
   PRODUCTRID             Product release ID (e.g. "10gr2")
   VENDORURL              Vendor URL (optional)
   PRODUCTURL             Product URL (optional)
   SUPPORTURL             Support URL (optional)
==============================================================*/
CREATE TABLE VCI_VA_PRODUCTS  (
   ID                      integer                    NOT NULL,
   VENDORNAME              varchar(255)               NOT NULL,
   VENDORUUID              varchar(255)               NOT NULL,
   PRODUCTNAME             varchar(255)               NOT NULL,
   PRODUCTRID              varchar(255)               NOT NULL,
   VENDORURL               text,
   PRODUCTURL              text,
   SUPPORTURL              text,
   CONSTRAINT PK_VCI_VA_PRODUCTS PRIMARY KEY (ID),
   CONSTRAINT UK_VCI_VA_PRODUCTS UNIQUE (VENDORUUID, PRODUCTRID)
);

/*==============================================================
 Table: VCI_VA_APPLIANCES

   VAID                   The MO ID of the appliance, used as primary key
   MGMTPORT               The port to contact appliance on to manage it
   MGMTPROTOCOL           The management protocol
   SUPPORTEDFEATURES      A freeform string for API feature compatibility
   VADKVERSION            VADK product version
   PRODUCTID              The ID of the product for this appliance
   UPDATEVERSION          The current patch version of the appliance
   DISPLAYVERSION         The current display version of the appliance
   SERIALNUMBER           The serial number of the appliance
   UPDATEURL              The software update URL of the appliance
   PRIVATEKEY             Private key (ASCII-Encoded) of the appliance
   CERTIFICATE            Certificate (ASCII-Encoded) of the appliance
==============================================================*/
CREATE TABLE VCI_VA_APPLIANCES  (
   VAID                    varchar(255)                NOT NULL,
   MGMTPORT                integer                     NOT NULL,
   MGMTPROTOCOL            integer                     NOT NULL,
   SUPPORTEDFEATURES       varchar(2000)               NOT NULL,
   VADKVERSION             varchar(255),
   PRODUCTID               integer,
   UPDATEVERSION           varchar(255),
   DISPLAYVERSION          varchar(255),
   SERIALNUMBER            varchar(255),
   UPDATEURL               text,
   PRIVATEKEY              text                         NOT NULL,
   CERTIFICATE             text                         NOT NULL,
   VC_CONTEXT              varchar(128)      NOT NULL DEFAULT '.',
   ORIGUPDATEURL           text,
   LASTGOODIP              varchar(40),
   CONSTRAINT PK_VCI_VA_APPLIANCES PRIMARY KEY (VAID, VC_CONTEXT),
   CONSTRAINT FK_VCI_VA_APP_PRODUCT_ID FOREIGN KEY (PRODUCTID)
       REFERENCES VCI_VA_PRODUCTS(ID) ON DELETE CASCADE
);

/*==============================================================
 Table: VCI_VA_CHANGELOG

   ID          Unique ID for the change. Primary key
   SUMMARY     Description of the change.
   CATEGORY    Change category: 0 - feature; 1 - security; 2 - bug fix
   SEVERITY    Change severity: 0 - low; 1 - moderate; 2 - important;
                  3 - critical
   REF_TYPE    Type of reference.
   REF_ID      Reference ID within the reference type
   REF_URL     URL with detailed description of the changes
==============================================================*/

CREATE TABLE VCI_VA_CHANGELOG (
   ID         integer         NOT NULL,
   SUMMARY    text            NOT NULL,
   CATEGORY   integer         NOT NULL,
   SEVERITY   integer         NOT NULL,
   REF_TYPE   varchar(255)    NOT NULL,
   REF_ID     varchar(255)    NOT NULL,
   REF_URL    varchar(1024),
   CONSTRAINT PK_VCI_VA_CHNGLG PRIMARY KEY (ID),
   CONSTRAINT UK_VCI_VA_CHNGLG UNIQUE (REF_TYPE, REF_ID)
);

/*===============================================================
Table: VCI_VA_FILES

   ID                File ID
   FILE_TYPE         Type of the file. rpm, deb or other (configuration)
   FILE_SIZE         Size of the file
   DOWNLOAD_URL      Source URL for the file
   RELATIVE_PATH     Relative path for the file
   CHECKSUM_TYPE     Checksum algorithm used
   CHECKSUM_VALUE    Checksum value of the EULA file
===============================================================*/

CREATE TABLE VCI_VA_FILES (
   ID                            integer                 NOT NULL,
   FILE_TYPE                     varchar(64),
   FILE_SIZE                     integer,
   DOWNLOAD_URL                  varchar(1024),
   RELATIVE_PATH                 varchar(1024),
   CHECKSUM_TYPE                 varchar(64)             NOT NULL,
   CHECKSUM_VALUE                varchar(255)            NOT NULL,
   CONSTRAINT PK_VCI_VA_PKG PRIMARY KEY (ID),
   CONSTRAINT UK_VCI_VA_FILES UNIQUE (RELATIVE_PATH)
);

/*================================================================
Table: VCI_VA_UPGRADES

   UPGRADE_ID              The upgrade. Used as the primary key
   TITLE                   A short description for the UI
   VERSION_NUMBER          Normalized version from title
   VENDOR                  Vendor Name
   VENDOR_UID              A Unique ID from the vendor
   PRODUCT_NAME            The product name
   PRODUCT_RID             A unique id of the product
   IMPACT                  Security Impact
   LOCALE                  Locale information, if any
   RELEASEDATE             Date when vendor released this update
   DOWNLOADTIME            When this update's metadata was downloaded
   VERSION_STRING          Description of the upgrade version
   SUMMARY                 Summary of the upgrade
   ALLOWED_SRC_VER         Allowed source versions on which this upgrade can
                              be applied
   UPGRADE_TYPE            Type of upgrade to be used
   UPGRADE_URI             URI to use during the upgrade
==================================================================*/
CREATE TABLE VCI_VA_UPGRADES (
   UPGRADE_ID           integer                       NOT NULL,
   TITLE                varchar(255)                  NOT NULL,
   VERSION_NUMBER       char(40)                      NOT NULL,
   VENDOR_NAME          varchar(128)                  NOT NULL,
   VENDOR_UID           varchar(255)                  NOT NULL,
   PRODUCT_NAME         varchar(255)                  NOT NULL,
   PRODUCT_RID          varchar(255)                  NOT NULL,
   IMPACT               integer                       NOT NULL,
   LOCALE               varchar(255),
   RELEASEDATE          timestamp,
   DOWNLOADTIME         timestamp                     NOT NULL,
   VERSION_STRING       varchar(255),
   SUMMARY              text,
   ALLOWED_SRC_VER      varchar(255),
   UPGRADE_TYPE         varchar(255),
   UPGRADE_URI          varchar(255),
   CONSTRAINT PK_VCI_VA_UPGRADES PRIMARY KEY (UPGRADE_ID),
   CONSTRAINT FK_VCI_VA_UPGRADES_REF_UPD FOREIGN KEY (UPGRADE_ID)
      REFERENCES VCI_UPDATES(ID) ON DELETE CASCADE,
   CONSTRAINT UK_VCI_VA_UPGRADES UNIQUE (VENDOR_UID, PRODUCT_RID, TITLE)
);
CREATE INDEX IDX_VCI_VA_UPGRADES ON VCI_VA_UPGRADES(VENDOR_NAME, PRODUCT_NAME, IMPACT);
CREATE INDEX IDX_VCI_VA_UPGRADES_PROD_ID ON VCI_VA_UPGRADES (PRODUCT_RID);

/*================================================================
 Table: VCI_VA_UPGRADE_BASELINES

  BASELINE_ID         Unique baseline id
  BASELINE_VERSION    Baseline version, incremented for updates
  SEQ_NUMBER          Used to maintain the rule ordering within
                        the same baseline
  DYNAMIC_SQL         Parsed result of info_blob in sql form
==============================================================*/
CREATE TABLE VCI_VA_UPGRADE_BASELINES  (
   BASELINE_ID          integer                       NOT NULL,
   BASELINE_VERSION     integer                       NOT NULL,
   SEQ_NUMBER           integer                       NOT NULL,
   ACTION               integer                       NOT NULL,
   DYNAMIC_SQL          text                          NOT NULL,
   CONSTRAINT PK_VCI_VA_UPG_BLS UNIQUE (BASELINE_ID,
                              BASELINE_VERSION,
                              SEQ_NUMBER),
   CONSTRAINT FK_VCI_VA_UPG_BL_REF_BL FOREIGN KEY (BASELINE_ID)
      REFERENCES VCI_BASELINES (ID) ON DELETE CASCADE
);

/*===============================================================
Table: VCI_VA_UPGRADE_CHANGELOG

   UPGRADE_ID        Upgrade ID
   CHANGE_ID         Change ID
   INTRO_VER         Version the change was introduced in
   AFFECTED_VER      Versions affected by the change
===============================================================*/

CREATE TABLE VCI_VA_UPGRADE_CHANGELOG (
   UPGRADE_ID           integer                       NOT NULL,
   CHANGE_ID            integer                       NOT NULL,
   INTRO_VER            varchar(255),
   AFFECTED_VER         varchar(255),
   CONSTRAINT PK_VA_UPG_CHNGLG PRIMARY KEY (UPGRADE_ID, CHANGE_ID),
   CONSTRAINT FK_VCI_UPG_CHNGLG_REF_UPG FOREIGN KEY (UPGRADE_ID)
      REFERENCES VCI_VA_UPGRADES(UPGRADE_ID),
   CONSTRAINT FK_VCI_UPG_CHNGLG_REF_CHNG FOREIGN KEY (CHANGE_ID)
      REFERENCES VCI_VA_CHANGELOG(ID)
);

 /*==============================================================
  Table: VCI_VMTOOLS_SCANRESULTS

   TARGET_UID           Identifier of the machine
   SCAN_RESULT          Scan result: toolsNotInstalled, toolsNotRunning,
                           toolsOld, or toolsOk
   SCANH_ID             The id of the scan history
   UPGRADE_ON_REBOOT    Scheduling status, e.g. 0 not scheduled; 1 scheduled
                           on reboot.
==================================================================*/
CREATE TABLE VCI_VMTOOLS_SCANRESULTS (
   TARGET_UID           varchar(255)                        NOT NULL,
   SCAN_RESULT          varchar(255)                        NOT NULL,
   SCANH_ID             integer,
   UPGRADE_ON_REBOOT    integer                            DEFAULT 0,
   CONSTRAINT PK_VCI_TOOLS_SRES PRIMARY KEY (TARGET_UID),
   CONSTRAINT FK_VCI_TOOLS_SRES_REF_SH FOREIGN KEY (SCANH_ID)
      REFERENCES VCI_SCANHISTORY (ID)
);

 /*==============================================================
  Table: VCI_VMHW_VERSIONS

 VMHW_ID          VM hardware version ID
 DESCRIPTION      Hardware version description
 FEATURES         Features of this VM HW version
 DEPRECATED       Is this VM HW version deprecated
 UPGRADEABLE_TO   Can a VM get upgraded to this HW version

==============================================================*/

CREATE TABLE VCI_VMHW_VERSIONS (
   VMHW_ID              integer                             NOT NULL,
   DESCRIPTION          text,
   FEATURES             text,
   DEPRECATED           integer                             NOT NULL,
   UPGRADEABLE_TO       integer                             NOT NULL,
   CONSTRAINT PK_VCI_VMHW_VERSIONS PRIMARY KEY (VMHW_ID)
);

 /*==============================================================
  Table: VCI_VMHW_COMPATIBILITY

 PRODUCT_ID       Product ID of the particular host version
 PRODUCT_VERSION  Version of the particular host version
 VMHW_ID          VM hardware ID, FK to VCI_VMHW_VERSIONS.VMHW_ID
 COMPATIBLE       Does this host version support this VM HW version
 IS_LATEST        Is this HW version the latest supported by this host version

==============================================================*/

CREATE TABLE VCI_VMHW_COMPATIBILITY (
   PRODUCT_ID        varchar(128)                        NOT NULL,
   PRODUCT_VERSION   varchar(255)                        NOT NULL,
   VMHW_ID           integer                             NOT NULL,
   COMPATIBLE        integer                   NOT NULL DEFAULT 0,
   IS_LATEST         integer                   NOT NULL DEFAULT 0,
   CONSTRAINT FK_VCI_COMP_REF_VERSIONS FOREIGN KEY (VMHW_ID)
      REFERENCES VCI_VMHW_VERSIONS (VMHW_ID) ON DELETE CASCADE
);

 /*==============================================================
  Table: VCI_VMHW_SCANRESULTS

 TARGET_UID          The UID of the target
 TARGET_VMHW_ID      The target VM HW version
 HOST_VMHW_ID        The latest HW version supported by the host
 ADDITIONAL_DETAILS  Additional optional details about the scan results
 SCANH_ID            ID of the scan history entry

==============================================================*/

CREATE TABLE VCI_VMHW_SCANRESULTS (
   TARGET_UID           varchar(255)                        NOT NULL,
   TARGET_VMHW_ID       integer                             NOT NULL,
   HOST_VMHW_ID         integer                             NOT NULL,
   ADDITIONAL_DETAILS   text,
   SCANH_ID             integer,
   CONSTRAINT PK_VCI_VMHW_SCANRESULTS PRIMARY KEY (TARGET_UID),
   CONSTRAINT FK_VCI_SRES_REF_VERSIONS FOREIGN KEY (TARGET_VMHW_ID)
      REFERENCES VCI_VMHW_VERSIONS (VMHW_ID) ON DELETE CASCADE,
   CONSTRAINT FK_VCI_VMHW_SCANRESULTS_REF_SH FOREIGN KEY (SCANH_ID)
      REFERENCES VCI_SCANHISTORY (ID)
);

/*===============================================================
Table: VCI_EULA

   ID               EULA ID
   CHECKSUM_TYPE    Checksum algorithm used
   CHECKSUM_VALUE   Checksum value of the EULA file
   PATH             Relative path where the EULA file is stored
===============================================================*/

CREATE TABLE VCI_EULA (
   ID                   integer                          NOT NULL,
   CHECKSUM_TYPE        varchar(64)                      NOT NULL,
   CHECKSUM_VALUE       varchar(255)                     NOT NULL,
   PATH                 varchar(255)                     NOT NULL,
   CONSTRAINT PK_VCI_EULA PRIMARY KEY (ID),
   constraint UK_VCI_EULA unique (CHECKSUM_TYPE, CHECKSUM_VALUE)
);

/*===============================================================
Table: VCI_UPDATE_EULAS

   UPDATE_ID         Update ID
   EULA_ID           EULA ID
   EULA_ACCEPTANCE   State of EULA acceptance: 0 - not accepted; 1 - accepted
===============================================================*/

CREATE TABLE VCI_UPDATE_EULAS (
   UPDATE_ID            integer                          NOT NULL,
   EULA_ID              integer                          NOT NULL,
   EULA_ACCEPTANCE      integer                          DEFAULT 0,
   CONSTRAINT PK_VA_UPD_EULA PRIMARY KEY (UPDATE_ID, EULA_ID),
   CONSTRAINT FK_VCI_UPD_EULA_REF_UPD FOREIGN KEY (UPDATE_ID)
      REFERENCES VCI_UPDATES(ID),
   CONSTRAINT FK_VCI_UPD_EULA_REF_EULA FOREIGN KEY (EULA_ID)
      REFERENCES VCI_EULA(ID)
);

/*===============================================================
Table: VCI_VA_UPGRADE_FILES

   UPGRADE_ID     Upgrade ID
   FILE_ID        File ID
===============================================================*/

CREATE TABLE VCI_VA_UPGRADE_FILES (
   UPGRADE_ID           integer                          NOT NULL,
   FILE_ID              integer                          NOT NULL,
   CONSTRAINT PK_VA_UPG_PKG PRIMARY KEY (UPGRADE_ID, FILE_ID),
   CONSTRAINT FK_VA_UPG_PKG_REF_UPG FOREIGN KEY (UPGRADE_ID)
      REFERENCES VCI_VA_UPGRADES(UPGRADE_ID),
   CONSTRAINT FK_VA_UPG_PKG_REF_PKG FOREIGN KEY (FILE_ID)
      REFERENCES VCI_VA_FILES(ID)
);

/*==============================================================
Table: VCI_OPERATION_HISTORY

 This table stores a history of all operations (scan/remediation/staging)
 performed at leaf node level. Stale data in this table may
 be periodically cleaned if user subscribes to VUM database aging policy.

 ID                     Unique Id; generated sequence number
 TARGET_UID             uid of the target being scanned
 VC_CONTEXT             The context of the VC
 STARTTIME              Scan start time
 ENDTIME                Scan end time
 OPERATION_STATUS       Scan status: 0 FAILURE 1 SUCCESS
 REASON                 Reason if any in case of failure

==============================================================*/
CREATE TABLE VCI_OPERATION_HISTORY  (
   ID                  integer                              NOT NULL,
   OPERATION_TYPE      integer                              NOT NULL,
   TARGET_UID          varchar(255)                         NOT NULL,
   VC_CONTEXT          varchar(128)             NOT NULL DEFAULT '.',
   STARTTIME           timestamp                            NOT NULL,
   ENDTIME             timestamp,
   OPERATION_STATUS    integer                              NOT NULL,
   REASON              text,
   CONSTRAINT PK_VCI_OPERATION_HISTORY PRIMARY KEY (ID)
);

 /*==============================================================
  Table: VCI_OPERATION_HISTORY_SUBTASKS

 OPERATION_ID        Parent operation
 SUB_TASK_ID         Sub task being spawned as part of this operation
 SUB_TASK_TYPE       Type of sub task, e.g. PRE_SCAN/REMEDIATE/STAGE/POST_SCAN
 SUB_TASK_STATUS     Sub task status
==============================================================*/

CREATE TABLE VCI_OPERATION_HISTORY_SUBTASKS  (
   OPERATION_ID      integer                              NOT NULL,
   SUB_TASK_ID       integer                              NOT NULL,
   SUB_TASK_TYPE     integer                              NOT NULL,
   SUB_TASK_STATUS   integer                              NOT NULL,
   CONSTRAINT PK_VCI_OP_HIST_SUB UNIQUE (OPERATION_ID, SUB_TASK_ID,
                                         SUB_TASK_TYPE),
   CONSTRAINT FK_VCI_OP_HIST_SUB_OP FOREIGN KEY (OPERATION_ID)
      REFERENCES VCI_OPERATION_HISTORY (ID) ON DELETE CASCADE
);

 /*==============================================================
  Table: VCI_SCANRESULTS_CONFRESUPD

 For an update that conflicts with the host, stores information about the latest
 version of update (if any) that obsoletes this update, that is applicable to
 the host and that does not conflict with it.
 NOTE: Used only by DVS scan VMODL.

 SCANH_ID                    Scan operation
 TARGET_UID                  UID of the entity being scanned.
 UPDATE_STATUS               Status of this update:
                              Missing/ConflictWithHost/ConflictWithDepot
 CONFLICTING_UPDATE_METAUID  ID of the software update that conflicts with the
                              entity
 RESOLVING_UPDATE_METAUID    ID of the software update that resolves the
                              conflict
 ================================================================*/
CREATE TABLE VCI_SCANRESULTS_CONFRESUPD  (
   SCANH_ID                      integer                       NOT NULL,
   TARGET_UID                    varchar(255)                  NOT NULL,
   UPDATE_STATUS                 integer                       NOT NULL,
   CONFLICTING_UPDATE_METAUID    varchar(255)                  NOT NULL,
   RESOLVING_UPDATE_METAUID      varchar(255)                  NOT NULL,
   CONSTRAINT PK_VCI_CFRESUPD PRIMARY KEY (SCANH_ID, TARGET_UID,
                                         CONFLICTING_UPDATE_METAUID,
                                         RESOLVING_UPDATE_METAUID),
   CONSTRAINT FK_VCI_CFRESUPD_REF_SH FOREIGN KEY (SCANH_ID)
      REFERENCES VCI_SCANHISTORY (ID) ON DELETE CASCADE,
   CONSTRAINT FK_VCI_CFRESUPD_REF_SIG FOREIGN KEY (CONFLICTING_UPDATE_METAUID)
      REFERENCES VCI_UPDATES (META_UID)
);

 /*==============================================================
  Table:   VCI_TASK_STATS

 Statistics collection for VCI tasks.

 ID                     A unique id
 NAME                   The name of the task
 TYPE                   The task type
 CREATE_TIME            The time stamp the task is created
 READY_TIME             The time the task is ready to be scheduled
                           (in microseconds).
 QUEUE_TIME             The time the task is queued (in microseconds)
 RUN_TIME               The time the task is executed including the time in the
                           queue (in microseconds)
 STATE                  The task state when it is finished
                           (see Vim.TaskInfo.State)
 ERROR                  The error of the task if it fails
 PARENT_ID              The unique id of the parent task (see ID)
 TARGET_UID             The UID of the entity being operated.
 VC_CONTEXT             The VC context of the target
 ================================================================*/
CREATE TABLE VCI_TASK_STATS  (
   ID                   integer                       NOT NULL,
   NAME                 varchar(255)                  NOT NULL,
   TYPE                 varchar(255)                  NOT NULL,
   CREATE_TIME          timestamp                     NOT NULL,
   READY_TIME           bigint,
   QUEUE_TIME           bigint,
   RUN_TIME             bigint,
   STATE                integer,
   ERROR                varchar(1024),
   PARENT_ID            integer,
   TARGET_UID           varchar(255),
   VC_CONTEXT           varchar(128),
   CONSTRAINT PK_VCI_TASK_STATS PRIMARY KEY (ID)
);

 /*==============================================================
  Table:   VCI_VC_CLEANUP_ACTION

 VC actions to be executed during the VUM starts up to clean up VC from
 previous VUM instance.

 ID                     A unique id
 VC_OBJECT              The VC object
 ACTION                 The action
 CREATE_TIME            The time stamp (in microseconds) the row is created
 ================================================================*/
CREATE TABLE VCI_VC_CLEANUP_ACTION  (
   ID                   integer                       NOT NULL,
   VC_OBJECT            varchar(1024)                 NOT NULL,
   ACTION               varchar(2000)                 NOT NULL,
   CREATE_TIME          bigint                        NOT NULL,
   CONSTRAINT PK_VCI_VC_CLEANUP PRIMARY KEY (ID)
);

 /*==============================================================
  Table: VCI_UPDATE_CONFLICT_INFO

 TARGET_UID         The moid for the target entity
 INPUT_ID           The update id that is conflicting
 CONFLICTS_WITH_ID  The update id that conflicts with the previous id.
                    Unused (-1) if it's a host conflict
 CONFLICT_TYPE      The type of conflict:
                    host/depot/host indirect/depot indirect
==============================================================*/
CREATE TABLE VCI_UPDATE_CONFLICT_INFO   (
   TARGET_UID                varchar(255)             NOT NULL,
   INPUT_ID                  integer                  NOT NULL,
   CONFLICTS_WITH_ID         integer,
   CONFLICT_TYPE             integer                  NOT NULL,
   CONSTRAINT PK_VCI_UPDATE_CONFLICT_INFO PRIMARY KEY (TARGET_UID, INPUT_ID, CONFLICTS_WITH_ID, CONFLICT_TYPE),
   CONSTRAINT FK_VCI_UCI_UPDATE FOREIGN KEY (INPUT_ID)
      REFERENCES VCI_UPDATES (ID) ON DELETE CASCADE
);

/*==============================================================
Table: VCI_UPGRADE_OFFLINE_IDS

   UPGRADE_ID          Foreign key to VCI_HOST_UPGRADES table; indicates the
                        upgrade ID to which an offline bundle update ID is
                        associated with.
   OFFLINE_UPGRADE_ID  Foreign key to VCI_UPDATES table; indicates offline
                        bundle ID
==============================================================*/
CREATE TABLE VCI_UPGRADE_OFFLINE_IDS  (
   UPGRADE_ID                 integer                  NOT NULL,
   OFFLINE_UPGRADE_ID         integer                  NOT NULL,
   CONSTRAINT PK_VCI_UPG_OFF PRIMARY KEY (UPGRADE_ID, OFFLINE_UPGRADE_ID),
   CONSTRAINT FK_VCI_UPG_OFF_REF_UPG FOREIGN KEY (UPGRADE_ID)
      REFERENCES VCI_HOST_UPGRADES (ID) ON DELETE CASCADE,
   CONSTRAINT FK_VCI_UPG_OFF_REF_OFF FOREIGN KEY (OFFLINE_UPGRADE_ID)
      REFERENCES VCI_UPDATES (ID)
);

/*================================================================
  VIEWS
 ==================================================================*/

/*==============================================================
   View: VUMV_VERSION
   Update Manager version information

   VERSION                    VUM Server version (x.y.z format) e.g. 1.0.0
   DATABASE_SCHEMA_VERSION    VUM database schema version (increasing integer
                                 value) e.g. 1
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_VERSION AS
SELECT VERSION_STRING AS VERSION,
       DB_SCHEMA_VERSION_ID AS DATABASE_SCHEMA_VERSION
FROM VCI_VERSION
WHERE VERSION_ID = 1
;

/*==============================================================
   View: VUMV_UPDATES
   The view gives detail information about software update (patch) metadata

   UPDATE_ID       Software Update unique ID generated by VUM
   TYPE            The target type, like VM, host, VA.
   TITLE           Title of the update
   DESCRIPTION     Description
   META_UID        A unique ID provided by vendor for this update.
                     (e.g. MS12444 for Microsoft Updates)
   SEVERITY        Update severity imformation e.g. Critical, Moderate
   RELEASE_DATE    Date this update was released by vendor.
   DOWNLOAD_TIME   Date and time this update was downloaded by VUM server into
                     it's database
   SPECIAL_ATTRIBUTE Any special attribute associated with this update. E.g. All
                     Microsoft Service packs will be marked as 'Service Pack'.
   UPDATECATEGORY  Defines the category like Patch, Upgrade etc for Update.
   COMPONENT       Target component, like HOST_GENERAL, HOST_THIRDPARTY, etc
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_UPDATES AS
SELECT ID AS UPDATE_ID,
       CASE TYPE
         WHEN 0 THEN 'VM'
         WHEN 1 THEN 'HOST'
         WHEN 2 THEN 'VA'
       END AS TYPE,
       TITLE,
       DESCRIPTION,
       META_UID,
       CASE IMPACT
         WHEN 0 THEN 'Not Applicable'
         WHEN 1 THEN 'Low'
         WHEN 2 THEN 'Moderate'
         WHEN 3 THEN 'Important'
         WHEN 4 THEN 'Critical'
         WHEN 5 THEN 'HostGeneral'
         WHEN 6 THEN 'HostSecurity'
       END AS SEVERITY,
       RELEASEDATE AS RELEASE_DATE,
       DOWNLOADTIME AS DOWNLOAD_TIME,
       CASE SERVICE_PACK
         WHEN 1 THEN 'Service Pack'
       END AS SPECIAL_ATTRIBUTE,
       CASE CATEGORY
         WHEN 0 THEN 'Patch'
         WHEN 1 THEN 'Upgrade'
         WHEN 2 THEN 'Configuration'
         WHEN 3 THEN 'Extension'
       END AS UpdateCategory,
       CASE COMPONENT
         WHEN 0 THEN 'HOST_GENERAL'
         WHEN 1 THEN 'HOST_THIRDPARTY'
         WHEN 2 THEN 'VM_GENERAL'
         WHEN 3 THEN 'VM_TOOLS'
         WHEN 4 THEN 'VM_HARDWAREVERSION'
         WHEN 5 THEN 'VA_GENERAL'
       END AS COMPONENT
FROM VCI_UPDATES
;

/*==========================================================================
   View: VUMV_HOST_UPGRADES
   The view gives detail information about host upgrade packages

   RELEASE_ID     Database generated ID, it refers to vumv_updates update_id
   PRODUCT        "esx" or "embeddedEsx"
   VERSION        "x.y.z"
   BUILD_NUMBER
   DISPLAY_NAME   Name that can be displayed to the user
   FILE_NAME      Relative path to the upgrade package.  Path is relative to
                     patchstore
 ================================================================*/
CREATE VIEW VUMV_HOST_UPGRADES AS
SELECT RELEASE_ID,
       PRODUCT,
       VERSION,
       BUILD_NUMBER,
       DISPLAY_NAME,
       FILE_NAME
FROM   VCI_HOST_UPGRADES
;

/*==============================================================
   View: VUMV_VA_UPGRADES
   The view gives detail information about VA upgrade packages

   UPGRADE_ID              The upgrade. Used as the primary key
   TITLE                   A short description for the UI
   VENDOR                  Vendor Name
   VENDOR_UID              A Unique ID from the vendor
   PRODUCT_NAME            The product name
   PRODUCT_RID             A unique id of the product
   SEVERITY                Security Impact
   LOCALE                  Locale information, if any
   RELEASEDATE             Date when vendor released this update
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_VA_UPGRADES AS
SELECT   UPGRADE_ID    ,
         TITLE         ,
         VENDOR_NAME   ,
         VENDOR_UID    ,
         PRODUCT_NAME  ,
         PRODUCT_RID   ,
         CASE IMPACT
            WHEN 1 THEN 'Low'
            WHEN 2 THEN 'Moderate'
            WHEN 3 THEN 'Important'
            WHEN 4 THEN 'Critical'
         END AS SEVERITY,
         LOCALE,
         RELEASEDATE
FROM VCI_VA_UPGRADES
;

/*===============================================================
   View: VUMV_PATCHES
   Patch Binary metadata for VM/HOST updates.

   DOWNLOAD_URL    URL for downloading the package
   PATCH_ID        Unique ID for this patch generated by VUM server
   TYPE            The patch type, VM, HOST, VA.
   NAME            Name of the patch.
   PATCH_SIZE      Size of the patch.
   DOWNLOAD_TIME   The time when patch was downloaded.
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_PATCHES AS
SELECT vp.DOWNLOADURL AS DOWNLOADURL,
       vp.ID AS PATCH_ID,
       CASE vu.TYPE
         WHEN 0 THEN 'VM'
         WHEN 1 THEN 'HOST'
       END AS TYPE,
       vp.NAME AS NAME,
       vp.DOWNLOADTIME AS DOWNLOAD_TIME,
       vp.PKG_SIZE AS PATCH_SIZE
FROM VCI_PACKAGES vp JOIN VCI_UPDATE_PACKAGES vup ON (vp.ID = vup.PACKAGE_ID)
     JOIN  VCI_UPDATES vu ON (vup.UPDATE_ID = vu.ID)
WHERE vp.DOWNLOADURL IS NOT NULL
UNION
SELECT DISTINCT (pl.DOWNLOADURL) AS DOWNLOADURL,
       vp.ID AS PATCH_ID,
       CASE vu.TYPE
         WHEN 0 THEN 'VM'
         WHEN 1 THEN 'HOST'
         WHEN 2 THEN 'VA'
       END AS TYPE,
       vp.NAME AS NAME,
       vp.DOWNLOADTIME AS DOWNLOAD_TIME,
       vp.PKG_SIZE AS PATCH_SIZE
FROM VCI_PACKAGES vp JOIN VCI_UPDATE_PACKAGES vup ON (vp.ID = vup.PACKAGE_ID)
     JOIN  VCI_UPDATES vu ON (vup.UPDATE_ID = vu.ID)
     JOIN VCI_PACKAGE_LOCALES pl ON (vp.ID = pl.PACKAGE_ID)
WHERE vp.DOWNLOADURL IS NULL
;

/*===============================================================
   View: VUMV_BASELINES
   VUM Baseline details.

   BASELINE_ID          Unique ID for this baseline generated by VUM server
   NAME                 Name
   BASELINE_VERSION     When baseline is changed, the old version still
                           retained in db
   TYPE                 Baseline types, e.g. VM, HOST, VA.
   BASELINE_UPDATE_TYPE The baseline is dynamic, fixed, or both.
   TARGET_COMPONENT     Type of targets this baseline applies to
   BASELINE_CATEGORY    The baseline is for patch, upgrade, or configuration
   DELETED              If the baseline has been deleted?
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_BASELINES AS
SELECT ID AS BASELINE_ID,
       NAME,
       VERSION AS BASELINE_VERSION,
       CASE TYPE
         WHEN 0 THEN 'VM'
         WHEN 1 THEN 'HOST'
         WHEN 2 THEN 'VA'
       END AS TYPE,
       CASE UPDATETYPE
         WHEN 0 THEN 'Dynamic'
         WHEN 1 THEN 'Fixed'
         WHEN 2 THEN 'Both'
       END AS BASELINE_UPDATE_TYPE,
       CASE TARGET_COMPONENT
         WHEN 0 THEN 'HOST_GENERAL'
         WHEN 1 THEN 'HOST_THIRDPARTY'
         WHEN 2 THEN 'VM_GENERAL'
         WHEN 3 THEN 'VM_TOOLS'
         WHEN 4 THEN 'VM_HARDWAREVERSION'
         WHEN 5 THEN 'VA_GENERAL'
       END AS TARGET_COMPONENT,
       CASE CATEGORY
         WHEN 0 THEN 'Patch'
         WHEN 1 THEN 'Upgrade'
         WHEN 2 THEN 'Configuration'
         WHEN 3 THEN 'Extension'
       END AS BASELINE_CATEGORY,
       CASE DELETED
         WHEN 0 THEN 'NO'
         WHEN 1 THEN 'YES'
       END AS DELETED
FROM VCI_BASELINES
;

/*===============================================================
   View: VUMV_BASELINE_GROUPS
   View for baseline group information.

    BASELINE_GROUP_ID    The unique Id of baseline group; generated sequence
                           number
    NAME                 The name of the baseline group
    TYPE                 Target type: VM, HOST, VA
    DESCRIPTION          The description of the baseline group
    DELETED              Whether or not the baseline group is deleted
    LASTUPDATED          Last update time
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_BASELINE_GROUPS AS
SELECT   BASELINE_GROUP_ID,
         VERSION          ,
         NAME             ,
         TYPE             ,
         DESCRIPTION      ,
         DELETED          ,
         LASTUPDATED
FROM VCI_BASELINE_GROUPS
;

/*===============================================================
   View: VUMV_BASELINE_GROUP_MEMBERS
   View for the baseline and baseline group relationship.

   BASELINE_GROUP_ID        The ID refers to the
                              VUMV_BASELINE_GROUPS.BASELINE_GROUP_ID
   BASELINE_GROUP_VERSION   The baseline group bersion
   BASELINE_ID              The VUMV_BASELINES.BASELINE_ID
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_BASELINE_GROUP_MEMBERS AS
SELECT BASELINE_GROUP_ID      ,
       BASELINE_GROUP_VERSION ,
       BASELINE_ID
FROM VCI_BASELINE_GROUP_BASELINES
;

/*===============================================================
   View: VUMV_PRODUCTS
   Product metadata (includes Operating systems and applications).

   PRODUCT_ID     Unique ID for this product generated by VUM server
   NAME           Name
   VERSION        Product version
   FAMILY         e.g. 'Windows' or 'ESX'
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_PRODUCTS AS
SELECT ID AS PRODUCT_ID,
       NAME,
       VERSION,
       CASE FAMILY
         WHEN 1 THEN 'Windows'
         WHEN 2 THEN 'Linux'
         WHEN 3 THEN 'ESX'
         WHEN 4 THEN 'Embedded ESX'
         END AS FAMILY
FROM VCI_PLATFORMS
;

/*===============================================================
   View: VUMV_BASELINE_ENTITY
   Targets that this baseline is attached to.

   BASELINE_ID     Baseline ID (foreign key, VUMV_BASELINES)
   ENTITY_UID      Update ID of the entity (VC generated MOID)
 ================================================================*/

CREATE OR REPLACE VIEW VUMV_BASELINE_ENTITY AS
SELECT BASELINE_ID,
       TARGET_UID AS ENTITY_UID
FROM VCI_TARGET_BASELINES
;

/*===============================================================
   View: VUMV_UPDATE_PATCHES
   Patch binaries that correspond to this Software Update

   UPDATE_ID     Software Update ID (foreign key, VUMV_UPDATES)
   PATCH_UID     Patch ID (foreign key, VUMV_PATCHES)
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_UPDATE_PATCHES AS
SELECT UPDATE_ID,
       PACKAGE_ID AS PATCH_ID
FROM VCI_UPDATE_PACKAGES
;

/*===============================================================
   View: VUMV_UPDATE_PRODUCT
   Products (Operating systems and applications) that this Software Update
   applies to.

   UPDATE_ID        Software Update ID (foreign key, VUMV_UPDATES)
   PRODUCT_UID      Product ID (foreign key, VUMV_PRODUCTS)
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_UPDATE_PRODUCT AS
SELECT UPDATE_ID,
       PLATFORM_ID AS PRODUCT_ID
FROM VCI_UPDATE_PLATFORMS
;

/*===============================================================
   View: VUMV_ENTITY_SCAN_HISTORY
   History of Scan operations

   SCAN_ID           Unique ID generated by VUM server
   START_TIME        Start time
   END_TIME          End time
   ENTITY_UID        UID of the entity scan was initiated on
   SCAN_STATUS       Result of scan operation
                        e.g. 'Success'/'Failure'/'Cancelled'
   SCAN_TYPE         patch or upgrade
   TARGET_COMPONENT  HOST_GENERAL, HOST_THIRDPARTY, VM_GENERAL, etc
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_ENTITY_SCAN_HISTORY AS
SELECT ID AS SCAN_ID,
       TARGET_UID AS ENTITY_UID,
       STARTTIME AS START_TIME,
       ENDTIME AS END_TIME,
       CASE SCAN_STATUS
          WHEN 0 THEN 'SUCCESS'
          WHEN 1 THEN 'FAILURE'
          WHEN 2 THEN 'CANCELLED'
       END AS SCAN_STATUS,
       REASON AS FAILURE_REASON
FROM VCI_SCANHISTORY
;

/*===============================================================
   View: VUMV_ENTITY_REMEDIATION_HISTORY
   History of Remediation operations

   SCAN_ID          Unique ID generated by VUM server
   START_TIME       Start time
   END_TIME         End time
   ENTITY_UID       UID of the entity scan was initiated on
   SCAN_STATUS      Result of scan operation
                        e.g. 'Success'/'Failure'/'Cancelled'
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_ENTITY_REMEDIATION_HIST AS
SELECT ID AS REMEDIATION_ID,
       TARGET_UID AS ENTITY_UID,
       STARTTIME AS START_TIME,
       ENDTIME AS END_TIME,
       CASE REMEDIATION_STATUS
          WHEN 0 THEN 'SUCCESS'
          WHEN 1 THEN 'FAILURE'
          WHEN 2 THEN 'CANCELLED'
       END AS REMEDIATION_STATUS,
       ISSNAPSHOTTAKEN AS IS_SNAPSHOT_TAKEN
FROM VCI_REMEDIATION_HISTORY
;

/*===============================================================
   View: VUMV_UPDATE_PRODUCT_DETAILS
   Convenience View for Products (Operating systems and applications) that
   this Software Update applies to.

   UPDATE_METAUID        Software Update ID (foreign key, VUMV_UPDATES)
   UPDATE_TITLE          Update Title
   UPDATE_SEVERITY       Update impact information
   PRODUCT_NAME          Product name
   PRODUCT_VERSION       Product version
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_UPDATE_PRODUCT_DETAILS AS
SELECT vu.META_UID AS UPDATE_METAUID,
       vu.TITLE AS UPDATE_TITLE,
       vu.SEVERITY AS UPDATE_SEVERITY,
       vp.NAME AS PRODUCT_NAME,
       vp.VERSION AS PRODUCT_VERSION
FROM VCI_UPDATE_PLATFORMS vup, VUMV_UPDATES vu, VCI_PLATFORMS vp
WHERE vu.UPDATE_ID = vup.UPDATE_ID AND vup.PLATFORM_ID = vp.ID
;

/*===============================================================
   View: VUMV_BASELINE_UPDATE_DETAILS
   Convenience View for updates or upgrades that are part of a baseline
   (latest version)

   BASELINE_NAME         Baseline name
   BASELINE_ID
   BASELINE_VERSION
   TYPE                  Baseline types, e.g. VM, HOST, VA.
   TARGET_COMPONENT      Type of targets this baseline applies to
   BASELINE_UPDATE_TYPE  Baseline update type e.g. static or dynamic
   UPDATE_METAUID        Update metauid
   TITLE                 Update title
   SEVERITY              Update severity
   ID                    Database generated ID.  For updates/patches, it is
                           update_id, for host upgrades, it is release_id,
                           for VA upgrade, it is UPGRADE_ID
 ================================================================*/

CREATE OR REPLACE VIEW VUMV_BASELINE_UPDATE_DETAILS AS
SELECT vb.NAME AS BASELINE_NAME,
       vb.BASELINE_ID,
       vb.BASELINE_VERSION,
       vb.TYPE,
       vb.TARGET_COMPONENT,
       vb.BASELINE_UPDATE_TYPE,
       vu.META_UID AS UPDATE_METAUID,
       vu.TITLE AS TITLE,
       vu.SEVERITY,
       vu.UPDATE_ID AS ID
FROM VCI_UPDATE_BASELINES_EXPANDED vub JOIN VUMV_BASELINES vb
     ON (vb.BASELINE_ID = vub.BASELINE_ID AND vb.BASELINE_VERSION = vub.BASELINE_VERSION)
     JOIN VUMV_UPDATES vu ON (vub.UPDATE_ID = vu.UPDATE_ID)
UNION
SELECT vb.NAME AS BASELINE_NAME,
       vb.BASELINE_ID,
       vb.BASELINE_VERSION,
       vb.TYPE,
       vb.TARGET_COMPONENT,
       vb.BASELINE_UPDATE_TYPE,
       vu.META_UID AS UPDATE_METAUID,
       vu.TITLE AS UPDATE_TITLE,
       vu.SEVERITY,
       vu.UPDATE_ID AS ID
FROM VCI_HOST_UPGRADE_BASELINES vub JOIN VUMV_BASELINES vb
     ON (vb.BASELINE_ID = vub.BASELINE_ID AND vb.BASELINE_VERSION = vub.BASELINE_VERSION)
     JOIN VUMV_UPDATES vu ON (vub.RELEASE_ID = vu.UPDATE_ID);

/*===============================================================
   View: VUMV_ENTITY_SCAN_RESULTS
   Convenience View for the latest status of given entity for an update,
   or upgrade.

   SCANH_ID           Database generated ID identifying a scan.
   ENTITY_UID         Entity UID (VC assigned MoId)
   SCAN_START_TIME    Scan start time
   SCAN_END_TIME      Scan end time
   UPDATE_METAUID     Update metauid
   UPDATE_TITLE       Update title
   UPDATE_SEVERITY    Update severity
   ENTITY_STATUS      Status of this entity wrt this update, Missing,
                        Installed, etc
 ================================================================*/
CREATE OR REPLACE VIEW VUMV_ENTITY_SCAN_RESULTS AS
       SELECT vs.ID  AS SCANH_ID,
       vs.TARGET_UID AS ENTITY_UID,
       vs.STARTTIME AS SCAN_START_TIME,
       vs.ENDTIME AS SCAN_END_TIME,
       vu.META_UID AS UPDATE_METAUID,
       vu.TITLE AS UPDATE_TITLE,
       vu.SEVERITY AS UPDATE_SEVERITY,
       COALESCE (
          CASE vst.TARGET_STATUS
              WHEN 0 THEN 'Missing'
              WHEN 1 THEN 'Installed'
              WHEN 2 THEN 'NotApplicable'
              WHEN 3 THEN 'Unknown'
              WHEN 4 THEN 'Staged'
              WHEN 5 THEN 'Conflict'
              WHEN 6 THEN 'ObsoletedByHost'
              WHEN 7 THEN 'MissingPackage'
              WHEN 8 THEN 'NotInstallable'
              WHEN 9 THEN 'NewModule'
              WHEN 10 THEN 'UnsupportedUpgrade'
              WHEN 11 THEN 'IncompatibleHardware'
              WHEN 12 THEN 'ConflictingNewModule'
              WHEN 13 THEN 'InstalledRecalled'
              WHEN 14 THEN 'NotApplicableRecalled'
              WHEN 15 THEN 'PrerequisiteRecalled'
              WHEN 16 THEN 'MissingRecalled'
              WHEN 17 THEN 'NewModuleRecalled'
              WHEN 18 THEN 'PrerequisiteRecalledInstalled'
              WHEN 19 THEN 'IncompatibleSoftwareConfig'
            END,
            CASE
            WHEN (vu.DOWNLOAD_TIME <= vs.STARTTIME) THEN 'Not Applicable'
            ELSE 'Unknown'
            END ) AS ENTITY_STATUS
FROM VCI_SCANRESULTS vs JOIN VUMV_UPDATES vu ON
                     ((CASE vs.TARGET_COMPONENT
                            WHEN 0 THEN 'HOST_GENERAL'
                            WHEN 1 THEN 'HOST_THIRDPARTY'
                            WHEN 2 THEN 'VM_GENERAL'
                            WHEN 3 THEN 'VM_TOOLS'
                            WHEN 4 THEN 'VM_HARDWAREVERSION'
                            WHEN 5 THEN 'VA_GENERAL'
                     END) = vu.COMPONENT
                            AND
                     (CASE vs.SCAN_TYPE
                           WHEN 0 THEN 'Patch'
                           WHEN 1 THEN 'Upgrade'
                           WHEN 2 THEN 'Configuration'
                           WHEN 3 THEN 'Extension'
                     END) = vu.UPDATECATEGORY )
       LEFT OUTER JOIN VCI_SCANRESULTS_TARGETS vst
         ON ( vst.UPDATE_ID = vu.UPDATE_ID
       AND vst.TARGET_UID = vs.TARGET_UID );

/*===============================================================
   View: VUMV_VMTOOLS_SCAN_RESULTS
   Convenience View for the latest status of given vm on vmtools installation.

   SCANH_ID           Database generated ID identifying a scan.
   ENTITY_UID         Entity UID (VC assigned MoId)
   SCAN_START_TIME    Scan start time
   SCAN_END_TIME      Scan end time
   ENTITY_STATUS      Status of this entity wrt this update, installed,
                        notinstalled, etc
 ================================================================*/
CREATE VIEW VUMV_VMTOOLS_SCAN_RESULTS AS
SELECT vst.SCANH_ID  AS SCANH_ID,
       vs.TARGET_UID AS ENTITY_UID,
       vs.STARTTIME AS SCAN_START_TIME,
       vs.ENDTIME AS SCAN_END_TIME,
       vst.SCAN_RESULT as ENTITY_STATUS
FROM VCI_VMTOOLS_SCANRESULTS vst JOIN VCI_SCANHISTORY vs
   ON (vst.SCANH_ID = vs.ID)
-- max of the scan ID, latest scan for an entity
WHERE NOT EXISTS (SELECT NULL
                  FROM VCI_SCANHISTORY s
                  WHERE vs.ID < s.ID AND
                        vs.TARGET_UID = s.TARGET_UID AND
                        s.TARGET_COMPONENT = 3 AND
                        s.SCAN_STATUS = 0);

/*===============================================================
   View: VUMV_VMHW_SCAN_RESULTS
   Convenience View for the latest status of given vm on its hardware version.

   SCANH_ID           Database generated ID identifying a scan.
   ENTITY_UID         Entity UID (VC assigned MoId)
   SCAN_START_TIME    Scan start time
   SCAN_END_TIME      Scan end time
   VM_HW_VERSION      VM's current hardware version
   HOST_HW_VERSION    Host recommended hardware version
 ================================================================*/
CREATE VIEW VUMV_VMHW_SCAN_RESULTS AS
SELECT vst.SCANH_ID  AS SCANH_ID,
       vs.TARGET_UID AS ENTITY_UID,
       vs.STARTTIME AS SCAN_START_TIME,
       vs.ENDTIME AS SCAN_END_TIME,
       vst.TARGET_VMHW_ID AS VM_HW_VERSION,
       vst.HOST_VMHW_ID AS HOST_HW_VERSION
FROM VCI_VMHW_SCANRESULTS vst JOIN VCI_SCANHISTORY vs ON (vst.SCANH_ID = vs.ID)
-- max of the scan ID, latest scan for an entity
WHERE NOT EXISTS (SELECT NULL
                  FROM VCI_SCANHISTORY s
                  WHERE vs.ID < s.ID AND
                        vs.TARGET_UID = s.TARGET_UID AND
                        s.TARGET_COMPONENT = 4 AND
                        s.SCAN_STATUS = 0);

/*==============================================================
 VIEW: VUMV_VA_APPLIANCES

   VAID                   The MO ID of the appliance, used as primary key
   MGMTPORT               The port to contact appliance on to manage it
   MGMTPROTOCOL           The management protocol
   SUPPORTEDFEATURES      A freeform string for API feature compatibility
   LASTGOODIP             The last known good IP this VA had. Can be IPV6 or V4
   VADKVERSION            VADK product version
   PRODUCTID              The ID in VUMV_VA_PRODUCTS
   UPDATEVERSION          The current patch version of the appliance
   DISPLAYVERSION         The current patch display version of the appliance
   SERIALNUMBER           The serial number of the appliance
   UPDATEURL              The current software update URL of the appliance
   ORIGUPDATEURL          The factory default software update URL of the
                              appliance

==============================================================*/
CREATE VIEW VUMV_VA_APPLIANCE AS
SELECT   VAID             ,
         MGMTPORT         ,
         MGMTPROTOCOL     ,
         SUPPORTEDFEATURES,
         LASTGOODIP       ,
         VADKVERSION      ,
         PRODUCTID        ,
         UPDATEVERSION    ,
         DISPLAYVERSION   ,
         SERIALNUMBER     ,
         UPDATEURL        ,
         ORIGUPDATEURL
FROM VCI_VA_APPLIANCES
;

/*==============================================================
 VIEW: VUMV_VA_PRODUCTS

   ID                     Unique Id; generated sequence number
   VENDORNAME             Vendor name
   VENDORUUID             UUID of Vendor
   PRODUCTNAME            Product name (minus the release, e.g. "Database")
   PRODUCTRID             Product release ID (e.g. "10gr2")
   VENDORURL              Vendor URL (optional)
   PRODUCTURL             Product URL (optional)
   SUPPORTURL             Support URL (optional)
==============================================================*/
CREATE VIEW VUMV_VA_PRODUCTS AS
SELECT   ID         ,
         VENDORNAME ,
         VENDORUUID ,
         PRODUCTNAME,
         PRODUCTRID ,
         VENDORURL  ,
         PRODUCTURL ,
         SUPPORTURL
FROM VCI_VA_PRODUCTS
;

/*==============================================================
 Populate Update Manager Version Information

 ********** IMPORTANT***************
 While changing these values, make sure that corresponding entries in code
 (vcidbInit.h for mow) are up-to-date
==============================================================*/

/* PostgreSQL support is introduced after Release 6.0.0 (corresponding
   to VCI_data_oracle-80-90 and VCI_data_mssql-80-90) */

INSERT INTO vci_version (version_id, version_string, db_schema_version_id) VALUES
   (1, 'VMware vSphere Update Manager Release 6.5.0', 100);
