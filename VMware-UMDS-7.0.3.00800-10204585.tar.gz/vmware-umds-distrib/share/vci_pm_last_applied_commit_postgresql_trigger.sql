/* *************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

CREATE OR REPLACE FUNCTION last_update_time() RETURNS TRIGGER as $$
BEGIN
   NEW.LAST_UPDATE_TIME = now();
   RETURN NEW;
END
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_last_update_time on PM_LAST_APPLIED_COMMIT;

CREATE TRIGGER update_last_update_time
BEFORE UPDATE ON PM_LAST_APPLIED_COMMIT
FOR EACH ROW EXECUTE PROCEDURE last_update_time();
