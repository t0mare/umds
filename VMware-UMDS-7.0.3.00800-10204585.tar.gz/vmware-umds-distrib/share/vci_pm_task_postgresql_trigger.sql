/* *************************************************************************
 * Copyright 2018-2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * ************************************************************************ */

/*
 * vci_pm_task_trigger.sql
 *
 * A trigger to scrub out older tasks on insertion of newer tasks.
 */
CREATE OR REPLACE FUNCTION scrub_pm_tasks() RETURNS TRIGGER as $$
DECLARE
   tmpRow RECORD;
BEGIN
   FOR tmpRow in SELECT DISTINCT operation_id, service_id FROM pm_tasks
   LOOP
      -- For each of the operation_id and service_id,
      -- delete all the tasks that are older than
      -- 7 days and preserve the task that was last updated.
      DELETE FROM pm_tasks WHERE operation_id=tmpRow.operation_id
      AND service_id=tmpRow.service_id AND last_updated IS NOT NULL
      AND last_updated<(NOW() AT TIME ZONE 'utc')-INTERVAL '7 days'
      AND task_id NOT IN (SELECT task_id FROM pm_tasks
                          WHERE operation_id=tmpRow.operation_id
                                AND service_id=tmpRow.service_id
                                AND last_updated IS NOT NULL
                                AND status>=3
                          ORDER BY last_updated DESC LIMIT 1);
   END LOOP;
   RETURN NEW;
END
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS scrub_old_pm_tasks ON PM_TASKS;

CREATE TRIGGER scrub_old_pm_tasks
BEFORE INSERT ON PM_TASKS
EXECUTE PROCEDURE scrub_pm_tasks();
