/* *************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Add column BUILTIN to PM_OFFLINE_DEPOTS
 *
 * BUILTIN     : Whether or not the offline depot is a built-in depot
               0 - Not a built-in depot (User-Defined)
               1 - built-in depot
 */
ALTER TABLE PM_OFFLINE_DEPOTS ADD COLUMN BUILTIN integer DEFAULT 0;
