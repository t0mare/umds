/* *************************************************************************
 * Copyright 2020 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Drop constraint on column VM_POWER_ACTION in PM_COORDINATOR_POLICY_OVERRIDES */
ALTER TABLE PM_COORDINATOR_POLICY_OVERRIDES DROP CONSTRAINT IF EXISTS pm_coordinator_policy_overrides_vm_power_action_check;
