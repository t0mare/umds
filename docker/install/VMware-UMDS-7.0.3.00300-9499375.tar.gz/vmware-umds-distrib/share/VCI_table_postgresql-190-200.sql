/* *************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/*==============================================================================
ENUMERATIONS
==============================================================================*/
CREATE TYPE manifest_category_type AS ENUM ('SECURITY',
                                            'ENHANCEMENT',
                                            'BUGFIX');

/*=======================================================================
 Table: PM_TASK_NOTIFICATIONS

 Table to record task-related notifications

 TASK_ID             : ID of the task
 NS_TYPE             : Type of the notification. 0: INFO, 1: WARNING, 2: ERROR
 NOTIFICATION        : Content of the notification
 CREATE_TIME         : The time when the notification is created
========================================================================*/
CREATE TABLE IF NOT EXISTS PM_TASK_NOTIFICATIONS (
   TASK_ID            varchar(255)      NOT NULL,
   NS_TYPE            integer           CHECK (NS_TYPE >= 0 and NS_TYPE <= 2) NOT NULL,
   NOTIFICATION       jsonb             NOT NULL,
   CREATE_TIME        timestamp         DEFAULT (now() at time zone 'utc'),
   FOREIGN KEY (TASK_ID)
      REFERENCES PM_TASKS (TASK_ID)
         ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS task_idx ON pm_task_notifications(task_id);

/* Drop column 'notifications' in pm_tasks */
ALTER TABLE PM_TASKS DROP COLUMN IF EXISTS NOTIFICATIONS;

/*=======================================================================
 Table: PM_HCL_COMPLIANCES
 CLUSTER_ID             : ID of the cluster
 DESIRED_STATE_ID       : ID of desired state against which compliance was calculated
 COMPLIANCE_RESULT      : Compliance results are stored in json
 SUMMARY                : Compliance summary is stored in json
 CREATE_TIME            : When the compliance result was created
=======================================================================*/

CREATE TABLE IF NOT EXISTS PM_HCL_COMPLIANCES (
   CLUSTER_ID                 varchar(255)            NOT NULL,
   DESIRED_STATE_ID           INTEGER                 NOT NULL,
   COMPLIANCE_RESULT          json                    NOT NULL,
   SUMMARY_RESULT             json                    NOT NULL,
   CLUSTER_INVENTORY_CHANGED  bool                    NOT NULL DEFAULT FALSE,
   CREATE_TIME                timestamp               DEFAULT (now() at time zone 'utc'),
   PRIMARY KEY (CLUSTER_ID)
);

/* Add column to pm_software_compliances */
ALTER TABLE PM_SOFTWARE_COMPLIANCES ADD COLUMN IF NOT EXISTS HW_SCAN_RESULT json;
ALTER TABLE PM_SOFTWARE_COMPLIANCES ADD COLUMN IF NOT EXISTS HW_REMEDIATION_IMPACT json;

/*=======================================================================
 Table: PM_DEPOT_MANIFESTS
 NAME                   : Name of the HSP Manifest
 VERSION                : Version of the HSP Manifest
 DISPLAY_NAME           : Human readable name of the HSP Manifest
 DISPLAY_VERSION        : Human readable version of the HSP Manifest
 VENDOR                 : Vendor of the HSP Manifest
 SUMMARY                : Summary of the HSP Manifest
 DESCRIPTION            : Description of the HSP Manifest
 CATEGORY               : Category of the HSP Manifest
 RELEASE_DATE           : Release date of the HSP Manifest
 KB                     : KB of the HSP Manifest
 BASE_IMAGE_VERSIONS    : Supported base image versions of the HSP Manifest
 MANAGER_NAME           : Hardware support manager name
 PACKAGE_NAME           : Hardware support package name
 PACKAGE_VERISON        : Hardware support package version
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_DEPOT_MANIFESTS (
   NAME                 varchar(255)            NOT NULL,
   VERSION              varchar(255)            NOT NULL,
   DISPLAY_NAME         varchar(255)            NOT NULL,
   DISPLAY_VERSION      varchar(255)            NOT NULL,
   VENDOR               varchar(255)            NOT NULL,
   SUMMARY              varchar(255)            DEFAULT '',
   DESCRIPTION          text                    DEFAULT '',
   CATEGORY             manifest_category_type  NOT NULL,
   RELEASE_DATE         timestamp               NOT NULL,
   KB                   varchar(255)            NOT NULL,
   BASE_IMAGE_VERSIONS  varchar(255)            NOT NULL,
   MANAGER_NAME         varchar(255)            NOT NULL,
   PACKAGE_NAME         varchar(255)            NOT NULL,
   PACKAGE_VERSION      varchar(255)            NOT NULL,
   PRIMARY KEY (NAME, VERSION)
);

/*=======================================================================
 Table: PM_DEPOT_MANIFESTS_COMPONENTS

 Junction table mapping PM_DEPOT_MANIFESTS and PM_DEPOT_COMPONENTS tables together.
 Used to identify the set of components that are being added by the given manifest.

 MANIFEST_NAME             : Foreign key to PM_DEPOT_MANIFESTS table
 MANIFEST_VERSION          : Foreign key to PM_DEPOT_MANIFESTS table
 COMPONENT_NAME         : Foreign key to PM_DEPOT_COMPONENTS table
 COMPONENT_VERSION      : Foreign key to PM_DEPOT_COMPONENTS table
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_DEPOT_MANIFESTS_COMPONENTS (
   MANIFEST_NAME                 varchar(255)            NOT NULL,
   MANIFEST_VERSION              varchar(255)            NOT NULL,
   COMPONENT_NAME                varchar(255)            NOT NULL,
   COMPONENT_VERSION             varchar(255)            NOT NULL,
   PRIMARY KEY (MANIFEST_NAME, MANIFEST_VERSION, COMPONENT_NAME, COMPONENT_VERSION),
   FOREIGN KEY (MANIFEST_NAME, MANIFEST_VERSION)
      REFERENCES PM_DEPOT_MANIFESTS(NAME, VERSION) ON DELETE CASCADE,
   FOREIGN KEY (COMPONENT_NAME, COMPONENT_VERSION)
      REFERENCES PM_DEPOT_COMPONENTS (NAME, VERSION) ON DELETE RESTRICT
);

/*=======================================================================
 Table: PM_DEPOT_MANIFESTS_REMOVED_COMPONENTS

 Junction table mapping PM_DEPOT_MANIFESTS and PM_DEPOT_COMPONENTS tables together.
 Used to identify the set of components that are being removed by the given manifest.

 MANIFEST_NAME             : Foreign key to PM_DEPOT_MANIFESTS table
 MANIFEST_VERSION          : Foreign key to PM_DEPOT_MANIFESTS table
 COMPONENT_NAME         : Foreign key to PM_DEPOT_COMPONENTS table
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_DEPOT_MANIFESTS_REMOVED_COMPONENTS (
   MANIFEST_NAME           varchar(255)            NOT NULL,
   MANIFEST_VERSION        varchar(255)            NOT NULL,
   COMPONENT_NAME          varchar(255)            NOT NULL,
   PRIMARY KEY (MANIFEST_NAME, MANIFEST_VERSION, COMPONENT_NAME),
   FOREIGN KEY (MANIFEST_NAME, MANIFEST_VERSION)
      REFERENCES PM_DEPOT_MANIFESTS (NAME, VERSION) ON DELETE CASCADE
);
