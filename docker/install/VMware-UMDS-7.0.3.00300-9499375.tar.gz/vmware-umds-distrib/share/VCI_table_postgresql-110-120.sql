/* *************************************************************************
 * Copyright 2017 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Postgres upgrade script from base schema: tables */

/*==============================================================
  Table: VCI_REMEDIATEPRECHECK_RESULTS

   TARGET_UID           Identifier of target entity
   ENDTIME              End time of the precheck operation
   NON_BLOCKING_ISSUES  Number of non blocking issues found
   BLOCKING_ISSUES      Number of blocking issues found
==================================================================*/
CREATE TABLE VCI_REMEDIATEPRECHECK_RESULTS (
   TARGET_UID           VARCHAR(255)                        NOT NULL,
   ENDTIME              TIMESTAMP                           NOT NULL,
   NON_BLOCKING_ISSUES  INTEGER                             NOT NULL DEFAULT 0,
   BLOCKING_ISSUES      INTEGER                             NOT NULL DEFAULT 0,
   CONSTRAINT PK_VCI_REMEDIATEPRECHECK_RES PRIMARY KEY (TARGET_UID)
);
