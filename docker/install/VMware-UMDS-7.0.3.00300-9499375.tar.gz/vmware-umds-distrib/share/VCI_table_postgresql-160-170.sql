/* *************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

ALTER TABLE PM_COORDINATOR_POLICY_OVERRIDES ADD COLUMN IF NOT EXISTS
   RETRY_COUNT integer CHECK(RETRY_COUNT >= 1);

/* Add column service_id */
ALTER TABLE PM_TASKS ADD COLUMN SERVICE_ID TEXT;
