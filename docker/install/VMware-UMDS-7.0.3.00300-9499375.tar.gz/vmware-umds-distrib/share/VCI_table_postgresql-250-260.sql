/* *************************************************************************
 * Copyright 2020-2021 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

CREATE SEQUENCE IF NOT EXISTS PM_HCM_NONCE_ID_SEQ INCREMENT BY 1;

/*==============================================================================
ENUMERATIONS
==============================================================================*/
CREATE TYPE plugin_type AS ENUM ('INTERNAL',
                                 'EXTERNAL');

/*=======================================================================
 Table: PM_HCM_AUTH_INFO
 NONCE_ID               : HCM Nonce ID (automatic sequence generated)
 NONCE                  : Random byte data
 CREATION_TIME          : Creation Timestamp UTC to be provided
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_HCM_AUTH_INFO (
   NONCE_ID             Integer                 NOT NULL,
   NONCE                varchar(255)            NOT NULL,
   CREATION_TIME        timestamp               NOT NULL,
   CONSTRAINT PK_PM_HCM_NONCE_ID PRIMARY KEY (NONCE_ID)
);

/*=======================================================================
 Table: PM_HCM_PLUGIN_INFO
 PLUGIN_ID              : Identifier of the plugin
 DISPLAY_NAME           : Display name of the plugin
 DESCRIPTION            : Description of the plugin
 TYPE                   : Type of the plugin, internal or external
 OWNER                  : Owner/provider of the plugin
 PLUGIN_VERSION         : Version of the plugin appliance, if any
 INTERNAL_PORT          : Internal port used by the plugin, applicable for
                          internal plugins only.
 HSM_KEY                : key to the HSM associated, if any
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_HCM_PLUGIN_INFO (
   PLUGIN_ID            varchar(255)            NOT NULL,
   DISPLAY_NAME         varchar(255)            NOT NULL,
   DESCRIPTION          text                    DEFAULT '',
   TYPE                 plugin_type             NOT NULL,
   OWNER                varchar(255)            NOT NULL,
   PLUGIN_VERSION       varchar(255),
   INTERNAL_PORT        varchar(255),
   HSM_KEY              varchar(255),
   NONCE_ID             Integer,
   CONSTRAINT PK_PM_HCM_PLUGIN_ID PRIMARY KEY (PLUGIN_ID),
   CONSTRAINT FK_NONCE_ID FOREIGN KEY (NONCE_ID)
      REFERENCES PM_HCM_AUTH_INFO(NONCE_ID)
);

/*=======================================================================
 Table: PM_HCM_EXTENSION_SERVER_INFO
 EXTENSION_SERVER_ID    : Identifier of the extension server
 API_VERSION            : API version catered by the extension server
 PLUGIN_ID              : Plugin Identifier, which this server is registered to
 DISPLAY_NAME           : Display name of the extension server
 DESCRIPTION            : Description of the extension server
 VENDOR                 : OEM vendor, which this extension server is applicable to
 SERVER_THUMBPRINT      : Extension server thumbprint
 NONCE_ID               : Nonce ID
 BASE_URL               : Base Url to reach the extension server
 CAPABILITIES           : Capabilities provided by the extension server
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_HCM_EXTENSION_SERVER_INFO (
   EXTENSION_SERVER_ID  varchar(255)            NOT NULL,
   API_VERSION          varchar(255)            NOT NULL,
   PLUGIN_ID            varchar(255)            NOT NULL,
   DISPLAY_NAME         varchar(255)            NOT NULL,
   DESCRIPTION          text                    DEFAULT '',
   VENDOR               varchar(255)            NOT NULL,
   SERVER_THUMBPRINT    varchar(255),
   BASE_URL             text,
   CAPABILITIES         json                    NOT NULL,
   CONSTRAINT PK_EXTENSION_SERVER_ID PRIMARY KEY (EXTENSION_SERVER_ID),
   CONSTRAINT FK_PLUGIN_ID FOREIGN KEY (PLUGIN_ID)
      REFERENCES PM_HCM_PLUGIN_INFO(PLUGIN_ID)
);

/*=======================================================================
 Table: PM_HCM_HOST_ASSOC_INFO
 HOST_ID                : Host MOID
 EXTENSION_SERVER_ID    : Extension server identifier
 HW_ID                  : Internal hardware ID
 PROGRAM_KEYS           : Program keys
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_HCM_HOST_ASSOC_INFO (
   HOST_ID              varchar(255)            NOT NULL,
   EXTENSION_SERVER_ID  varchar(255)            NOT NULL,
   HW_ID                varchar(255),
   PROGRAM_KEYS         varchar(255),
   CONSTRAINT PK_HOST_ID_EXT_SERVER_ID PRIMARY KEY (HOST_ID, EXTENSION_SERVER_ID),
   CONSTRAINT FK_EXTENSION_SERVER_ID FOREIGN KEY (EXTENSION_SERVER_ID)
        REFERENCES PM_HCM_EXTENSION_SERVER_INFO(EXTENSION_SERVER_ID)
);

/*=======================================================================
 Table: PM_HCM_CLUSTER_ASSOC_INFO
 CLUSTER_ID             : Cluster MOID
 EXTENSION_SERVER_IDS   : Extension server identifiers associated to the cluster
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_HCM_CLUSTER_ASSOC_INFO (
   CLUSTER_ID           varchar(255)            NOT NULL,
   EXTENSION_SERVER_IDS json                    NOT NULL,
   CONSTRAINT PK_PM_HCM_CLUSTER_ASSOC_CLUSTER_ID  PRIMARY KEY (CLUSTER_ID)
);

/*==============================================================
 Table: PM_ONLINE_AND_UMDS_TO_MICRO_DEPOT

 Junction table mapping online/UMDS depots to micro depots (identified by
 vendor code and metadata file name).

 DEPOT_ID    : Identifier of an online/UMDS depot
 VENDOR_CODE : Vendor code
 METADATA_FILE_NAME : Name of metadata file belonging to the online/UMDS depot
=================================================================*/
CREATE TABLE IF NOT EXISTS PM_ONLINE_AND_UMDS_TO_MICRO_DEPOT (
   DEPOT_ID                varchar(40)             NOT NULL,
   VENDOR_CODE             varchar(255)            NOT NULL,
   METADATA_FILE_NAME      text                    NOT NULL,
   PRIMARY KEY (DEPOT_ID, VENDOR_CODE, METADATA_FILE_NAME),
   FOREIGN KEY (DEPOT_ID)
      REFERENCES PM_ONLINE_AND_UMDS_DEPOTS (DEPOT_ID) ON DELETE CASCADE
);

/*==============================================================
 Table: PM_OFFLINE_TO_MICRO_DEPOT

 Junction table mapping online depots to micro depots (identified by
 vendor code and metadata file name).

 DEPOT_ID    : Identifier of an offline depot
 VENDOR_CODE : Vendor code
 METADATA_FILE_NAME : Name of metadata file belonging to the offline depot
=================================================================*/
CREATE TABLE IF NOT EXISTS PM_OFFLINE_TO_MICRO_DEPOT (
   DEPOT_ID                varchar(40)             NOT NULL,
   VENDOR_CODE             varchar(255)            NOT NULL,
   METADATA_FILE_NAME      text                    NOT NULL,
   PRIMARY KEY (DEPOT_ID, VENDOR_CODE, METADATA_FILE_NAME),
   FOREIGN KEY (DEPOT_ID)
      REFERENCES PM_OFFLINE_DEPOTS (DEPOT_ID) ON DELETE CASCADE
);

ALTER TABLE PM_CONFIG_TREES ADD UNIQUE (TREE_ID, ELEMENT_ID);

ALTER TABLE PM_CLUSTER_DRAFT_TREES ADD UNIQUE (DRAFT_ID, ELEMENT_ID);

ALTER TABLE pm_config_tree_elements
   DROP CONSTRAINT pm_config_tree_elements_check1,
   ADD  CONSTRAINT path_check CHECK (
      ARRAY_LENGTH(CONFIG_PATH, 1) > 0 AND
      ((CONFIG_PATH[1] IN ('cluster', 'profile') AND OP = 'REPLACE') OR
        CONFIG_PATH[1] NOT IN ('cluster', 'profile'))
   );

DELETE FROM VCI_PACKAGE_FILES WHERE PACKAGE_ID NOT IN (SELECT ID FROM VCI_PACKAGES);

ALTER TABLE IF EXISTS VCI_PACKAGE_FILES
   DROP CONSTRAINT IF EXISTS FK_VCI_PACKAGE_FILES,
   ADD CONSTRAINT FK_VCI_PACKAGE_FILES FOREIGN KEY (PACKAGE_ID)
      REFERENCES VCI_PACKAGES(ID) ON DELETE CASCADE;
