/* *************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Postgres upgrade script from base schema: data */
UPDATE vci_version
set db_schema_version_id=180
where db_schema_version_id=170
;
