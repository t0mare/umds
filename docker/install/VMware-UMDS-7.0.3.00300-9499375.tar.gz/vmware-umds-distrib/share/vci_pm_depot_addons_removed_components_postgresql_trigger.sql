/* ************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/*
 * vci_pm_policy_trigger.sql
 *
 * A trigger to verify that given component exists in PM_DEPOT_COMPONENTS table..
 *
 * Note: this trigger has been dropped in VCI_table_postgresql-150-160.sql.
 */
CREATE OR REPLACE FUNCTION check_component_existence() RETURNS TRIGGER as $$
BEGIN
   IF NOT EXISTS (SELECT * from PM_DEPOT_COMPONENTS WHERE NAME=NEW.COMPONENT_NAME) THEN
      RAISE EXCEPTION 'Component with % name does not exist.', NEW.COMPONENT_NAME;
   END IF;
   RETURN NEW;
END
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS component_existence on PM_DEPOT_ADDONS_REMOVED_COMPONENTS;

CREATE TRIGGER component_existence
BEFORE INSERT ON PM_DEPOT_ADDONS_REMOVED_COMPONENTS
FOR EACH ROW EXECUTE PROCEDURE check_component_existence();
