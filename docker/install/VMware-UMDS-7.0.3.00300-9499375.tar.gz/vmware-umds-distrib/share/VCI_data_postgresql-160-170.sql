/* *************************************************************************
 * Copyright 2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Postgres upgrade script from base schema: data */
UPDATE vci_version
set db_schema_version_id=170
where db_schema_version_id=160
;

/* Update retry_count to 1 where failure_action is 1 (FAIL) */
UPDATE PM_COORDINATOR_POLICY_OVERRIDES
set RETRY_COUNT=1
where FAILURE_ACTION=1
;
