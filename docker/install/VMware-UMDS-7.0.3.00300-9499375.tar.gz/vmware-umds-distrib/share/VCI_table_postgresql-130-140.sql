/* *************************************************************************
 * Copyright 2018-2019 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Postgres upgrade script from base schema: tables */

/*==============================================================================
Table:            PM_TASKS
TASK_ID:          Task ID; generally a UUID
START_TIME:       Start time of the task
END_TIME:         End time of the task
LAST_UPDATED:     Last time the task was updated.
STATUS:           0: PENDING, 1 RUNNING, 2: BLOCKED, 3: SUCCEEDED, 4: FAILED
PROGRESS:         Progress of the task (0 <= PROGRESS <= 100)
ENTITY_ID:        The moId of the object being acted on.
ERROR:            Error msg reported by the task
RESULT:           Final result saved by the task
OPERATION_ID:     Task's operation ID
DESCRIPTION:      Task's description
PARENT_TASK_ID:   Task ID of the Parent of this task
IS_CANCELED:      0: CANCEL NOT REQUESTED 1: CANCEL REQUESTED
METADATA:         Task's metadata
USER_NAME:        User that initiated the task
CANCELABLE        Is the task cancelable
NOTIFICATIONS:    Task's detailed running information
==============================================================================*/

CREATE TABLE IF NOT EXISTS PM_TASKS (
    TASK_ID          varchar(255) NOT NULL,
    START_TIME       timestamp    DEFAULT (now() at time zone 'utc'),
    END_TIME         timestamp,
    LAST_UPDATED     timestamp    DEFAULT (now() at time zone 'utc'),
    STATUS           integer      CHECK (STATUS >= 0 and STATUS <= 4) NOT NULL DEFAULT 0,
    PROGRESS         integer      CHECK (PROGRESS >= 0 and PROGRESS <= 100) NOT NULL DEFAULT 0,
    ENTITY_ID        varchar(50)  NOT NULL,
    ERROR            text,
    RESULT           text,
    OPERATION_ID     varchar(255),
    DESCRIPTION      text,
    PARENT_TASK_ID   varchar(255),
    IS_CANCELED      bool     NOT NULL DEFAULT FALSE,
    METADATA         text,
    USER_NAME        varchar(255),
    CANCELABLE       bool     NOT NULL DEFAULT FALSE,
    NOTIFICATIONS    text,
    CONSTRAINT PK_PM_TASKS PRIMARY KEY (TASK_ID)
);

/*==============================================================
 Table: PM_SOFTWARE_SPEC
 SPEC_ID       : The ID of the software spec
 SOFTWARE_SPEC : Software spec data
=============================================================nex=*/
CREATE TABLE IF NOT EXISTS PM_SOFTWARE_SPEC  (
   SPEC_ID                 varchar(255)                   NOT NULL,
   SOFTWARE_SPEC           text,
   CONSTRAINT PK_PM_SOFTWARE_SPEC_ID PRIMARY KEY (SPEC_ID)
);

/*==============================================================
 Table: PM_CLUSTER_SOFTWARE_SPEC
 CLUSTER_ID         : Cluster ID
 SOFTWARE_SPEC_ID   : The name of the associated software spec
=============================================================nex=*/
CREATE TABLE IF NOT EXISTS PM_CLUSTER_SOFTWARE_SPEC  (
   CLUSTER_ID              varchar(255)                   NOT NULL,
   SOFTWARE_SPEC_ID        varchar(255),
   CONSTRAINT PK_PM_CLUSTER_SOFTWARE_SPEC_ID PRIMARY KEY (CLUSTER_ID),
   CONSTRAINT FK_PM_CSS_REF_SS FOREIGN KEY (SOFTWARE_SPEC_ID)
      REFERENCES PM_SOFTWARE_SPEC (SPEC_ID)
);

/*==============================================================
 Table: PM_OFFLINE_DEPOTS
 DEPOT_ID    : The ID of the offline depot (bundle)
 DESCRIPTION : Description
 SOURCE_TYPE : Type of the source from which the offline bundle is
               obtained: 0 - PULL; 1 - PUSH
 LOCATION    : URL of the offline bundle from which content should
               be retrieved (valid only when the source type is PULL)
 FILE_ID     : File identifier returned by the file upload endpoint
               after the offline bundle is uploaded (valid only
               when the source type is PUSH)
 CREATE_TIME : When the offline depot was created
=============================================================nex=*/
CREATE TABLE IF NOT EXISTS PM_OFFLINE_DEPOTS  (
   DEPOT_ID                varchar(40)                          NOT NULL,
   DESCRIPTION             text                                 NOT NULL,
   SOURCE_TYPE             integer                    NOT NULL DEFAULT 0,
   LOCATION                text                                 NOT NULL,
   FILE_ID                 varchar(255)                         NOT NULL,
   CREATE_TIME             timestamp  DEFAULT (now() at time zone 'utc'),
   CONSTRAINT PK_PM_OFFLINE_DEPOT_ID PRIMARY KEY (DEPOT_ID)
);

/*=======================================================================
 Table: PM_COORDINATOR_POLICY_OVERRIDES
 ENTITY_ID            : The ID of the managed object entity for which the
                        policies are being overridden.
 FAILURE_ACTION       : Failure action in case of failure:
                        0: Fail the remediation task.
                        1: Retry the task after the period specified by
                           RETRY_DELAY
 RETRY_DELAY          : Delay after which to retry the remediation action
                        after a failure. The delay is between 5 minutes to
                        an hour.
 VM_POWER_ACTION      : Possible actions to take before entering
                        maintenance mode:
                        0: Power off the VMs.
                        1: Suspend the VMs.
                        2: Do not change the power state of the VMs.
 ENABLE_QUICKBOOT     : Enable/disable Quickboot.
 DISABLE_DPM          : Enable/disable DPM.
 DISABLE_HAC          : Enable/disable HAC.
 EVACUATE_OFFLINE_VMS : Evacuate powered off/suspended VMs.

===================================================================nex=*/
CREATE TABLE IF NOT EXISTS PM_COORDINATOR_POLICY_OVERRIDES (
    ENTITY_ID               varchar(40)                          NOT NULL,
    FAILURE_ACTION          integer
                            CHECK(FAILURE_ACTION >= 0 and FAILURE_ACTION <=3),
    RETRY_DELAY             integer
                            CHECK(RETRY_DELAY >= 300 and RETRY_DELAY <= 3600),
    VM_POWER_ACTION         integer
                            CHECK(VM_POWER_ACTION >= 0 and VM_POWER_ACTION <= 2),
    ENABLE_QUICK_BOOT       bool,
    DISABLE_DPM             bool,
    DISABLE_HAC             bool,
    EVACUATE_OFFLINE_VMS    bool,
    CONSTRAINT PK_PM_COORDINATOR_POLICY_OVERRIDES PRIMARY KEY (ENTITY_ID)
);

/*=======================================================================
 Table: PM_LAST_APPLIED_COMMIT
 ENTITY_ID              : The ID of the managed object entity for which the
                          applied version is being tracked.
 PARENT_ID              : ID of the parent entity.
 APPLIED_COMMIT         : The last successfully applied document commit on the
                          entity.
 UPDATE_TIME            : When the document version was applied.
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_LAST_APPLIED_COMMIT (
   ENTITY_ID               varchar(40)                            NOT NULL,
   PARENT_ID               varchar(40),
   APPLIED_COMMIT          text,
   LAST_UPDATE_TIME        timestamp DEFAULT (now() at time zone 'utc'),
   CONSTRAINT PK_PM_LAST_APPLIED_VERSION_PK PRIMARY KEY (ENTITY_ID)
);

