/* *************************************************************************
 * Copyright 2020-2021 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/* Delete dangling records before updating foreign key constraint */
DELETE FROM VCI_VMHW_SCANRESULTS WHERE SCANH_ID NOT IN (SELECT ID FROM VCI_SCANHISTORY);

/* Drop foreign key constraint and add it back with delete on cascade */
ALTER TABLE IF EXISTS VCI_VMHW_SCANRESULTS
DROP CONSTRAINT IF EXISTS FK_VCI_VMHW_SCANRESULTS_REF_SH;

ALTER TABLE VCI_VMHW_SCANRESULTS ADD CONSTRAINT FK_VCI_VMHW_SCANRESULTS_REF_SH
FOREIGN KEY (SCANH_ID) REFERENCES VCI_SCANHISTORY (ID) ON DELETE CASCADE;


/* Delete dangling records before updating foreign key constraint */
DELETE FROM VCI_VMTOOLS_SCANRESULTS WHERE SCANH_ID NOT IN (SELECT ID FROM VCI_SCANHISTORY);

/* Drop foreign key constraint and add it back with delete on cascade */
ALTER TABLE IF EXISTS VCI_VMTOOLS_SCANRESULTS
DROP CONSTRAINT IF EXISTS FK_VCI_TOOLS_SRES_REF_SH;

ALTER TABLE VCI_VMTOOLS_SCANRESULTS ADD CONSTRAINT FK_VCI_TOOLS_SRES_REF_SH
FOREIGN KEY (SCANH_ID) REFERENCES VCI_SCANHISTORY (ID) ON DELETE CASCADE;

