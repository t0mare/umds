/* *************************************************************************
 * Copyright 2020, 2021 VMware, Inc.   All rights reserved. -- VMware Confidential
 * ************************************************************************ */


/**
 * A function to do a nested jsonb_set() on a jsonb document.
 *
 * Examples:
 * - To set the path $.abc.def to "Hello, World!":
 *   jsonb_set_recursive('{}', {abc, def}, '"Hello, World!"');
 * - To append an element to the array at $.abc.def:
 *   jsonb_set_recursive('{}', {abc, def, NULL}, '"Hello, World!"');
 *
 * @param data The data to set.
 * @param path The path in the document to set.  If the path ends with a NULL
 *             element, the data will be appended to an array.
 * @param new_value The new_value to replace the existing value with or insert
 * a new one.
 */
CREATE OR REPLACE FUNCTION jsonb_set_recursive (data jsonb, path text[], new_value jsonb)
   RETURNS jsonb
   LANGUAGE plpgsql
   IMMUTABLE AS
$$
DECLARE
   chk_path text[];
   cur_path text[];
   cur_idx text;
   cur_value jsonb;
   def_obj jsonb DEFAULT '{}'::jsonb;
BEGIN
   chk_path := path[:ARRAY_LENGTH(path, 1) - 1];
   IF (data #> chk_path IS NULL) THEN -- fast check
      FOREACH cur_idx IN ARRAY chk_path LOOP
         cur_path := cur_path || cur_idx;
         cur_value = data #> cur_path;
         IF (cur_value IS NULL) THEN
            IF (cur_path = chk_path AND path[ARRAY_LENGTH(path, 1)] IS NULL) THEN
               def_obj = '[]'::jsonb;
            END IF;
            data = JSONB_SET(data, cur_path, def_obj);
         ELSIF (JSONB_TYPEOF(cur_value) NOT IN ('object', 'array')) THEN
            RAISE EXCEPTION 'path element by % is neither object nor array', cur_path;
         END IF;
      END LOOP;
   ELSIF (JSONB_TYPEOF(data #> chk_path) NOT IN ('object', 'array')) THEN
      RAISE EXCEPTION 'path element by % is neither object nor array', chk_path;
   END IF;

   IF (path[ARRAY_LENGTH(path, 1)] IS NULL) THEN
      -- When the last element of the path is null, we append to an array
      RETURN JSONB_SET(data, chk_path, data#>chk_path || new_value);
   END IF;
   RETURN JSONB_SET(data, path, new_value);
END
$$;

DROP AGGREGATE IF EXISTS jsonb_set_agg (text [], jsonb);
CREATE AGGREGATE jsonb_set_agg (text [], jsonb) (
   SFUNC = jsonb_set_recursive,
   STYPE = jsonb,
   INITCOND = $jsonb$ {} $jsonb$
);

/**
 * A table-valued function that walks over a JSONB document and returns
 * properties at a given path with their corresponding value.
 *
 * @param value_to_walk The value to walk
 */
CREATE OR REPLACE FUNCTION jsonb_walk (value_to_walk jsonb)
   RETURNS SETOF jsonb_walk_result
   LANGUAGE SQL AS
$$
WITH RECURSIVE extract_all AS (
  SELECT ARRAY[KEY] AS path, value
  FROM JSONB_EACH(value_to_walk)
  UNION ALL
  SELECT ARRAY_APPEND(path, json_obj.key), json_obj.value
  FROM extract_all
      LEFT JOIN JSONB_EACH(
         CASE JSONB_TYPEOF(extract_all.value)
         WHEN 'object' THEN
            extract_all.value
         END) AS json_obj ON JSONB_TYPEOF(extract_all.value) = 'object'
  WHERE json_obj.key IS NOT NULL)
SELECT path, value FROM extract_all;
$$;

/**
 * A table-valued function that walks over a JSONB config document and returns
 * properties at a given path with their corresponding value.
 *
 * @param value_to_walk The value to walk
 */
CREATE OR REPLACE FUNCTION config_walk (value_to_walk jsonb)
   RETURNS SETOF jsonb_walk_result
   LANGUAGE SQL AS
$$
   WITH top_level AS (
      SELECT key as top_key, value FROM jsonb_each(value_to_walk)
   ),

   -- Preserve any metadata provided by the user.
   meta AS (
      SELECT ARRAY[top_key], value
         FROM top_level
         WHERE top_key IN ('$schema', 'metadata')
   ),

   -- The following tables contain the base cluster settings broken up by:
   -- components, groups, and keys.
   components AS (
      SELECT top_key, j.key, j.value
         FROM top_level, jsonb_each(top_level.value) AS j
         WHERE top_key IN ('cluster', 'profile')
   ),
   cgroups AS (
      SELECT top_key, components.key AS comp, j.key AS cgroup, j.value
         FROM components, jsonb_each(components.value) AS j
   ),
   pkeys AS (
      SELECT top_key,
         cgroups.comp AS comp,
         cgroups.cgroup AS cgroup,
         j.key AS key,
         j.value AS value
      FROM cgroups,
         jsonb_each(cgroups.value) AS j
   ),

   -- The following tables contain the host-specific/host-override settings
   hosts AS (
      SELECT top_key, j.key AS host_id, j.value
         FROM top_level, jsonb_each(top_level.value) AS j
         WHERE top_key IN ('host-specific', 'host-override')
   ),
   hcomponents AS (
      SELECT top_key, host_id, j.key AS comp, j.value
         FROM hosts, jsonb_each(hosts.value) AS j
   ),
   hgroups AS (
      SELECT top_key, host_id, comp, j.key AS cgroup, j.value
         FROM hcomponents, jsonb_each(hcomponents.value) AS j
   ),
   hkeys AS (
      SELECT top_key, host_id, comp, cgroup, j.key AS key, j.value AS value
         FROM hgroups, jsonb_each(hgroups.value) AS j
   ),

   -- These tables reshape the above tables into a result-set containing the
   -- path and value.
   cluster_settings AS (
      SELECT ARRAY [top_key, comp, cgroup, key] AS path, value
         FROM pkeys
   ),
   host_settings AS (
      SELECT ARRAY [top_key, host_id, comp, cgroup, key] AS path, value
         FROM hkeys
   )
   SELECT * FROM meta
   UNION ALL
   SELECT * FROM cluster_settings
   UNION ALL
   SELECT * FROM host_settings;
$$;


/**
 * Modify the given JSONB document based on the given operation and path.
 *
 * @param doc The JSONB document to modify
 * @param path The path in the document to modify.
 * @param op The operation to perform on the path.
 * @param value If the operation is 'REPLACE', this is the new value for the path.
 */
CREATE OR REPLACE FUNCTION config_to_json (doc jsonb, path text[], op config_op_type, value jsonb)
   RETURNS jsonb
   LANGUAGE plpgsql AS
$$
DECLARE
BEGIN
   CASE op
      WHEN 'REPLACE' THEN
         IF value IS NULL THEN
            RAISE EXCEPTION 'null value for path: %', path;
         ELSE
            RETURN jsonb_set_recursive (doc, path, value);
         END IF;
      WHEN 'REMOVE' THEN
         RETURN doc #- path;
   END CASE;
END
$$;


/**
 * Aggregate version of config_to_json().
 */
DROP AGGREGATE IF EXISTS config_to_json_agg (text[], config_op_type, jsonb);

CREATE AGGREGATE config_to_json_agg (text[], config_op_type, jsonb) (
   SFUNC = config_to_json,
   STYPE = jsonb,
   INITCOND = $jsonb${
      "profile": {}
   }$jsonb$
);


/**
 * Create a blob with the given value and return its identifier.
 */
CREATE OR REPLACE FUNCTION create_config_blob (blob jsonb)
   RETURNS text
   LANGUAGE plpgsql AS
$$
DECLARE
   new_blob_id text;
BEGIN
   new_blob_id := md5(JSONB_PRETTY(blob));
   INSERT INTO PM_CONFIG_BLOBS (BLOB_ID, VALUE) VALUES (new_blob_id, blob)
   ON CONFLICT (BLOB_ID) DO UPDATE SET ACCESS_TIME = (NOW() at time zone 'utc');
   RETURN new_blob_id;
END
$$;


/**
 * Create a tree element, if it has not already been done, and return the ID.
 *
 * @param path The property path
 * @param op The operation to perform on that property.
 * @param blob_id The identifier of the blob for the property.
 * @return The element ID.
 */
CREATE OR REPLACE FUNCTION create_config_tree_element (path text[], op config_op_type, blob_id varchar(255))
   RETURNS text
   LANGUAGE plpgsql AS
   $$
DECLARE
   new_element_id text;
BEGIN
   new_element_id := md5(path::text::bytea || op::text::bytea || COALESCE(blob_id, '')::bytea);
   INSERT INTO PM_CONFIG_TREE_ELEMENTS (ELEMENT_ID, CONFIG_PATH, OP, BLOB_ID)
      VALUES (new_element_id, path, op, blob_id)
   ON CONFLICT (ELEMENT_ID)
      DO UPDATE SET ACCESS_TIME = (NOW() at time zone 'utc');
   RETURN new_element_id;
END
$$;


/**
 * Return the difference between two tree elements.
 *
 * @param left_elem The "left" element.
 * @param right_elem The "right" element.
 * @return The differences between the two elements.
 */
CREATE OR REPLACE FUNCTION diff_config_tree_element (left_elem pm_config_tree_elements, right_elem pm_config_tree_elements)
   RETURNS config_tree_diff
   LANGUAGE plpgsql AS
$$
BEGIN
   RETURN (left_elem.element_id, right_elem.element_id,
      COALESCE(left_elem.config_path, right_elem.config_path),
      CASE
         WHEN left_elem.element_id = right_elem.element_id THEN 'SAME'
         WHEN left_elem.config_path IS NULL THEN 'RIGHT'
         WHEN right_elem.config_path IS NULL THEN 'LEFT'
         ELSE 'DIFFERENT'
      END)::config_tree_diff;
END
$$;


/**
 * Get the JSON document for a host in a given cluster.
 *
 * @param host_cluster_id The ID of the host's cluster.
 * @param host_id The ID of the host.
 * @return The JSON configuration file for the given host.
 */
CREATE OR REPLACE FUNCTION get_host_doc (host_cluster_id varchar(255), host_id varchar(255))
   RETURNS jsonb
   LANGUAGE plpgsql AS
$$
DECLARE
   cluster_tree_id varchar(255);
BEGIN
   cluster_tree_id := (
      SELECT tree_id FROM pm_cluster_configs, pm_config_commits
      WHERE pm_cluster_configs.cluster_id = host_cluster_id
         AND pm_cluster_configs.commit_id = pm_config_commits.commit_id);
   RETURN (
      SELECT config_to_json_agg (
            CASE WHEN config_path[1] IN ('cluster', 'profile') THEN
               config_path[2:]
            ELSE
               config_path[3:]
            END, op, value ORDER BY config_path)
      FROM pm_config_trees
      NATURAL JOIN pm_config_tree_elements
      NATURAL LEFT JOIN pm_config_blobs
      WHERE pm_config_trees.tree_id = cluster_tree_id
         AND (config_path[1] IN ('cluster', 'profile')
         OR (config_path[1] = 'host-specific'
         AND config_path[2] = host_id)));
END
$$;


/**
 * @return A table containing the clusters and tree elements that contain the
 *         given host BIOS UUID.
 */
CREATE OR REPLACE FUNCTION find_configs_for_host (host_uuid text)
   RETURNS TABLE(cluster_id VARCHAR, element_ids VARCHAR[])
   LANGUAGE plpgsql
AS $$
BEGIN
   RETURN QUERY SELECT pm_cluster_configs.cluster_id,
          ARRAY_AGG(pm_config_trees.element_id)
   FROM pm_config_trees,
        pm_config_tree_elements,
        pm_cluster_configs,
        pm_config_commits
   WHERE pm_config_commits.commit_id = pm_cluster_configs.commit_id AND
         pm_config_commits.tree_id = pm_config_trees.tree_id AND
         pm_config_trees.element_id = pm_config_tree_elements.element_id AND
         pm_config_tree_elements.config_path[1] IN ('host-specific', 'host-override') AND
         pm_config_tree_elements.config_path[2] = host_uuid
   GROUP BY pm_cluster_configs.cluster_id;
END
$$;


/**
 * Drops any references to the given host BIOS UUID in all configurations.
 *
 * @param host_uuid The host BIOS UUID to remove from configurations.
 * @return The commit
 */
CREATE OR REPLACE FUNCTION drop_host_from_config(host_uuid text)
   RETURNS SETOF integer
   LANGUAGE plpgsql AS
$$
DECLARE
   tmp_draft_id INTEGER;
   new_commit_id INTEGER;
   cluster_with_host record;
BEGIN
   FOR cluster_with_host IN
      SELECT * FROM find_configs_for_host(host_uuid)
   LOOP
      SELECT create_draft(cluster_with_host.cluster_id, 'system') INTO tmp_draft_id;
      DELETE FROM pm_cluster_draft_trees
         WHERE draft_id = tmp_draft_id AND
               element_id = ANY(cluster_with_host.element_ids);
      UPDATE pm_cluster_drafts SET draft_state = 'VALID'
         WHERE draft_id = tmp_draft_id;
      SELECT commit_draft(tmp_draft_id, 'Remove host: ' || host_uuid)
         INTO new_commit_id;
      RETURN NEXT new_commit_id;
   END LOOP;
END
$$;


/**
 * Create the initial draft for the given cluster.  The creation of the initial
 * draft is used to enable the Configuration Manager for the cluster.
 *
 * @param draft_cluster_id The MOID of the cluster to create the draft for.
 * @param author The user that is creating the draft.
 */
CREATE OR REPLACE FUNCTION create_initial_draft (draft_cluster_id varchar(255), author text)
   RETURNS integer
   LANGUAGE plpgsql AS
$$
DECLARE
   draft_id integer;
BEGIN
   draft_id := (SELECT NEXTVAL('PM_CONFIG_DRAFT_SEQ'));
   INSERT INTO PM_CLUSTER_DRAFTS (CLUSTER_ID, PARENT_ID, DRAFT_ID, AUTHOR, DRAFT_STATE)
      VALUES (draft_cluster_id, 0, draft_id, author, 'VALID');
   RETURN draft_id;
END
$$;


/**
 * Create a draft that can be used to make changes to a cluster configuration.
 */
CREATE OR REPLACE FUNCTION create_draft (draft_cluster_id varchar(255), author text)
   RETURNS integer
   LANGUAGE plpgsql AS
$$
DECLARE
   draft_id integer;
   draft_parent_id integer;
   parent_tree_id varchar(255);
BEGIN
   draft_id := (SELECT NEXTVAL('PM_CONFIG_DRAFT_SEQ'));
   draft_parent_id := (
    SELECT commit_id
    FROM pm_cluster_configs
    WHERE pm_cluster_configs.cluster_id = draft_cluster_id);
   IF draft_parent_id IS NULL THEN
      -- TODO: Raise an exception since the initial draft was not created.
      draft_parent_id := 0;
   END IF;
   parent_tree_id := (
      SELECT tree_id
      FROM pm_config_commits
      WHERE commit_id = draft_parent_id);

   INSERT INTO PM_CLUSTER_DRAFTS (CLUSTER_ID, PARENT_ID, DRAFT_ID, AUTHOR)
      VALUES (draft_cluster_id, draft_parent_id, draft_id, author);
   INSERT INTO PM_CLUSTER_DRAFT_TREES (DRAFT_ID, ELEMENT_ID)

   SELECT draft_id, element_id
   FROM pm_config_trees
   WHERE TREE_ID = parent_tree_id;

   RETURN draft_id;
END
$$;


/* Validation states for a draft. */
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'config_draft_state')
        THEN
        CREATE TYPE config_draft_state AS ENUM (
           -- The draft has been modified since the last validation
           'MODIFIED',
           -- The draft is currently being validated
           'VALIDATING',
           -- The draft is valid
           'VALID',
           -- The draft is invalid, the validation task needs to be checked for
           -- further details
           'INVALID'
        );
    END IF;
END
$$ LANGUAGE plpgsql;


/**
 * Commit the given draft.
 */
CREATE OR REPLACE FUNCTION commit_draft (draft_id_to_commit integer, description text)
   RETURNS integer
   LANGUAGE plpgsql AS
$$
DECLARE
   current_draft_state config_draft_state;
   new_commit_id integer;
   draft_parent_id integer;
   draft_cluster_id varchar(255);
   author text;
   commit_tree_id varchar(255);
BEGIN
   current_draft_state := (
      SELECT draft_state FROM PM_CLUSTER_DRAFTS
      WHERE DRAFT_ID = draft_id_to_commit);
   IF current_draft_state != 'VALID'
   THEN
      RAISE EXCEPTION 'Draft has not been validated';
   END IF;

   CALL merge_config(draft_id_to_commit);
   IF (
      SELECT COUNT(*)
      FROM PM_CLUSTER_DRAFT_CONFLICTS
      WHERE DRAFT_ID = draft_id_to_commit) > 0
   THEN
      RAISE EXCEPTION 'Unresolved conflicts';
   END IF;
   new_commit_id := (SELECT NEXTVAL('PM_CONFIG_COMMIT_SEQ'));
   draft_parent_id := (
      SELECT PARENT_ID FROM PM_CLUSTER_DRAFTS
      WHERE DRAFT_ID = draft_id_to_commit);
   draft_cluster_id := (
      SELECT CLUSTER_ID FROM PM_CLUSTER_DRAFTS
      WHERE DRAFT_ID = draft_id_to_commit);
   commit_tree_id := (
      SELECT md5(coalesce(
         ARRAY_AGG(element_id ORDER BY ELEMENT_ID)::varchar::bytea,
         -- NB: ARRAY_AGG() returns NULL when there are no rows, but we always
         -- need a result, so we default to an empty string here.
         ''::bytea))
      FROM PM_CLUSTER_DRAFT_TREES
      WHERE DRAFT_ID = draft_id_to_commit);
   author := (
      SELECT PM_CLUSTER_DRAFTS.AUTHOR FROM PM_CLUSTER_DRAFTS
      WHERE DRAFT_ID = draft_id_to_commit);
   INSERT INTO pm_config_trees (TREE_ID, ELEMENT_ID)
      SELECT commit_tree_id, element_id FROM PM_CLUSTER_DRAFT_TREES
         WHERE DRAFT_ID = draft_id_to_commit
      ON CONFLICT (tree_id, element_id) DO NOTHING;

   INSERT INTO pm_config_commits
      (CLUSTER_ID, PARENT_ID, COMMIT_ID, TREE_ID, AUTHOR, DESCRIPTION)
      VALUES (draft_cluster_id, draft_parent_id, new_commit_id, commit_tree_id, author, description);
   INSERT INTO pm_cluster_configs (CLUSTER_ID, COMMIT_ID)
      VALUES (draft_cluster_id, new_commit_id)
   ON CONFLICT (CLUSTER_ID)
      DO UPDATE SET
         commit_id = new_commit_id;

   DELETE FROM PM_CLUSTER_DRAFT_TREES WHERE DRAFT_ID = draft_id_to_commit;
   DELETE FROM PM_CLUSTER_DRAFTS WHERE DRAFT_ID = draft_id_to_commit;
   RETURN new_commit_id;
END
$$;


/**
 * Drop a cluster configuration draft.
 */
CREATE OR REPLACE PROCEDURE drop_draft (draft_id_to_drop integer)
   LANGUAGE plpgsql AS
$$
BEGIN
   DELETE FROM pm_cluster_draft_trees WHERE draft_id = draft_id_to_drop;
   DELETE FROM pm_cluster_draft_conflicts WHERE draft_id = draft_id_to_drop;
   DELETE FROM pm_cluster_drafts WHERE draft_id = draft_id_to_drop;
END
$$;

/**
 * A trigger function that updates the draft's validation state when rows have
 * been INSERTed or DELETEd in the draft's tree structure.
 */
CREATE OR REPLACE FUNCTION config_draft_tree_modified ()
   RETURNS TRIGGER AS
$$
BEGIN
   UPDATE PM_CLUSTER_DRAFTS SET
      draft_state = 'MODIFIED',
      last_modified_time = (now() at time zone 'utc'),
      validate_task_id = '',
      impact_task_id = ''
      WHERE draft_id IN (SELECT distinct draft_id FROM reftable);
   RETURN NULL;
END
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_draft_state_on_ins on PM_CLUSTER_DRAFT_TREES;

/**
 * Trigger to detect insertions into the PM_CLUSTER_DRAFT_TREES table
 */
CREATE TRIGGER update_draft_state_on_ins
   AFTER INSERT ON PM_CLUSTER_DRAFT_TREES
   REFERENCING NEW TABLE AS reftable
   FOR EACH STATEMENT EXECUTE PROCEDURE config_draft_tree_modified();

DROP TRIGGER IF EXISTS update_draft_state_on_del on PM_CLUSTER_DRAFT_TREES;
/**
 * Trigger to detect deletions from the PM_CLUSTER_DRAFT_TREES table
 */
CREATE TRIGGER update_draft_state_on_del
   AFTER DELETE ON PM_CLUSTER_DRAFT_TREES
   REFERENCING OLD TABLE AS reftable
   FOR EACH STATEMENT EXECUTE PROCEDURE config_draft_tree_modified();

/**
 * Clear a cluster configuration draft.
 */
CREATE OR REPLACE PROCEDURE clear_config_draft (draft_id_to_clear integer)
   LANGUAGE plpgsql AS
$$
BEGIN
   DELETE FROM PM_CLUSTER_DRAFT_TREES WHERE DRAFT_ID = draft_id_to_clear;
END
$$;


/**
 * Delete a path in the cluster configuration draft.
 *
 * @param draft_id_to_modify The ID of the draft to modify
 * @param path The path in the configuration to delete
 */
CREATE OR REPLACE PROCEDURE delete_config_draft_path (draft_id_to_modify integer, path text[])
   LANGUAGE plpgsql AS
$$
BEGIN
   DELETE FROM PM_CLUSTER_DRAFT_TREES WHERE
      DRAFT_ID = draft_id_to_modify AND
      ELEMENT_ID IN (
         SELECT ELEMENT_ID
         FROM PM_CONFIG_TREE_ELEMENTS
         WHERE CONFIG_PATH[:array_length(path, 1)] = path);
END
$$;


/**
 * Import a configuration snippet into a cluster configuration draft.
 *
 * @param dst_draft_id The draft to modify with the new configuration snippet.
 * @param config The configuration snippet.
 */
CREATE OR REPLACE PROCEDURE import_config (dst_draft_id integer, config jsonb)
LANGUAGE plpgsql
AS $$
BEGIN
   INSERT INTO pm_cluster_draft_trees (DRAFT_ID, ELEMENT_ID)
   SELECT dst_draft_id, create_config_tree_element (
         CASE path[1]
            WHEN '$schema' THEN
               path
            WHEN 'metadata' THEN
               path
            WHEN 'cluster' THEN
               path
            WHEN 'profile' THEN
               path
            WHEN 'host-specific' THEN
               path
            WHEN 'host-override' THEN
               path
            ELSE
               path[:ARRAY_LENGTH(path, 1) - 1]
         END,
         CASE path[1]
            WHEN '$schema' THEN
               'REPLACE'
            WHEN 'metadata' THEN
               'REPLACE'
            WHEN 'cluster' THEN
               'REPLACE'
            WHEN 'profile' THEN
               'REPLACE'
            WHEN 'host-specific' THEN
               'REPLACE'
            WHEN 'host-override' THEN
               'REPLACE'
            ELSE
               path[ARRAY_LENGTH(path, 1)]::config_op_type
         END,
         CASE
            WHEN path[1] = 'host-specific'
               AND path[ARRAY_LENGTH(path, 1)] = 'REMOVE' THEN
               NULL
            ELSE
               create_config_blob (value)
         END)
   FROM config_walk (config)
   ON CONFLICT (DRAFT_ID, ELEMENT_ID) DO NOTHING;
END
$$;

/**
 * Merge changes that have been committed to the cluster configuration after
 * this draft was last created/merged.  The procedure compares the draft's
 * parent tree against the current top tree to find the changed elements. The
 * set of "external" changes are compared against the changes in the draft
 * (internal).  If there are external and internal changes to an element, then
 * there is a conflict and the PM_CLUSTER_DRAFT_CONFLICTS table is updated with
 * the relevant information.  If there are no conflicts, the draft is updated
 * with the external changes.
 *
 * @param dst_draft_id The ID of the draft.
 */
CREATE OR REPLACE PROCEDURE merge_config (dst_draft_id integer)
   LANGUAGE plpgsql AS
$$
DECLARE
   parent_tree_id varchar(255);
   top_commit_id integer;
   top_tree_id varchar(255);
   r record;
BEGIN
   -- Get the ID for the tree that was committed when this draft was created.
   parent_tree_id := (
      SELECT tree_id
      FROM pm_cluster_drafts
      LEFT JOIN pm_config_commits ON pm_cluster_drafts.parent_id = pm_config_commits.commit_id
   WHERE draft_id = dst_draft_id);
   -- Get the ID for the tree that is currently committed.
   top_commit_id := (
      SELECT commit_id
      FROM pm_cluster_drafts
      LEFT JOIN pm_cluster_configs ON pm_cluster_configs.cluster_id = pm_cluster_drafts.cluster_id
      WHERE draft_id = dst_draft_id);
   IF top_commit_id IS NULL THEN
      top_commit_id := 0;
   END IF;
   top_tree_id := (
      SELECT tree_id FROM pm_config_commits WHERE commit_id = top_commit_id);

   IF (parent_tree_id = top_tree_id) THEN
      return;
   END IF;

   DELETE FROM PM_CLUSTER_DRAFT_CONFLICTS WHERE DRAFT_ID = dst_draft_id;

   -- parent_tree contains the elements in the parent tree
   WITH parent_tree AS (
      SELECT (pm_config_tree_elements).*
         FROM pm_config_trees
         NATURAL JOIN pm_config_tree_elements
         WHERE tree_id = parent_tree_id
      ),
   -- draft_tree contains the elements in the draft tree
   draft_tree AS (
      SELECT (pm_config_tree_elements).*
         FROM pm_cluster_draft_trees
         NATURAL JOIN pm_config_tree_elements
         WHERE draft_id = dst_draft_id
   ),
   -- top_tree contains the elements in the draft tree
   top_tree AS (
      SELECT (pm_config_tree_elements).*
         FROM pm_config_trees
         NATURAL JOIN pm_config_tree_elements
         WHERE tree_id = top_tree_id
   ),
   -- compare the elements in the draft tree against the parent to find
   -- "internal" changes.  In this context, the result of the
   -- diff_config_tree_element() function are as follows:
   --   LEFT      - The value was in the parent and deleted from the draft.
   --   RIGHT     - The value was added in the draft.
   --   SAME      - The value is unmodified in the draft.
   --   DIFFERENT - The value was modified in the draft.
   internal_changes AS (
      SELECT (diff_config_tree_element (parent_tree, draft_tree)).*
         FROM draft_tree
         FULL JOIN parent_tree ON parent_tree.config_path = draft_tree.config_path
   ),
   -- compare the elements in the parent tree against the top tree to find
   -- "external" changes.  In this context, the result of the
   -- diff_config_tree_element() function are as follows:
   --   LEFT      - The value was in the parent and deleted by a new commit.
   --   RIGHT     - The value was added by a new commit.
   --   SAME      - The value was unmodified.
   --   DIFFERENT - The value was modified by a new commit.
   external_changes AS (
      SELECT (diff_config_tree_element (parent_tree, top_tree)).*
         FROM parent_tree
         FULL JOIN top_tree ON parent_tree.config_path = top_tree.config_path
   ),
   -- find elements where there are internal and external changes and add them
   -- to the PM_CLUSTER_DRAFT_CONFLICTS table.
   conflicts AS (
      INSERT INTO PM_CLUSTER_DRAFT_CONFLICTS
         (DRAFT_ID, INTERNAL_ELEMENT_ID, EXTERNAL_ELEMENT_ID)
      SELECT dst_draft_id,
             internal_changes.right_element_id,
            external_changes.right_element_id
         FROM external_changes
         INNER JOIN internal_changes ON
            internal_changes.path = external_changes.PATH AND
            internal_changes.right_element_id <> external_changes.right_element_id
         WHERE external_changes.op <> 'SAME'
   ),
   -- delete elements in the draft that were deleted by an external change
   deletions AS (
      DELETE FROM pm_cluster_draft_trees
         WHERE draft_id = dst_draft_id AND
               element_id IN (
                  SELECT left_element_id FROM external_changes
                     WHERE op = 'LEFT')
   )
   -- add external additions/modifications to the draft tree
   INSERT INTO pm_cluster_draft_trees (DRAFT_ID, ELEMENT_ID)
      SELECT dst_draft_id, external_changes.right_element_id
         FROM external_changes
         LEFT JOIN internal_changes ON
            internal_changes.path = external_changes.path AND
            internal_changes.path IS NULL
         WHERE external_changes.op IN ('DIFFERENT', 'RIGHT')
      ON CONFLICT (draft_id, element_id) DO NOTHING;

   UPDATE PM_CLUSTER_DRAFTS SET parent_id = top_commit_id
      WHERE draft_id = dst_draft_id;
END
$$;


/**
 * Export a cluster configuration as a JSON string.
 *
 * @param export_cluster_id The cluster ID.
 */
CREATE OR REPLACE FUNCTION export_config (export_cluster_id varchar(255))
   RETURNS jsonb
   LANGUAGE plpgsql AS
$$
DECLARE
   cluster_tree_id varchar(255);
BEGIN
   cluster_tree_id := (
      SELECT tree_id
      FROM pm_cluster_configs, pm_config_commits
      WHERE pm_cluster_configs.cluster_id = export_cluster_id
         AND pm_cluster_configs.commit_id = pm_config_commits.commit_id);
   IF (cluster_tree_id IS NULL) THEN
      RAISE EXCEPTION 'Configuration Manager is not enabled for cluster %', export_cluster_id;
   END IF;

   RETURN (
      SELECT config_to_json_agg (
            config_path,
            'REPLACE',
            CASE op
               WHEN 'REMOVE' THEN
                  'null'::jsonb
               ELSE
                  value
            END
            ORDER BY config_path)
      FROM pm_config_trees
      LEFT JOIN pm_config_tree_elements ON
         pm_config_tree_elements.element_id = pm_config_trees.element_id
      LEFT JOIN pm_config_blobs ON
         pm_config_blobs.blob_id = pm_config_tree_elements.blob_id
      WHERE pm_config_trees.tree_id = cluster_tree_id
   );
END
$$;


/**
 * Export a cluster configuration as a JSON string.
 *
 * @param export_cluster_id The cluster ID.
 */
CREATE OR REPLACE FUNCTION export_draft_config (export_draft_id integer)
   RETURNS jsonb
   LANGUAGE plpgsql AS
$$
BEGIN
   RETURN (
      SELECT config_to_json_agg (
            config_path,
            'REPLACE',
            CASE op
               WHEN 'REMOVE' THEN
                  'null'::jsonb
               ELSE
                  value
            END
            ORDER BY config_path)
      FROM pm_cluster_draft_trees
      LEFT JOIN pm_config_tree_elements ON
         pm_config_tree_elements.element_id = pm_cluster_draft_trees.element_id
      LEFT JOIN pm_config_blobs ON
         pm_config_blobs.blob_id = pm_config_tree_elements.blob_id
      WHERE pm_cluster_draft_trees.draft_id = export_draft_id
   );
END
$$;


/**
 * Drop a cluster configuration and any current drafts.
 *
 * @param host_cluster_id The cluster ID to delete.
 */
CREATE OR REPLACE PROCEDURE drop_cluster_config (host_cluster_id varchar(255))
   LANGUAGE plpgsql AS
$$
DECLARE
   draft_to_delete integer;
BEGIN
   FOR draft_to_delete IN
      SELECT draft_id FROM PM_CLUSTER_DRAFTS WHERE cluster_id = host_cluster_id
   LOOP
      CALL drop_draft(draft_to_delete);
   END LOOP;
   DELETE FROM pm_cluster_configs WHERE cluster_id = host_cluster_id;
END
$$;


/**
 * Insert a JSON schema object in to the configuration schema table.
 *
 * @param data : The JSONB schema object.
 */
CREATE OR REPLACE PROCEDURE insert_config_schema (data jsonb)
   LANGUAGE plpgsql AS
$$
DECLARE
   vibname text;
   property jsonb;
BEGIN
   vibname := (data #>> '{"metadata", "vibname"}')::text ||
               '-' || (data #>> '{"metadata", "vibversion"}')::text;
   FOR property IN
   SELECT *
   FROM JSONB_ARRAY_ELEMENTS(data -> 'data')
      LOOP
         INSERT INTO PM_CONFIG_SCHEMAS (VIB, SCHEMA_COMPONENT,
                                        SCHEMA_GROUP, SCHEMA_KEY,
                                        SCHEMA_PROPERTY)
            VALUES (vibname, (property ->> 'component')::text,
               (property ->> 'group')::text,
               (property ->> 'key')::text,
               (property #- '{"key"}' #- '{"component"}' #- '{"group"}')::jsonb)
         ON CONFLICT
            DO NOTHING;
      END LOOP;
END
$$;


/**
 * Generate the schema for the host-specific
 *
 * @param vib_name: The name of the vib in pm_config_schemas to generate the
 *                  the schema from.
 * @param v_component: The component in the vib to generate schema for.
 * @param v_group: The group in the vib to generate schema for.
 * @return The host-specific portion of the schema.
 */
CREATE OR REPLACE FUNCTION generate_host_specific_schema (
   vib_name text,
   v_component text,
   v_group text)
   RETURNS jsonb
   LANGUAGE plpgsql AS
$$
DECLARE
   retval jsonb;
BEGIN
   WITH vibschema AS (
      -- Get the requested key schemas.
      SELECT *
         FROM pm_config_schemas
         WHERE
            vib = vib_name AND
            schema_component = v_component AND
            schema_group = v_group
   ),
   root_hspecs AS (
      SELECT ARRAY [schema_key] as path, vibschema.schema_property
         FROM vibschema
         WHERE
            vibschema.schema_property->'hostSpecific' = 'true'::jsonb
   ),
   -- Descend through the schema looking for hostSpecific properties.
   hspecs AS (
      SELECT array_prepend(schema_key, jw.path) as path, jw.value as value
         FROM vibschema, jsonb_walk(vibschema.schema_property) AS jw
         WHERE
            jsonb_typeof(jw.value) = 'object' AND
            jw.value->'hostSpecific' = 'true'::jsonb
   ),
   -- If the hostSpecific properties are in arrays, we need to get the
   -- instanceIds.
   itemInstanceIdPaths AS (
      SELECT DISTINCT array_append(path[:ipos - 1], 'instanceId') AS path
         FROM hspecs, unnest(array_positions(path, 'items')) AS ipos
         WHERE 'items' = any(path)
   ),
   itemIdPath AS (
      SELECT
         array_cat(path[:array_length(path, 1) - 1],
                      ARRAY['items', 'properties',
                      vibschema.schema_property#>>path[2:]]) AS path
         FROM itemInstanceIdPaths, vibschema
         WHERE vibschema.schema_key = path[1]
   ),
   -- Get the instanceId path and its schema
   itemIdPair AS (
      SELECT path, vibschema.schema_property#>path[2:] AS value
         FROM itemIdPath, vibschema
         WHERE vibschema.schema_key = path[1]
   ),
   -- Combine everything together
   everything AS (
      -- Add a 'required' for any instanceId properties
      SELECT
            array_append(path[:array_length(path, 1) - 2], 'required') AS path,
            to_jsonb(ARRAY[path[array_length(path, 1)]]) AS value
         FROM itemIdPath
      UNION ALL
      -- Add constraints to prevent empty objects and arrays
      SELECT
            array_append(path[:array_length(path, 1) - 2], 'minProperties') AS path,
            to_jsonb(1) AS value
         FROM hspecs
      UNION ALL
      -- NB: Array elements require two properties, one for the instanceId and
      -- one for a value.
      SELECT
            array_append(path[:array_length(path, 1) - 2], 'minProperties') AS path,
            to_jsonb(2) AS value
         FROM itemIdPath
      UNION ALL
      SELECT
            array_append(path[:array_length(path, 1) - 1], 'minItems') AS path,
            to_jsonb(1) AS value
         FROM itemInstanceIdPaths
      UNION ALL
      -- Finally, combine the instance ID schemas and the actual hostSpecific
      -- schemas.
      SELECT * FROM itemIdPair
      UNION ALL
      SELECT * FROM root_hspecs
      UNION ALL
      SELECT * FROM hspecs
   )
   SELECT jsonb_set_agg(path, value) INTO retval
      FROM everything;

   RETURN retval;
END
$$;


/**
 * Generate a cluster schema object based on the list of vibs. Optionally, the
 * function takes in a tuple('component', 'group', 'key') to narrow down the
 *
 * @param vibs: List of vibs to generate schema for.
 * @param flt_component: 'component' argument to the filter.
 * @param flt_group: 'group' argument to the filter.
 * @param flt_key: 'key' argument to the filter.
 */
CREATE OR REPLACE FUNCTION generate_config_schema_doc (vibs text[],
                                              flt_component text DEFAULT NULL,
                                              flt_group text DEFAULT NULL,
                                              flt_key text DEFAULT NULL)
   RETURNS jsonb
   LANGUAGE plpgsql AS
$$
DECLARE
   s_vib text;
   s_component text;
   s_group text;
   s_key text;
   s_property jsonb;
   query_result refcursor;
   s_path text[];
   path_element text;
   hs_schema jsonb;
   hs_path text[];
   ret_schema jsonb := NULL;
   walk_rec record;
BEGIN
   IF COALESCE(flt_component, flt_group, flt_key) IS NULL THEN
      OPEN query_result FOR
         SELECT VIB, SCHEMA_COMPONENT, SCHEMA_GROUP,
                JSONB_OBJECT_AGG(SCHEMA_KEY, SCHEMA_PROPERTY)
         FROM PM_CONFIG_SCHEMAS
         WHERE VIB = ANY (vibs)
         GROUP BY VIB, SCHEMA_COMPONENT, SCHEMA_GROUP;
   ELSIF flt_component IS NULL OR flt_component IS NULL OR flt_key IS NULL THEN
         RAISE EXCEPTION 'incomplete filter provided';
   ELSE
      OPEN query_result FOR
         SELECT VIB, SCHEMA_COMPONENT, SCHEMA_GROUP,
                JSONB_OBJECT_AGG(SCHEMA_KEY, SCHEMA_PROPERTY)
         FROM PM_CONFIG_SCHEMAS
         WHERE VIB = ANY (vibs)
            AND (SCHEMA_COMPONENT, SCHEMA_GROUP, SCHEMA_KEY) =
                (flt_component, flt_group, flt_key)
         GROUP BY VIB, SCHEMA_COMPONENT, SCHEMA_GROUP;
   END IF;

   LOOP
      s_path := '{"properties", "profile", "properties"}';
      FETCH query_result INTO s_vib, s_component, s_group, s_property;
      IF NOT FOUND THEN
         IF ret_schema IS NULL THEN
            RAISE EXCEPTION 'No records found';
        END IF;
         EXIT;
      END IF;
      IF ret_schema IS NULL THEN
         ret_schema := $json${
              "type": "object",
              "additionalProperties": false,
              "required": [
                "profile"
              ],
              "properties": {
                "$schema": {
                  "type": "string",
                  "title": "Schema URI",
                  "description": "The URI of the schema for this document"
                },
                "metadata": {
                  "type": "object",
                  "properties": {
                     "author": {
                        "type": "string",
                        "minLength": 1,
                        "title": "Author",
                        "description": "The ID of the author of this configuration"
                     },
                     "description": {
                        "type": "string",
                        "title": "Description",
                        "description": "A description of this configuration"
                     },
                     "tags": {
                        "items": {
                           "type": "string"
                        },
                        "type": "array",
                        "title": "Tags",
                        "description": "Tags to associate with this configuration"
                     },
                     "reference_host": {
                        "type": "object",
                        "title": "Reference Host",
                        "description": "A description of the host this configuration was initially extracted from",
                        "properties": {
                           "uuid": {
                              "type": "string",
                              "pattern": "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
                              "title": "BIOS UUID",
                              "description": "The BIOS UUID of the host"
                           },
                           "build": {
                              "type": "string",
                              "title": "Build Number",
                              "description": "The ESX build number at the time of extraction"
                           },
                           "version": {
                              "type": "string",
                              "title": "Version",
                              "description": "The full ESX version at the time of extraction"
                           },
                           "patch": {
                              "type": "string",
                              "title": "Patch",
                              "description": "The ESX patch version at the time of extraction"
                           },
                           "update": {
                              "type": "string",
                              "title": "Update",
                              "description": "The ESX update version at the time of extraction"
                           }
                        }
                     },
                     "reference_vcenter": {
                        "cluster": {
                           "type": "string",
                           "title": "The cluster path",
                           "description": "The path that specifies the location of the reference cluster in Vcenter's inventory."
                        },
                        "hostname": {
                           "type": "string",
                           "title": "vCenter Hostname",
                           "description": "The hostname of the vCenter instance this configuration was exported from"
                        },
                        "id": {
                           "type": "integer",
                           "minimum": 0,
                           "maximum": 63,
                           "title": "vCenter ID",
                           "description": "The ID of the vCenter instance this configuration was exported from"
                        }
                     }
                  },
                  "additionalProperties": true,
                  "title": "Metadata",
                  "description": "Container for metadata related to this configuration"
                },
                "profile": {
                  "$id": "#profile",
                  "type": "object",
                  "additionalProperties": false,
                  "properties": {},
                  "title": "Profile",
                  "description": "The generic configuration to be applied to hosts"
                },
                "host-specific": {
                  "type": "object",
                  "properties": {},
                  "patternProperties": {
                     "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$": {
                        "type": "object",
                        "properties": {},
                        "minProperties": 1,
                        "additionalProperties": false
                     }
                  },
                  "title": "Host-Specific Configuration",
                  "description": "Container for configuration fragments that are specific to a given host as indexed by the host's BIOS UUID"
                },
                "host-override": {
                  "type": "object",
                  "properties": {},
                  "patternProperties": {
                     "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$": {
                        "$ref": "#/properties/profile"
                     }
                  },
                  "title": "Host-Override Configuration",
                  "description": "Container for configurations that override the profile for a given host as indexed by the host's BIOS UUID"
                }
              }
            }$json$;
      END IF;

      FOREACH path_element IN ARRAY ARRAY[s_component, s_group] LOOP
         s_path := s_path || path_element;
         IF ret_schema #> s_path IS NULL THEN
            ret_schema := JSONB_SET(ret_schema, s_path,
                                    $json${
                                             "type": "object",
                                             "additionalProperties":false,
                                              "properties": {}
                                          }$json$
                                   );
         END IF;
         s_path := s_path || 'properties'::text;
      END LOOP;
      -- Find and remove any 'solutionUser' properties in the schema.
      FOR walk_rec IN
         SELECT jw.path, jw.value FROM jsonb_walk(s_property) AS jw
            WHERE jw.path[ARRAY_LENGTH(jw.path, 1)] = 'solutionUser' AND
                  jw.value = 'true'::jsonb
      LOOP
         s_property := s_property #- walk_rec.path[:ARRAY_LENGTH(walk_rec.path, 1) - 1];
      END LOOP;
      ret_schema := JSONB_SET(ret_schema, s_path, s_property);
      -- Populate in the host-specific section with the stuff from this
      -- component and group
      hs_schema := generate_host_specific_schema(s_vib, s_component, s_group);
      IF hs_schema != '{}'::jsonb THEN
         hs_path := ARRAY['properties',
                  'host-specific',
                  'patternProperties',
                  '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
                  'properties',
                  s_component,
                  'properties',
                  s_group,
                  'properties'];
         ret_schema := jsonb_set_recursive(ret_schema, hs_path, hs_schema);
         ret_schema := jsonb_set(ret_schema,
                                 array_append(hs_path[:6], 'minProperties'),
                                 to_jsonb(1));
         ret_schema := jsonb_set(ret_schema,
                                 array_append(hs_path[:8], 'minProperties'),
                                 to_jsonb(1));
      END IF;
   END LOOP;

   RETURN ret_schema;
END
$$;


/*==============================================================
Extra columns for tracking draft properties in PM_CLUSTER_DRAFTS

Added in the proc file since it is tied to the type declaration
`config_draft_state` defined above.
=================================================================*/

ALTER TABLE PM_CLUSTER_DRAFTS
    ADD COLUMN IF NOT EXISTS DRAFT_STATE config_draft_state DEFAULT 'MODIFIED',
    ADD COLUMN IF NOT EXISTS VALIDATE_TASK_ID varchar(255) NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS IMPACT_TASK_ID varchar(255) NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS LAST_MODIFIED_TIME timestamp DEFAULT
        (NOW() at time zone 'utc');
