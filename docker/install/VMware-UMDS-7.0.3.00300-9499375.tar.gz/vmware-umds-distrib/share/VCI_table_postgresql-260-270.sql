/* *************************************************************************
 * Copyright 2021 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/

/*
 * Add tables for HCL compliance attributes and overrides
 * on servers and PCI devices
 */

/*=======================================================================
Table: PM_SERVER_COMPLIANCE_ATTRIBUTES
HOST_ID                : Identifier of host server
CPU_FMS                : Family/Model/Stepping from server's CPU ID
SERVER_BIOS            : Version of BIOS actually present on server
                         (SMBIOS Type 0, offset 05h)
CPU_SERIES             : Name of CPU Series
CERTIFIED_BIOS         : BIOS version certified with specified CPU series
VCG_PRODUCT_ID         : Identifier of VCG certification record
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_SERVER_COMPLIANCE_ATTRIBUTES (
HOST_ID             varchar(255)            NOT NULL,
CPU_FMS             varchar(255)            DEFAULT '' NOT NULL,
SERVER_BIOS         varchar(255)            DEFAULT '' NOT NULL,
CPU_SERIES          varchar(255)            DEFAULT '' NOT NULL,
CERTIFIED_BIOS      varchar(255),
VCG_PRODUCT_ID      varchar(255),
PRIMARY KEY(HOST_ID)
);

/*=======================================================================
Table: PM_SERVER_COMPLIANCE_OVERRIDES
 ENTITY_ID              : Identifier of cluster/host where override is valid
 MANUFACTURER           : Server SMBIOS 'manufacturer' (Type 1, offset 04h)
 PRODUCT_NAME           : Server SMBIOS 'product name' (Type 1, offset 05h)
 CPU_SERIES             : Name of CPU Series
 SERVER_BIOS            : BIOS actually present on server (Type 0, offset 05h)
 RELEASE                : Version of applicable base image release
 COMPLIANCE_OVERRIDE    : Compliance status override for the device
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_SERVER_COMPLIANCE_OVERRIDES (
ENTITY_ID           varchar(255)            NOT NULL,
MANUFACTURER        varchar(255)            DEFAULT '' NOT NULL,
PRODUCT_NAME        varchar(255)            DEFAULT '' NOT NULL,
CPU_SERIES          varchar(255)            DEFAULT '' NOT NULL,
SERVER_BIOS         varchar(255)            DEFAULT '' NOT NULL,
RELEASE             varchar(255)            NOT NULL,
COMPLIANCE_OVERRIDE int                     DEFAULT 0 NOT NULL,
PRIMARY KEY(ENTITY_ID, MANUFACTURER, PRODUCT_NAME, CPU_SERIES, SERVER_BIOS,
            RELEASE)
);

/*=======================================================================
Table: PM_PCI_DEVICE_COMPLIANCE_OVERRIDES
 ENTITY_ID              : Identifier of cluster/host where override is valid
 PCI_VENDOR_ID          : PCI Device dientifier vendor ID
 PCI_DEVICE_ID          : PCI Device dientifier device ID
 PCI_SUBVENDOR_ID       : PCI Device dientifier subvendor ID
 PCI_SUBSYSTEM_ID       : PCI Device dientifier subsystem ID
 FIRMWARE_VERSION       : Firmware version of the device
 PART_NUMBER            : VCG Part Number
 PRODUCT_ID             : (Storage) Product ID advertised [e.g. NVMe]
 CAPACITY               : Device capacity (in bytes) [storage devices]
 DRIVER_NAME            : Name of driver claiming device
 DRIVER_VERSION         : Version of driver claiming device
 RELEASE                : Version of applicable base image release
 ACTIVE_FEATURES        : String indicating set of solutions/features in use
 COMPLIANCE_OVERRIDE    : Compliance status override for the device
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_PCI_DEVICE_COMPLIANCE_OVERRIDES (
ENTITY_ID           varchar(255)            NOT NULL,
PCI_VENDOR_ID       varchar(255)            NOT NULL,
PCI_DEVICE_ID       varchar(255)            NOT NULL,
PCI_SUBVENDOR_ID    varchar(255)            NOT NULL,
PCI_SUBSYSTEM_ID    varchar(255)            NOT NULL,
FIRMWARE_VERSION    varchar(255)            DEFAULT '' NOT NULL,
PART_NUMBER         varchar(255)            DEFAULT '' NOT NULL,
PRODUCT_ID          varchar(255)            DEFAULT '' NOT NULL,
CAPACITY            bigint                  DEFAULT 0 NOT NULL,
DRIVER_NAME         varchar(255)            NOT NULL,
DRIVER_VERSION      varchar(255)            NOT NULL,
RELEASE             varchar(255)            NOT NULL,
ACTIVE_FEATURES     varchar(255)            DEFAULT '' NOT NULL,
COMPLIANCE_OVERRIDE int                     DEFAULT 0 NOT NULL,
PRIMARY KEY(ENTITY_ID, PCI_VENDOR_ID, PCI_DEVICE_ID, PCI_SUBVENDOR_ID,
            PCI_SUBSYSTEM_ID, FIRMWARE_VERSION, PART_NUMBER, PRODUCT_ID,
            CAPACITY, DRIVER_NAME, DRIVER_VERSION, RELEASE, ACTIVE_FEATURES)
);

/*=======================================================================
Table: PM_PCI_DEVICE_VCG_PRODUCT_ID_OVERRIDES
 ENTITY_ID              : Identifier of cluster/host where override is valid
 PCI_VENDOR_ID          : PCI Device dientifier vendor ID
 PCI_DEVICE_ID          : PCI Device dientifier device ID
 PCI_SUBVENDOR_ID       : PCI Device dientifier subvendor ID
 PCI_SUBSYSTEM_ID       : PCI Device dientifier subsystem ID
 FIRMWARE_VERSION       : Firmware version of the device
 PART_NUMBER            : VCG Part Number
 PRODUCT_ID             : (Storage) Product ID advertised [e.g. NVMe]
 CAPACITY               : Device capacity (in bytes) [storage devices]
 DRIVER_NAME            : Name of driver claiming device
 DRIVER_VERSION         : Version of driver claiming device
 VCG_PRODUCT_ID         : Identifier of VCG certification record
 COMPLIANCE_OVERRIDE    : Compliance status override for the device
=======================================================================*/
CREATE TABLE IF NOT EXISTS PM_PCI_DEVICE_VCG_PRODUCT_ID_OVERRIDES (
ENTITY_ID           varchar(255)            NOT NULL,
PCI_VENDOR_ID       varchar(255)            NOT NULL,
PCI_DEVICE_ID       varchar(255)            NOT NULL,
PCI_SUBVENDOR_ID    varchar(255)            NOT NULL,
PCI_SUBSYSTEM_ID    varchar(255)            NOT NULL,
FIRMWARE_VERSION    varchar(255)            DEFAULT '' NOT NULL,
PART_NUMBER         varchar(255)            DEFAULT '' NOT NULL,
PRODUCT_ID          varchar(255)            DEFAULT '' NOT NULL,
CAPACITY            bigint                  DEFAULT 0 NOT NULL,
DRIVER_NAME         varchar(255)            NOT NULL,
DRIVER_VERSION      varchar(255)            NOT NULL,
VCG_PRODUCT_ID      varchar(255)            NOT NULL,
PRIMARY KEY(ENTITY_ID, PCI_VENDOR_ID, PCI_DEVICE_ID, PCI_SUBVENDOR_ID,
            PCI_SUBSYSTEM_ID, FIRMWARE_VERSION, PART_NUMBER, PRODUCT_ID,
            CAPACITY, DRIVER_NAME, DRIVER_VERSION)
);

/**
 * Add FAIL_IF_UNAVAILABLE_COMPLIANCE column to PM_COORDINATOR_POLICY_INTERNAL table.
 */
ALTER TABLE IF EXISTS PM_COORDINATOR_POLICY_INTERNAL ADD COLUMN FAIL_IF_UNAVAILABLE_COMPLIANCE bool NOT NULL DEFAULT FALSE;

/*==================================================================
 1. Delete dangling records before updating foreign key constraint;

 2. Add "ON DELETE CASCADE" to a couple of relationship tables to
    simplify depot deletion operations.
 ==================================================================*/

DELETE FROM VCI_PACKAGE_FILES WHERE PACKAGE_ID NOT IN (SELECT ID FROM VCI_PACKAGES);

ALTER TABLE IF EXISTS VCI_PACKAGE_FILES
   DROP CONSTRAINT IF EXISTS FK_VCI_PACKAGE_FILES,
   ADD CONSTRAINT FK_VCI_PACKAGE_FILES FOREIGN KEY (PACKAGE_ID)
      REFERENCES VCI_PACKAGES(ID) ON DELETE CASCADE;


DELETE FROM VCI_PLATFORM_METADATA WHERE PLATFORM_ID NOT IN (SELECT ID FROM VCI_PLATFORMS);
DELETE FROM VCI_PLATFORM_METADATA WHERE METADATA_ID NOT IN (SELECT ID FROM VCI_METADATA_FILES);

ALTER TABLE IF EXISTS VCI_PLATFORM_METADATA
   DROP CONSTRAINT IF EXISTS FK_VCI_PLT_MTAS_REF_PLT,
   ADD CONSTRAINT FK_VCI_PLT_MTAS_REF_PLT FOREIGN KEY (PLATFORM_ID)
      REFERENCES VCI_PLATFORMS (ID) ON DELETE CASCADE,
   DROP CONSTRAINT IF EXISTS FK_VCI_PLT_MTAS_REF_MTA,
   ADD CONSTRAINT FK_VCI_PLT_MTAS_REF_MTA FOREIGN KEY (METADATA_ID)
      REFERENCES VCI_METADATA_FILES (ID) ON DELETE CASCADE;


DELETE FROM VCI_UPDATE_PLATFORMS WHERE PLATFORM_ID NOT IN (SELECT ID FROM VCI_PLATFORMS);

ALTER TABLE IF EXISTS VCI_UPDATE_PLATFORMS
   DROP CONSTRAINT IF EXISTS FK_VCI_UPDPLT_REF_PLTS,
   ADD CONSTRAINT FK_VCI_UPDPLT_REF_PLTS FOREIGN KEY (PLATFORM_ID)
      REFERENCES VCI_PLATFORMS (ID) ON DELETE CASCADE;


DELETE FROM VCI_UPDATE_PACKAGES WHERE PACKAGE_ID NOT IN (SELECT ID FROM VCI_PACKAGES);

ALTER TABLE IF EXISTS VCI_UPDATE_PACKAGES
   DROP CONSTRAINT IF EXISTS FK_VCI_UPDPKG_REF_PKGS,
   ADD CONSTRAINT FK_VCI_UPDPKG_REF_PKGS FOREIGN KEY (PACKAGE_ID)
      REFERENCES VCI_PACKAGES (ID) ON DELETE CASCADE;


DELETE FROM VCI_SCANHISTORY_TARGETS WHERE UPDATE_ID NOT IN (SELECT ID FROM VCI_UPDATES);

ALTER TABLE IF EXISTS VCI_SCANHISTORY_TARGETS
   DROP CONSTRAINT IF EXISTS fk_vci_shistvvms_ref_sig,
   DROP CONSTRAINT IF EXISTS FK_VCI_SHISTVMS_REF_SIG,
   ADD CONSTRAINT FK_VCI_SHISTVMS_REF_SIG FOREIGN KEY (UPDATE_ID)
      REFERENCES VCI_UPDATES (ID) ON DELETE CASCADE;


DELETE FROM VCI_BUNDLE_KEYS WHERE PLATFORM_ID NOT IN (SELECT ID FROM VCI_PLATFORMS);

ALTER TABLE IF EXISTS VCI_BUNDLE_KEYS
   DROP CONSTRAINT IF EXISTS FK_VCI_BUNDLEKEYS_REF_PLT,
   ADD CONSTRAINT FK_VCI_BUNDLEKEYS_REF_PLT FOREIGN KEY (PLATFORM_ID)
      REFERENCES VCI_PLATFORMS(ID) ON DELETE CASCADE;


DELETE FROM VCI_PACKAGE_LOCALES WHERE PACKAGE_ID NOT IN (SELECT ID FROM VCI_PACKAGES);
DELETE FROM VCI_PACKAGE_LOCALES WHERE LANG_ID NOT IN (SELECT LANG_ID FROM VCI_LOCALES);

ALTER TABLE IF EXISTS VCI_PACKAGE_LOCALES
   DROP CONSTRAINT IF EXISTS FK_VCI_PKGLCL_REF_PKGS,
   ADD CONSTRAINT FK_VCI_PKGLCL_REF_PKGS FOREIGN KEY (PACKAGE_ID)
      REFERENCES VCI_PACKAGES (ID) ON DELETE CASCADE,
   DROP CONSTRAINT IF EXISTS FK_VCI_PKGLCL_REF_LCLS,
   ADD CONSTRAINT FK_VCI_PKGLCL_REF_LCLS FOREIGN KEY (LANG_ID)
      REFERENCES VCI_LOCALES (LANG_ID) ON DELETE CASCADE;


DELETE FROM VCI_UPDATE_EULAS WHERE EULA_ID NOT IN (SELECT ID FROM VCI_EULA);

ALTER TABLE IF EXISTS VCI_UPDATE_EULAS
   DROP CONSTRAINT IF EXISTS FK_VCI_UPD_EULA_REF_EULA,
   ADD CONSTRAINT FK_VCI_UPD_EULA_REF_EULA FOREIGN KEY (EULA_ID)
      REFERENCES VCI_EULA(ID) ON DELETE CASCADE;


DELETE FROM VCI_UPGRADE_OFFLINE_IDS WHERE OFFLINE_UPGRADE_ID NOT IN (SELECT ID FROM VCI_UPDATES);

ALTER TABLE IF EXISTS VCI_UPGRADE_OFFLINE_IDS
   DROP CONSTRAINT IF EXISTS FK_VCI_UPG_OFF_REF_OFF,
   ADD CONSTRAINT FK_VCI_UPG_OFF_REF_OFF FOREIGN KEY (OFFLINE_UPGRADE_ID)
      REFERENCES VCI_UPDATES (ID) ON DELETE CASCADE;

/*==============================================================
 Due to schema versioning issue, drop and then recreate
 PM_ONLINE_AND_UMDS_TO_MICRO_DEPOT and PM_OFFLINE_TO_MICRO_DEPOT
 that were done in VCI_table_postgresql-250-260.sql.
 ==============================================================*/

DROP TABLE IF EXISTS PM_ONLINE_AND_UMDS_TO_MICRO_DEPOT CASCADE;
DROP TABLE IF EXISTS PM_OFFLINE_TO_MICRO_DEPOT CASCADE;

/*==============================================================
 Table: PM_ONLINE_AND_UMDS_TO_MICRO_DEPOT

 Junction table mapping online/UMDS depots to micro depots (identified by
 vendor code and metadata file name).

 DEPOT_ID    : Identifier of an online/UMDS depot
 VENDOR_CODE : Vendor code
 METADATA_FILE_NAME : Name of metadata file belonging to the online/UMDS depot
=================================================================*/
CREATE TABLE IF NOT EXISTS PM_ONLINE_AND_UMDS_TO_MICRO_DEPOT (
   DEPOT_ID                varchar(40)             NOT NULL,
   VENDOR_CODE             varchar(255)            NOT NULL,
   METADATA_FILE_NAME      text                    NOT NULL,
   PRIMARY KEY (DEPOT_ID, VENDOR_CODE, METADATA_FILE_NAME),
   FOREIGN KEY (DEPOT_ID)
      REFERENCES PM_ONLINE_AND_UMDS_DEPOTS (DEPOT_ID) ON DELETE CASCADE
);

/*==============================================================
 Table: PM_OFFLINE_TO_MICRO_DEPOT

 Junction table mapping online depots to micro depots (identified by
 vendor code and metadata file name).

 DEPOT_ID    : Identifier of an offline depot
 VENDOR_CODE : Vendor code
 METADATA_FILE_NAME : Name of metadata file belonging to the offline depot
=================================================================*/
CREATE TABLE IF NOT EXISTS PM_OFFLINE_TO_MICRO_DEPOT (
   DEPOT_ID                varchar(40)             NOT NULL,
   VENDOR_CODE             varchar(255)            NOT NULL,
   METADATA_FILE_NAME      text                    NOT NULL,
   PRIMARY KEY (DEPOT_ID, VENDOR_CODE, METADATA_FILE_NAME),
   FOREIGN KEY (DEPOT_ID)
      REFERENCES PM_OFFLINE_DEPOTS (DEPOT_ID) ON DELETE CASCADE
);
