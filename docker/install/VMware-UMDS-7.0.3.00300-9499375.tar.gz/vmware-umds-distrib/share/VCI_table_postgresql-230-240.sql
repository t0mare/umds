/* *************************************************************************
 * Copyright 2020 VMware, Inc.   All rights reserved. -- VMware Confidential
 * *************************************************************************/


-- Sequence for commit identifiers
CREATE SEQUENCE IF NOT EXISTS PM_CONFIG_COMMIT_SEQ START 1;


-- Sequence for draft identifiers
CREATE SEQUENCE IF NOT EXISTS PM_CONFIG_DRAFT_SEQ START 1;


/**
 * Operation to perform when modifying a JSON configuration document
 */
CREATE TYPE config_op_type AS ENUM (
   'REPLACE',
   'REMOVE'
);


/**
 * Types of differences between parts of a configuration document
 */
CREATE TYPE config_diff_type AS ENUM (
   -- The property only appears in the "left" argument
   'LEFT',
   -- The property only appears in the "right" argument
   'RIGHT',
   -- The property exists on both sides and the value is the same.
   'SAME',
   -- The property exists on both sides, but the value is different.
   'DIFFERENT'
);


/**
 * The possible validation states for a draft
 */
CREATE TYPE config_draft_state AS ENUM (
   -- The draft has been modified since the last validation
   'MODIFIED',
   -- The draft is currently being validated
   'VALIDATING',
   -- The draft is valid
   'VALID',
   -- The draft is invalid, the validation task needs to be checked for further
   -- details
   'INVALID'
);


/**
 * The result of the jsonb_walk() function
 */
CREATE TYPE jsonb_walk_result AS (
   path text[],
   value jsonb
);


/**
 * The result of the diff_config_tree_element() function
 */
CREATE TYPE config_tree_diff AS (
   -- The ID of the element for the left argument.
   left_element_id varchar (255),
   -- The ID of the element for the right argument.
   right_element_id varchar(255),
   -- The path of the property being compared
   path text[],
   -- The type of difference between the two arguments.
   op config_diff_type
);


/**
 * Table of JSONB configuration blobs.
 */
CREATE TABLE IF NOT EXISTS PM_CONFIG_BLOBS (
   -- The hash of the JSONB blob
   BLOB_ID varchar(255) NOT NULL,
   -- The JSONB blob
   VALUE jsonb NOT NULL,
   CREATE_TIME timestamp DEFAULT (NOW() at time zone 'utc'),
   ACCESS_TIME timestamp DEFAULT (NOW() at time zone 'utc'),

   PRIMARY KEY (BLOB_ID)
);


/**
 * Individual elements that make up a configuration tree
 */
CREATE TABLE IF NOT EXISTS PM_CONFIG_TREE_ELEMENTS (
   -- The hash of the path, op, and blob ID.
   ELEMENT_ID varchar(255) NOT NULL,
   -- The path in the configuration document to be operated on.
   CONFIG_PATH text[] NOT NULL,
   -- The operation to perform on the path.
   OP config_op_type NOT NULL DEFAULT 'REPLACE',
   -- The ID of the blob.
   BLOB_ID varchar(255),
   CREATE_TIME timestamp DEFAULT (NOW() at time zone 'utc'),
   ACCESS_TIME timestamp DEFAULT (NOW() at time zone 'utc'),

   CHECK (
      (OP = 'REMOVE' AND BLOB_ID IS NULL) OR
      (OP = 'REPLACE' AND BLOB_ID IS NOT NULL)
   ),
   CHECK (
      ARRAY_LENGTH(CONFIG_PATH, 1) > 0 AND
      ((CONFIG_PATH[1] = 'cluster' AND OP = 'REPLACE') OR
      CONFIG_PATH[1] <> 'cluster')
   ),

   FOREIGN KEY (BLOB_ID) REFERENCES PM_CONFIG_BLOBS (BLOB_ID) ON DELETE CASCADE,

   PRIMARY KEY (ELEMENT_ID)
);


/**
 * Table of trees that define what makes up the configuration of a cluster.
 */
CREATE TABLE IF NOT EXISTS PM_CONFIG_TREES (
   -- The ID is the hash of the blob hashes.
   TREE_ID varchar(255) NOT NULL,
   -- The ID of the tree element.
   ELEMENT_ID varchar(255) NOT NULL,

   FOREIGN KEY (ELEMENT_ID) REFERENCES PM_CONFIG_TREE_ELEMENTS ON DELETE CASCADE,

   UNIQUE (TREE_ID, ELEMENT_ID)
);


/**
 * Table of commits made to a cluster configuration.
 */
CREATE TABLE IF NOT EXISTS PM_CONFIG_COMMITS (
   CLUSTER_ID varchar(255) NOT NULL,
   -- The ID of the parent of this commit.
   PARENT_ID integer NOT NULL,
   -- The ID of this commit.
   COMMIT_ID integer NOT NULL,
   -- The ID of the tree that captures the configuration document for this commit.
   TREE_ID varchar(255),
   CREATE_TIME timestamp DEFAULT (NOW() at time zone 'utc'),
   AUTHOR text NOT NULL,
   DESCRIPTION text NOT NULL,

   CHECK (TREE_ID IS NOT NULL OR COMMIT_ID = 0),

   FOREIGN KEY (PARENT_ID) REFERENCES PM_CONFIG_COMMITS (COMMIT_ID)
   ON DELETE CASCADE,

   PRIMARY KEY (COMMIT_ID)
);


/**
 * Table of cluster configurations.
 */
CREATE TABLE IF NOT EXISTS PM_CLUSTER_CONFIGS (
   CLUSTER_ID varchar(255) NOT NULL,
   COMMIT_ID integer NOT NULL,
   CREATE_TIME timestamp DEFAULT (NOW() at time zone 'utc'),

   FOREIGN KEY (COMMIT_ID) REFERENCES PM_CONFIG_COMMITS (COMMIT_ID)
   ON DELETE CASCADE,

   PRIMARY KEY (CLUSTER_ID)
);


/**
 * Table of draft changes to a cluster configuration.
 */
CREATE TABLE IF NOT EXISTS PM_CLUSTER_DRAFTS (
   -- The ID of the cluster
   CLUSTER_ID varchar(255) NOT NULL,
   -- The ID of the commit this draft is based off of.
   PARENT_ID integer NOT NULL,
   -- The ID of this draft.
   DRAFT_ID integer NOT NULL,
   -- The Author of this draft.
   AUTHOR text NOT NULL,
   -- The creation time for this draft.
   CREATE_TIME timestamp DEFAULT (NOW() at time zone 'utc'),
   -- The last modified time for this draft.
   LAST_MODIFIED_TIME timestamp DEFAULT (NOW() at time zone 'utc'),
   -- The validation state of the draft.
   DRAFT_STATE config_draft_state DEFAULT 'MODIFIED',
   -- The ID of the task used to validate this draft.
   VALIDATE_TASK_ID varchar(255) NOT NULL DEFAULT '',
   -- The ID of the task used to do impact analysis for this draft.
   IMPACT_TASK_ID varchar(255) NOT NULL DEFAULT '',

   FOREIGN KEY (PARENT_ID) REFERENCES PM_CONFIG_COMMITS (COMMIT_ID)
   ON DELETE CASCADE,

   PRIMARY KEY (DRAFT_ID)
);


/**
 * Table of draft changes to the tree of a cluster configuration.
 */
CREATE TABLE IF NOT EXISTS PM_CLUSTER_DRAFT_TREES (
   -- The ID of the draft this tree element is associated with
   DRAFT_ID integer NOT NULL,
   -- The ID of the tree element.
   ELEMENT_ID varchar(255) NOT NULL,

   FOREIGN KEY (DRAFT_ID) REFERENCES PM_CLUSTER_DRAFTS ON DELETE CASCADE,

   FOREIGN KEY (ELEMENT_ID) REFERENCES PM_CONFIG_TREE_ELEMENTS ON DELETE CASCADE,
   UNIQUE (DRAFT_ID, ELEMENT_ID)
);


/**
 * Table of conflicts detected in a draft by the merge_config() function.
 */
CREATE TABLE IF NOT EXISTS PM_CLUSTER_DRAFT_CONFLICTS (
   -- The ID of the draft.
   DRAFT_ID integer NOT NULL,
   -- The ID of the element that was changed in the draft.
   INTERNAL_ELEMENT_ID varchar(255) NOT NULL,
   -- The ID of the element that was committed separately.
   EXTERNAL_ELEMENT_ID varchar(255) NOT NULL,

   FOREIGN KEY (DRAFT_ID) REFERENCES PM_CLUSTER_DRAFTS ON DELETE CASCADE
);


/**
 * The root commit
 */
INSERT INTO pm_config_commits
   (CLUSTER_ID, PARENT_ID, COMMIT_ID, TREE_ID, AUTHOR, DESCRIPTION)
   VALUES ('', 0, 0, NULL, 'root', 'root commit');


/**
 * Table to store configuration schema properties.
 */
CREATE TABLE IF NOT EXISTS PM_CONFIG_SCHEMAS (
   -- vib in "vibname-vibversion" format.
   VIB text NOT NULL,
   -- component
   SCHEMA_COMPONENT text NOT NULL,
   -- group
   SCHEMA_GROUP text NOT NULL,
   -- key
   SCHEMA_KEY text NOT NULL,
   -- property
   SCHEMA_PROPERTY jsonb NOT NULL,

   CONSTRAINT unique_schema UNIQUE (VIB, SCHEMA_COMPONENT, SCHEMA_GROUP,
                                    SCHEMA_KEY)
);
